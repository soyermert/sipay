<?php

   /*

   Plugin Name: Woocommerce Sipay Payment Gateway

   description: A Payment gateway to pay online.

   Author: Rajib Kanti

   Version: 2.4.5

   */



if ( ! defined( 'ABSPATH' ) ) {

    exit; // Exit if accessed directly

}



add_action( 'plugins_loaded', 'wc_offline_gateway_init', 11 );

function wc_offline_gateway_init() {



// Make sure WooCommerce is active

if ( ! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) return;



    class WC_Gateway_Sipay extends WC_Payment_Gateway 

	{

		public $domain;



		public $headers = array(

			'Accept: application/json',

			'Content-Type: application/json'

			);



		protected $is_3d = 0;





		protected $token ='';

	

		public function __construct(){ 

			$this->domain 			  = 'sipay_custom_payment';

			$this->id                 = 'sipay_payment';

			$this->icon               = apply_filters('woocommerce_custom_gateway_icon', '');

			$this->has_fields         = true;

			$this->method_title       = __( 'Sipay', $this->domain );

			$this->method_description = __( 'Allows payments with Sipay gateway.', $this->domain );

			

			// Load the settings.

			$this->init_form_fields();

			$this->init_settings();

			

			// Define user set variables

			$this->title        = $this->get_option( 'title' );

			$this->description  = $this->get_option( 'description' );

			$this->instructions = $this->get_option( 'instructions', $this->description );

			$this->order_status = $this->get_option( 'order_status', 'completed' );

			

			$this->order_button_text = __( $this->title, 'sipay_payment' );

					

					

			// Actions

			//add_action('init', array(&$this, 'handle_wc_api'));

			add_action( 'wp_enqueue_scripts', array( $this, 'payment_scripts' ) );

			add_action( 'admin_enqueue_scripts', array( $this, 'admin_payment_scripts' ) );

			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'process_admin_options' ) );



			add_action('woocommerce_receipt_sipay_payment', array(&$this, 'receipt_page'));



		} 





		

		

		/**

		 * Initialise Gateway Settings Form Fields.

		*/  

		public function init_form_fields(){
			
	//echo "<pre>"; print_r(debug_backtrace(2)); exit;

			$currency_code_options = get_woocommerce_currencies();



			foreach ( $currency_code_options as $code => $name ) {

				$currency_code_options[ $code ] = $name . ' (' . get_woocommerce_currency_symbol( $code ) . ')';

			}
			
			$installment_options= array();

			
			if(!empty($this->get_option( 'merchant_api_domain' )) && $this->get_option( 'app_id' ) && $this->get_option( 'app_secret' )){
			
    			$token_post = array(
    				'app_id' =>  $this->get_option( 'app_id' ),
    				'app_secret' => $this->get_option( 'app_secret' )
    			);
    			$result = wp_remote_post($this->get_option( 'merchant_api_domain' )."/ccpayment/api/token", array(
    				'method' => 'POST',
    				'sslverify' => false,
    				'body' => $token_post
    			));
				
				if ((isset($result['status_code']) && $result['status_code'] == 100) || !is_wp_error( $result ) ) {

					$tok = json_decode($result['body'], true);
		
					$req_headers= array(
						'Authorization' => "Bearer ".$tok['data']['token']
					);
					
					$req_post = array(
						'merchant_key' =>  $this->get_option( 'merchant_key' )
					);
					$installments = wp_remote_post($this->get_option( 'merchant_api_domain' )."/ccpayment/api/installments", array(
						'method' => 'POST',
						'sslverify' => false,
						'headers' => $req_headers,
						'body' => $req_post
					));

					if ( !is_wp_error( $installments ) ) {
		
						$installments = json_decode($installments['body'], true);
			
						if(isset($installments['status_code']) && $installments['status_code'] == 100 && !empty($installments['installments'])){
							foreach($installments['installments'] as $in => $installment){
								if($installment == 1)
									continue;
			
								/*if($in == 1)
									$inst_title= "Installments";
								else
									$inst_title = '';
			
			
								$installment_fields['installment_'.$installment] = array(
									'title'   => $inst_title,
									'type'    => 'checkbox',
									'label'   => $installment,
									'default' => 'no'
								);*/
			
								$installment_options[$installment]= $installment; 
			
							}
						}
					}
				}
			}

			//echo "<pre>"; print_r($installment_fields); exit;
			
			

			$this->form_fields=	$settings_fields = apply_filters( 'wc_offline_form_fields', array(

				'enabled' => array(

					'title'   => __( 'Enable/Disable', 'wc-gateway-offline' ),

					'type'    => 'checkbox',

					'label'   => __( 'Enable Payment Sipay', 'wc-gateway-offline' ),

					'default' => 'no'

				),



				'title' => array(

					'title'       => __( 'Title', 'wc-gateway-offline' ),

					'type'        => 'text',

					'description' => __( 'This controls the title for the payment method the customer sees during checkout.', 'wc-gateway-offline' ),

					'default'     => __( 'Pay with sipay', 'wc-gateway-offline' ),

					'desc_tip'    => true,

					'required'		=> true,

				),

		

				'description' => array(

					'title'       => __( 'Description', 'wc-gateway-offline' ),

					'type'        => 'textarea',

					'description' => __( 'Payment method description that the customer will see on your checkout.', 'wc-gateway-offline' ),

					'default'     => __( 'Please remit payment to Store Name upon pickup or delivery.', 'wc-gateway-offline' ),

					'desc_tip'    => true,

					

				),

				'order_status' => array(

					'title'       => __( 'Order Status', $this->domain ),

					'type'        => 'select',

					'class'       => 'wc-enhanced-select',

					'description' => __( 'Choose whether status you wish after checkout.', $this->domain ),

					'default'     => 'wc-completed',

					'desc_tip'    => true,

					'options'     => array(

						'wc-processing' => 'Processing',

						'wc-completed' => 'Completed'

					)

				),

				'merchant_key' => array(

					'title'       => __( 'Merchant Key', 'wc-gateway-offline' ),

					'type'        => 'text',

					'description' => __( 'Get your secure secret from Sipay', 'wc-gateway-offline' ),

					'default'     => '',

					'desc_tip'    => false,

					'required' => true,

				),

				'merchant_id' => array(

					'title'       => __( 'Merchant ID', 'wc-gateway-offline' ),

					'type'        => 'text',

					'description' => __( 'Get your Merchant Id from Sipay', 'wc-gateway-offline' ),

					'default'     => '',

					'desc_tip'    => false,

					'required' => true,

				),

				'app_id' => array(

					'title'       => __( 'App ID', 'wc-gateway-offline' ),

					'type'        => 'text',

					'description' => __( 'Get your App Id from Sipay', 'wc-gateway-offline' ),

					'default'     => '',

					'desc_tip'    => false,

					'required' => true

				),

				'app_secret' => array(

					'title'       => __( 'App Secret', 'wc-gateway-offline' ),

					'type'        => 'text',

					'description' => __( 'Get your App Secret from Sipay', 'wc-gateway-offline' ),

					'default'     => '',

					'desc_tip'    => false,

					'required' => true,

				),

				'merchant_currency' => array(

					'title'       => __( 'Merchant Currency', 'wc-gateway-offline' ),

					'type'        => 'select',

					'class'       => 'wc-enhanced-select',

					'description' => __( '', 'wc-gateway-offline' ),

					'default'     => '',

					'desc_tip'    => true,

					'options'     => $currency_code_options,

					'required' => true,

				),

				'merchant_api_domain' => array(

					'title'       => __( 'Merchant API Domain', 'wc-gateway-offline' ),

					'type'        => 'text',

					'description' => __( 'Add API Domain name without "/" end of the domain example: https://example.com', 'wc-gateway-offline' ),

					'default'     => '',

					'desc_tip'    => false,

					'required' => true,

				),

				'return_url' => array(

					'title'       => __( 'Return URL', 'wc-gateway-offline' ),

					'type'        => 'text',

					'description' => __( '', 'wc-gateway-offline' ),

					'default'     => '',

					'desc_tip'    => false,

					'required' => true,

				),

				'cancel_url' => array(

					'title'       => __( 'Cancel URL', 'wc-gateway-offline' ),

					'type'        => 'text',

					'description' => __( '', 'wc-gateway-offline' ),

					'default'     => '',

					'desc_tip'    => false,

					'required' => true,

				),

				'sale_key_name' => array(

					'title'   => __( 'Sale Webhook Key Name', 'wc-gateway-offline' ),

					'type'    => 'text',

					'label'   => __( 'Sale Webhook Key Name', 'wc-gateway-offline' ),

					'default' => ''

				),

				'recurring_key_name' => array(

					'title'   => __( 'Recurring Webhook Key Name', 'wc-gateway-offline' ),

					'type'    => 'text',

					'label'   => __( 'Recurring Webhook Key Name', 'wc-gateway-offline' ),

					'default' => ''

				),

				'sale_webhook_url' => array(

					'title'   => __( 'Sale Webhook URL', 'wc-gateway-offline' ),

					'type'    => 'text',

					'custom_attributes' => array('readyonly'),

					'description' => "<h4>".home_url()."/sipay-sale-payment-callback</h4>",

				),

				'webhook_url' => array(

					'title'   => __( 'Recurring Webhook URL', 'wc-gateway-offline' ),

					'type'    => 'text',

					'custom_attributes' => array('readyonly'),

					'description' => "<h4>".home_url()."/sipay-payment-callback</h4>",
				),

				'installment_enabled' => array(

					'title'   => __( 'Enable/Disable', 'wc-gateway-offline' ),

					'type'    => 'checkbox',

					'label'   => __( 'Please check the checkbox to disable installment block.', 'wc-gateway-offline' ),

					'default' => 'no'

				),
				'installments' => array(
					'title'   => 'Installments',
					'type'    => 'multiselect',
					'options' => $installment_options, 
					'description'       => __( 'You can choose multiple installments with Shift key.', 'wc-gateway-offline' ),
					'custom_attributes' => array(
						'data-placeholder' => __( 'Select Installments', 'wc-gateway-offline' ),
					),
				)
				)
			 );

			// $this->form_fields = array_merge($settings_fields, $installment_fields);
			

		} 


		/**

		 * Output for the order received page.

		*/

		public function thankyou_page() {

			if ( $this->instructions ) {

				echo wpautop( wptexturize( $this->instructions ) );

			}

		}



        public function getLocalizationContent($content, $language){

		    $language = strtoupper($language);

            $lang = [

                'TRY' => [

                    'card_holder_name' => 'Kart Sahibi',

                    'card_number' => 'Kart Numarası',

                    'expiry' => 'Son Kullanma Tarihi',

                    'cvv' => 'Güvenlik Numarası',

                    'single_installment' => 'Peşin',

                    'installment' => 'Taksit'

                ],

                'USD' => [

                    'card_holder_name' => 'Card Holder Name',

                    'card_number' => 'Card Number',

                    'expiry' => 'Expiry',

                    'cvv' => 'CVV',

                    'single_installment' => 'Single Installment',

                    'installment' => 'Installment'

                ]

            ];



            if (!isset($lang[$language])){

                $language = 'USD';

            }

            if (isset($lang[$language][$content])){

                $localizeContent = $lang[$language][$content];

            }else{

                $localizeContent = $content;

            }



            return $localizeContent;

        }







        public function payment_fields(){

        

			if ( $description = $this->get_description() ) {

				echo wpautop( wptexturize( $description ) );

			}

			$currency = $this->get_option( 'merchant_currency' );



			//app_secret

			$post = array(

				'app_id' => $this->get_option( 'app_id' ),

				'app_secret' => $this->get_option( 'app_secret' )

			);



			$result = wp_remote_post($this->get_option( 'merchant_api_domain' )."/ccpayment/api/token", array(

				'method' => 'POST',

				'headers' => $this->headers,

				'sslverify' => false,

				'body' => $post

			));


			if ( is_wp_error( $result ) ) 
			return;

			$response = json_decode($result['body'], true);

			if($response['status_code'] == 100){

				$this->is_3d = $response['data']['is_3d'];

                

			}

           





 			if($this->is_3d != 4 && $this->is_3d != 8){

				echo '<fieldset id="wc-' . esc_attr( $this->id ) . '-cc-form" class="wc-credit-card-form wc-payment-form" style="background:transparent;">';

			}



			if($response['status_code'] == 100){

				echo "<input type='hidden' name='sipay_token' class='sipay_token' id='sipay_token' value='".$response['data']['token']."'/>";

				if( ! empty ( WC()->cart->get_cart() )){

					foreach( WC()->cart->get_cart() as $cart_item ) {

						$cart_product_id = $cart_item['product_id'];

						$is_recurring_cart = get_post_meta($cart_product_id, "_recurring", true);

						if($is_recurring_cart == 'yes'){

							$payment_duration = get_post_meta($cart_product_id, "payment_duration", true);

							$payment_cycle = get_post_meta($cart_product_id, "payment_cycle", true);

							$payment_interval = get_post_meta($cart_product_id, "payment_interval", true);

							if(!empty($payment_duration) && !empty($payment_cycle) && !empty($payment_interval)){

								?>

						<input class="recurring_checkbox" name="recurring_options[recurring_check]" type="hidden"  value="yes">

						<input type="hidden" name="recurring_options[payment_duration]" class="payment_duration" value="<?php echo $payment_duration; ?>"/>

						<input type="hidden" name="recurring_options[payment_cycle]" class="payment_cycle" value="<?php echo $payment_cycle; ?>"/>

						<input type="hidden" name="recurring_options[payment_interval]" class="payment_interval" value="<?php echo $payment_interval; ?>"/>

								<?php

							}

						}

					}

				}

			}else{

				echo "<input type='hidden' name='sipay_token' class='sipay_token' id='sipay_token' value=''/>";

			}



				echo "<input type='hidden' name='sipay_3d' class='sipay_3d' id='sipay_3d' value='".$this->is_3d."'/>";





				if($this->is_3d != 4 && $this->is_3d != 8){

			// Add this action hook if you want your custom payment gateway to support it

			do_action( 'woocommerce_credit_card_form_start', $this->id );



			// I recommend to use inique IDs, because other gateways could already use #ccNo, #expdate, #cvc

			?>

			<p class="form-row form-row-wide">

				<label><?php echo $this->getLocalizationContent('card_holder_name', $currency) ?> <span class="required">*</span></label>

				<input id="cc_holder_name" name="cc_holder_name" class="input-text cc_holder_name" type="text" autocomplete="off">

			</p>

			<p class="form-row form-row-wide">

				<label><?php echo $this->getLocalizationContent('card_number', $currency) ?> <span class="required">*</span></label>

				<input id="cc_number" class="input-text cc_number" name="cc_number" type="text" autocomplete="off">

				<span class="sipay_spinner_blk"></span>

			</p>

			<p class="form-row form-row-first">

				<label><?php echo $this->getLocalizationContent('expiry', $currency) ?> <span class="required">*</span></label>

				<select name="expiry_month" id="expiry_month" class="input-text" style="padding:15px;">

                    <?php

                    for($i=1; $i<=12; $i++)

                        echo '<option value="'.$i.'" >'.$i.'</option>';

                    ?>

				</select>

                <select name="expiry_year" id="expiry_year" class="input-text" style="padding:15px;">

                    <?php

                    for($i=date('Y'); $i<=date('Y') + 10; $i++)

                        echo '<option value="'.$i.'" >'.$i.'</option>';

                    ?>

                </select>

			</p>

			<p class="form-row form-row-last">

				<label><?php echo $this->getLocalizationContent('cvv', $currency) ?> <span class="required">*</span></label>

				<input id="cc_cvv" class="input-text cc_cvv" name="cc_cvv" type="password" autocomplete="off" placeholder="CVV">

			</p>

			<input type="hidden" name="pos_id" class="pos_id" value=""/>

			<input type="hidden" name="pos_amount" class="pos_amount" value=""/>

			<input type="hidden" name="currency_id" class="currency_id" value=""/>

			<input type="hidden" name="campaign_id" class="campaign_id" value=""/>

			<input type="hidden" name="currency_code" class="currency_code" value=""/>

			<input type="hidden" name="allocation_id" class="allocation_id" value=""/>

			<input type="hidden" name="installments_number" class="installments_number" value=""/>

			<input type="hidden" name="hash_key" class="hash_key" value=""/>

			<div class="clear"></div>

			<?php

			$instllment = $this->get_option( 'installment_enabled' );

				$dis = '';

			if($instllment == 'yes'){

				$dis = "style='display:none'";

			}

			?>

			<p class="installments form-row form-row-wide" id="installments" <?php echo $dis ?>></p>

			<div class="clear"></div>

			<?php

			if($this->is_3d == 1){ ?>

			<p class="form-row form-row-wide">

				<input style="width:auto;" id="pay_via_3d" class="pay_via_3d" name="pay_via_3d" type="checkbox" autocomplete="off" value="yes"><strong><?php echo __('I want 3D payment option', 'wc-gateway-offline')?></strong>

			</p>

			<?php } ?>

			<?php /*<div class="recurring_block">

				<p class="form-row form-row-wide">

					<input style="width:auto;" id="recurring_checkbox" class="recurring_checkbox" name="recurring_options[recurring_check]" type="checkbox" autocomplete="off" value="yes"> <strong><?php echo __('Recurring Payment', 'wc-gateway-offline')?></strong>

				</p>

				<div class="recurring_option_fields" style="display:none;">

					<p class="form-row form-row-wide">

						<label>No of Payments <span class="required">*</span></label>

						<input type="number" name="recurring_options[payment_duration]" class="payment_duration" value=""/>

					</p>

					<p class="form-row form-row-wide">

						<label>Order Frequency Cycle <span class="required">*</span></label>

						<select name="recurring_options[payment_cycle]" class="payment_cycle">

							<option value="D">Daily</option>

							<option value="W">Weekly</option>

							<option value="M">Monthly</option>

							<option value="Y">Yearly</option>

						</select>

					</p>

					<p class="form-row form-row-wide">

						<label>Order Frequency Interval <span class="required">*</span></label>

						<input type="number" name="recurring_options[payment_interval]" class="payment_interval" value=""/>

					</p>

				</div>

			</div> */ ?>

		<?php

					

		

			do_action( 'woocommerce_credit_card_form_end', $this->id );



			echo '<div class="clear"></div></fieldset>';

				}

			

			

		}



		/*

		 * Custom CSS and JS, in most cases required only when you decided to go with a custom credit card form

		 */

		public function payment_scripts() {



				// we need JavaScript to process a token only on cart/checkout pages, right?

				if ( ! is_cart() && ! is_checkout() && ! isset( $_GET['pay_for_order'] ) ) {

					return;

				}



				// if our payment gateway is disabled, we do not have to enqueue JS too

				if ( 'no' === $this->enabled ) {

					return;

				}







				// and this is our custom JS in your plugin directory that works with token.js



				wp_register_script( 'woocommerce_sipay', plugins_url( 'js/sipay.js', __FILE__ ) );

				wp_localize_script('woocommerce_sipay', 'sipay_var', array('spinner' => plugins_url( 'images/spinner.gif', __FILE__ )));

				wp_enqueue_script('woocommerce_sipay');

				wp_enqueue_style( 'woocommerce_sipay_style', plugins_url( 'css/sipay.css', __FILE__ ) );





		}

		

		/*

		 * Custom CSS and JS, in most cases required only when you decided to go with a custom credit card form

		 */

		public function admin_payment_scripts() {

				wp_enqueue_style( 'woocommerce_sipay_style', plugins_url( 'css/sipay.css', __FILE__ ) );

		}



		/*

 		 * Fields validation, more in Step 5

		 */

		public function validate_fields() {

			if( isset($_POST[ 'cc_holder_name' ]) && empty( $_POST[ 'cc_holder_name' ]) ) {

				wc_add_notice(  'Credit card name is required!', 'error' );

				return false;

			}

			if( isset($_POST[ 'cc_number' ]) && empty( $_POST[ 'cc_number' ]) ) {

				wc_add_notice(  'Credit card number is required!', 'error' );

				return false;

			}

			if( isset($_POST[ 'expiry_month' ]) && empty( $_POST[ 'expiry_month' ]) ) {

				wc_add_notice(  'Expiry month is required!', 'error' );

				return false;

			}

			if( isset($_POST[ 'expiry_year' ]) && empty( $_POST[ 'expiry_year' ]) ) {

				wc_add_notice(  'Expiry year is required!', 'error' );

				return false;

			}

			if( isset($_POST[ 'cc_cvv' ]) && empty( $_POST[ 'cc_cvv' ]) ) {

				wc_add_notice(  'CVV is required!', 'error' );

				return false;

			}

			return true;



		}





		public function receipt_page($order_id){

			global $woocommerce;

			if ( version_compare( WOOCOMMERCE_VERSION, '2.0.0', '>=' ) ) {

				$order = new WC_Order($order_id);

			} else {

				$order = new woocommerce_order($order_id);

			}



			$payment_method= get_post_meta($order_id, '_payment_method', true);

			if($payment_method != 'sipay_payment')

			return;



			echo '<p>'.__('Thank you for your order, you will redirect to sipay.').'</p>';



			$sipay_data = get_post_meta($order_id, 'sipay_data_payment', true);





			$sipay_data['app_id'] = $this->get_option( 'app_id' );

			$sipay_data['app_secret'] = $this->get_option( 'app_secret' );



				/*$this->headers[1] = "Content-Type: application/x-www-form-urlencoded";

				$this->headers[]= "Authorization: Bearer {$sipay_data['sipay_token']}";

				$ch = curl_init();

				curl_setopt($ch, CURLOPT_URL, $this->get_option( 'merchant_api_domain' )."/ccpayment/api/pay3d" );



				curl_setopt($ch, CURLOPT_POST, true);

				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

				curl_setopt($ch, CURLOPT_POSTFIELDS, urldecode(http_build_query($sipay_data)));

				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);

				curl_setopt($ch, CURLOPT_HTTPHEADER, $this->headers);



				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);

				echo $response = curl_exec($ch);





				curl_close($ch);*/



				$formdata=array();

				foreach($sipay_data as $key => $val){

					if($key == "sipay_token"){

					$key ="Authorization";

					$val = "Bearer ".$val;

					}

					$formdata[] = "<input type='hidden' name='".$key."' value='".$val."'/>";

				}



			?>

			<div class="payment_3d_overlay"></div>

			<div class="payment_3d_popup">

			<img src="<?php echo plugins_url( 'images/spinner.gif', __FILE__ ) ?>"/>

			</div>



			<form action="<?php echo $this->get_option( 'merchant_api_domain' )."/ccpayment/api/pay3d" ?>" class="payment_3d" method="post">

				<?php echo  implode('', $formdata); ?>

			</form>

			<script>

			jQuery(".payment_3d").submit();

			</script>



			<?php









		}





		public function process_payment( $order_id ){



			if($_POST['payment_method'] != 'sipay_payment')

        		return;

			

			if ($_SERVER['REQUEST_METHOD'] === 'POST') {

				$order = wc_get_order( $order_id );



				update_post_meta( $order_id, 'sipay_payment_info', array('sipay_3d' => $_POST['sipay_3d'], 'token' => $_POST['sipay_token']));



				$invoice = array();



				if($order->get_discount_total() > 0){

					$invoice['discount'] = number_format( $order->get_discount_total(), 2, ".", "");

					$invoice['coupon'] = implode($order->get_used_coupons());

				}else{

					$invoice['discount'] =0;

					$invoice['coupon'] = '3XY8P';

				}

				$invoice['invoice_id'] = $order_id;

				$invoice['invoice_description'] = "Order with Invoice ".  $invoice['invoice_id'] ;



				$return_url=(!empty($this->get_option( 'return_url' ) )) ? add_query_arg(array('sipay_status' => 1, 'invoice_id' => $order_id), $this->get_option( 'return_url' ))  : $order->get_checkout_order_received_url();

				$invoice['return_url'] = $return_url;

				$invoice['cancel_url'] = (!empty($this->get_option( 'cancel_url' ) )) ? $this->get_option( 'cancel_url' ) : wc_get_checkout_url();







				/* Older version payment request */

				if(isset($_POST['sipay_3d']) && ($_POST['sipay_3d'] == 4 || $_POST['sipay_3d'] == 8)){

					$price = 0;
					/* Login for deduct discount amount */
					$dis_per_product_amount =0;
					if($order->get_discount_total() > 0){
						$dis_total_amount = number_format( $order->get_discount_total(), 2, ".", "");
						$item_count= count($order->get_items());
						$dis_per_product_amount = $dis_total_amount/$item_count;
					}

				foreach($order->get_items() as $item_id => $item_data){

					$product = $item_data->get_product();

					$invoice['items'][]=array(

						'name' => $product->get_name(),

						'price' => number_format( ($product->get_price()-$dis_per_product_amount), 2, ".", ""), 

						'qty' => $item_data->get_quantity(),

						'description' => ''

					);

					$price = $price+($product->get_price()*$item_data->get_quantity()-$dis_per_product_amount); 

				}



				if($order->get_shipping_total() > 0){

					$invoice['items'][] = array(

						'name' => 'Shipping Charge',

						'price' => number_format( $order->get_shipping_total(), 2, ".", ""),

						'qty' => 1,

						'description' => ''

					);

					$price = $price + $order->get_shipping_total();

				}







				if($order->get_total_tax() > 0){

					$invoice['items'][] = array(

						'name' => 'Tax',

						'price' => number_format( $order->get_total_tax(), 2, ".", ""),

						'qty' => 1,

						'description' => ''

					);

					$price = $price + $order->get_total_tax();

				}



					//$invoice['total'] = (float)$price;

					$invoice['total'] = number_format( $price, 2, ".", "");



                    //BIlling info Optional

                    $invoice['bill_address1'] = isset($_POST['billing_address_1']) ? $_POST['billing_address_1'] : '';

                    $invoice['bill_address2'] = isset($_POST['billing_address_2']) ? $_POST['billing_address_2'] : '';

                    $invoice['bill_city'] = isset($_POST['billing_city']) ? $_POST['billing_city'] : '';

                    $invoice['bill_postcode'] = isset($_POST['billing_postcode']) ? $_POST['billing_postcode'] : '';

                    $invoice['bill_state'] = isset($_POST['billing_state']) ? $_POST['billing_state'] : '';

                    $invoice['bill_country'] = isset($_POST['billing_country']) ? $_POST['billing_country'] : '';

                    $invoice['bill_email'] = isset($_POST['billing_email']) ? $_POST['billing_email'] : '';

					$invoice['bill_phone'] = isset($_POST['billing_phone']) ? $_POST['billing_phone'] : '';

					

					if(!empty($this->get_option( 'sale_key_name' )))

						$invoice['sale_web_hook_key'] = $this->get_option( 'sale_key_name' );

					

					if(isset($_POST['recurring_options']) && !empty($_POST['recurring_options']) && $_POST['recurring_options']['recurring_check'] == 'yes'){

						$invoice['order_type'] = 1;

						$invoice['recurring_payment_number'] = $_POST['recurring_options']['payment_duration'];

						$invoice['recurring_payment_cycle'] = $_POST['recurring_options']['payment_cycle'];

						$invoice['recurring_payment_interval'] = $_POST['recurring_options']['payment_interval'];

						if(!empty($this->get_option( 'recurring_key_name' )))

						$invoice['recurring_web_hook_key'] = $this->get_option( 'recurring_key_name' );

						update_post_meta($order_id, 'payment_duration', $_POST['recurring_options']['payment_duration']);

					}

					

					$invoice = json_encode($invoice);



					$post = array(

						'merchant_key' => $this->get_option( 'merchant_key' ),

						'invoice' => $invoice,

						'currency_code' =>  $this->get_option( 'merchant_currency' ),

						'name' => $_POST['billing_first_name'],

						'surname' => $_POST['billing_last_name']

					);



					$ch = curl_init();

					curl_setopt($ch, CURLOPT_URL, $this->get_option( 'merchant_api_domain' )."/ccpayment/purchase/link" );



					curl_setopt($ch, CURLOPT_POST, true);

					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

					curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

					curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);



					curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);

					$response = json_decode(curl_exec($ch),true);

					curl_close($ch);







					if ($response['status'] == 1) {

						return array(

							'result'    => 'success',

							'redirect'  => $response['link']

						);

					}else{

						wc_add_notice(  $response['error_message'], 'error' );

						return array(

							'result'   => 'fail',

							'redirect' => ''



							);

					}

				}

				/* End older version request */



				$price = 0;
				/* Login for deduct discount amount */
				$dis_per_product_amount=0;
				if($order->get_discount_total() > 0){
					$dis_total_amount = number_format( $order->get_discount_total(), 2, ".", "");
					$item_count= count($order->get_items());
					$dis_per_product_amount = $dis_total_amount/$item_count;
				}

				foreach($order->get_items() as $item_id => $item_data){

					$product = $item_data->get_product();


					$invoice['items'][]=array(

						'name' => $product->get_name(),

						'price' => number_format( ($product->get_price()-$dis_per_product_amount), 2, ".", ""), 

						'qnantity' => $item_data->get_quantity(),

						'description' => ''

					);

					$price = $price+($product->get_price()*$item_data->get_quantity());

				}



				if($order->get_shipping_total() > 0){

					$invoice['items'][] = array(

						'name' => 'Shipping Charge',

						'price' => number_format( $order->get_shipping_total(), 2, ".", ""),

						'qnantity' => 1,

						'description' => ''

					);

					$price = $price + $order->get_shipping_total();

				}







				if($order->get_total_tax() > 0){

					$invoice['items'][] = array(

						'name' => 'Tax',

						'price' => number_format( $order->get_total_tax(), 2, ".", ""),

						'qnantity' => 1,

						'description' => ''

					);

					$price = $price + $order->get_total_tax();

				}



				$invoice['total'] = number_format( $price, 2, ".", "");

				$invoice['payable_amount'] = number_format( $_POST['pos_amount'], 2, ".", "");

				$invoice['merchant_key'] = $this->get_option( 'merchant_key' );



				$invoice['pos_id'] = $_POST['pos_id'];

				$invoice['currency_id'] = $_POST['currency_id'];

				$invoice['campaign_id'] = $_POST['campaign_id'];

				$invoice['allocation_id'] = $_POST['allocation_id'];

				$invoice['installments_number'] = $_POST['installments_number'];

				$invoice['hash_key'] = $_POST['hash_key'];



				$invoice['cc_holder_name'] = $_POST['cc_holder_name'];

				$invoice['cc_no'] = $_POST['cc_number'];

				$invoice['expiry_month'] = $_POST['expiry_month'];

				$invoice['expiry_year'] = $_POST['expiry_year'];

				$invoice['cvv'] = $_POST['cc_cvv'];

				$invoice['currency_code'] = $this->get_option( 'merchant_currency' );

				

				if(((isset($_POST['sipay_3d']) && $_POST['sipay_3d'] == 1) && (isset($_POST['pay_via_3d']) && $_POST['pay_via_3d'] == "yes")) || (isset($_POST['sipay_3d']) && $_POST['sipay_3d'] == 2)){



					



						$pay_data=array(

							'sipay_token' => $_POST['sipay_token'],

							'sipay_3d' => $_POST['sipay_3d'],

							'cc_holder_name' => $_POST['cc_holder_name'],

							'cc_no' => $_POST['cc_number'],

							'expiry_month' => $_POST['expiry_month'],

							'expiry_year' => $_POST['expiry_year'],

							'cvv' => $_POST['cc_cvv'],

							'pos_id' => $_POST['pos_id'],

							'pos_amount' => $_POST['pos_amount'],

							'currency_id' => $_POST['currency_id'],

							'currency_code' => $_POST['currency_code'],

							'campaign_id' => $_POST['campaign_id'],

							'allocation_id' => $_POST['allocation_id'],

							'installments_number' => $_POST['installments_number'],

							'hash_key' => $_POST['hash_key'],

							'invoice_id' => $order_id,

							'invoice_description' => "Order with Invoice ".  $invoice['invoice_id'],

							'total' => number_format( $_POST['pos_amount'], 2, ".", ""),

							'merchant_key' => $this->get_option( 'merchant_key' ),

							'payable_amount' => number_format( $_POST['pos_amount'], 2, ".", ""),

							'return_url' => $return_url,

							'cancel_url' => (!empty($this->get_option( 'cancel_url' ) )) ? $this->get_option( 'cancel_url' ) : wc_get_checkout_url(),

							'items' => json_encode($invoice['items']),

							'name' => $_POST['billing_first_name'],

							'surname' => $_POST['billing_last_name'],

                            'bill_address1' => isset($_POST['billing_address_1']) ? $_POST['billing_address_1'] : '',

                            'bill_address2' => isset($_POST['billing_address_2']) ? $_POST['billing_address_2'] : '',

                            'bill_city' => isset($_POST['billing_city']) ? $_POST['billing_city'] : '',

                            'bill_postcode' => isset($_POST['billing_postcode']) ? $_POST['billing_postcode'] : '',

                            'bill_state' => isset($_POST['billing_state']) ? $_POST['billing_state'] : '',

                            'bill_country' => isset($_POST['billing_country']) ? $_POST['billing_country'] : '',

                            'bill_email' => isset($_POST['billing_email']) ? $_POST['billing_email'] : '',

                            'bill_phone' => isset($_POST['billing_phone']) ? $_POST['billing_phone'] : ''

						);

						/* Login for deduct discount amount */
						if($invoice['discount'] > 0)
							$pay_data['discount'] = $invoice['discount'];


//print_r($invoice); print_r($pay_data); exit;
						if(!empty($this->get_option( 'sale_key_name' )))

							$pay_data['sale_web_hook_key'] = $this->get_option( 'sale_key_name' );



						if(isset($_POST['recurring_options']) && !empty($_POST['recurring_options']) && $_POST['recurring_options']['recurring_check'] == 'yes'){

							$pay_data['order_type'] = 1;

							$pay_data['recurring_payment_number'] = $_POST['recurring_options']['payment_duration'];

							$pay_data['recurring_payment_cycle'] = $_POST['recurring_options']['payment_cycle'];

							$pay_data['recurring_payment_interval'] = $_POST['recurring_options']['payment_interval'];

							if(!empty($this->get_option( 'recurring_key_name' )))

							$pay_data['recurring_web_hook_key'] = $this->get_option( 'recurring_key_name' );

							update_post_meta($order_id, 'payment_duration', $_POST['recurring_options']['payment_duration']);

						}



						update_post_meta($order_id, 'sipay_data_payment', $pay_data);



						$validate_fields=array('sipay_token', 'pos_amount', 'currency_id', 'currency_code', 'merchant_key');

						foreach($validate_fields as $val){

							if(empty($pay_data[$val])){

								wc_add_notice(  ucfirst($val)." can not be empty!", 'error' );

								return array(

									'result'   => 'fail',

									'redirect' => wc_get_checkout_url()

								);

							}

						}



						return array(

							'result' => 'success',

							'redirect' => add_query_arg('order', $order->id, add_query_arg('key', $order->order_key, $order->get_checkout_payment_url( true )))

						);



				}



				



				$this->headers[]= "Authorization: Bearer {$_POST['sipay_token']}";



				$invoice['app_id'] = $this->get_option( 'app_id' );

				$invoice['app_secret'] = $this->get_option( 'app_secret' );

				$invoice['name'] = $_POST['billing_first_name'];

				$invoice['surname'] = $_POST['billing_last_name'];



                //BIlling info Optional

                $invoice['bill_address1'] = isset($_POST['billing_address_1']) ? $_POST['billing_address_1'] : '';

                $invoice['bill_address2'] = isset($_POST['billing_address_2']) ? $_POST['billing_address_2'] : '';

                $invoice['bill_city'] = isset($_POST['billing_city']) ? $_POST['billing_city'] : '';

                $invoice['bill_postcode'] = isset($_POST['billing_postcode']) ? $_POST['billing_postcode'] : '';

                $invoice['bill_state'] = isset($_POST['billing_state']) ? $_POST['billing_state'] : '';

                $invoice['bill_country'] = isset($_POST['billing_country']) ? $_POST['billing_country'] : '';

                $invoice['bill_email'] = isset($_POST['billing_email']) ? $_POST['billing_email'] : '';

				$invoice['bill_phone'] = isset($_POST['billing_phone']) ? $_POST['billing_phone'] : '';

				

				if(!empty($this->get_option( 'sale_key_name' )))

					$invoice['sale_web_hook_key'] = $this->get_option( 'sale_key_name' );

				

				if(isset($_POST['recurring_options']) && !empty($_POST['recurring_options']) && $_POST['recurring_options']['recurring_check'] == 'yes'){

					$invoice['order_type'] = 1;

					$invoice['recurring_payment_number'] = $_POST['recurring_options']['payment_duration'];

					$invoice['recurring_payment_cycle'] = $_POST['recurring_options']['payment_cycle'];

					$invoice['recurring_payment_interval'] = $_POST['recurring_options']['payment_interval'];

					if(!empty($this->get_option( 'recurring_key_name' )))

					$invoice['recurring_web_hook_key'] = $this->get_option( 'recurring_key_name' );

					update_post_meta($order_id, 'payment_duration', $_POST['recurring_options']['payment_duration']);



				}

				



				$ch = curl_init();

				curl_setopt($ch, CURLOPT_URL, $this->get_option( 'merchant_api_domain' )."/ccpayment/api/pay" );



				curl_setopt($ch, CURLOPT_POST, true);

				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

				curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($invoice));

				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);

				curl_setopt($ch, CURLOPT_HTTPHEADER, $this->headers);



				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);

				$response = json_decode(curl_exec($ch),true);

				curl_close($ch);

				

				if ($response['status_code'] == 100 ) {

										

					$status = 'wc-' === substr( $this->order_status, 0, 3 ) ? substr( $this->order_status, 3 ) : $this->order_status;

					// Set order status

					$order->update_status( $status, __( 'Checkout with Sipay payment. ', $this->domain ) );

				

					$order->add_order_note(sprintf( __( 'Sipay payment complete', 'wc-gateway-offline' )));

					WC()->cart->empty_cart();

					

					$order->reduce_order_stock();

					

					return array(

						'result'    => 'success',

						'redirect'  => $order->get_checkout_order_received_url()

					);

				}else{

					$order->update_status('failed');

					wc_add_notice(  $response['status_description'], 'error' );

					return array(

						'result'   => 'fail',

						'redirect' => wc_get_checkout_url()



						);

				}

			}

		}













	}



	add_filter( 'woocommerce_payment_gateways', 'wc_sipay_add_to_gateways');

	function wc_sipay_add_to_gateways( $gateways ) {

		$gateways[] = 'WC_Gateway_Sipay';

		return $gateways;

	}



	add_action('wp_ajax_get_installment', 'get_installment');

	add_action('wp_ajax_nopriv_get_installment', 'get_installment');



	function get_installment(){

		

		if(!empty($_POST['cc_number']) && !empty($_POST['token'])){

			global $woocommerce;

			$sipay_pay =new WC_Gateway_Sipay();

			/* getpos request */

			$pos_post = array(

				'credit_card' => $_POST['cc_number'],

				'amount' => $woocommerce->cart->total,

				"currency_code" => $sipay_pay->get_option( 'merchant_currency' ),

				"merchant_key" => $sipay_pay->get_option( 'merchant_key' ),

				'app_id' => $sipay_pay->get_option( 'app_id' ),

				'app_secret' => $sipay_pay->get_option( 'app_secret' )

			);

			if(!empty($_POST['recurring_options']['recurring_check']) && $_POST['recurring_options']['recurring_check'] == 'yes'){

				$pos_post['is_recurring'] = 1;

			}

			$headers = array(

				'Accept: application/json',

				'Content-Type: application/json',

				"Authorization: Bearer {$_POST['token']}"

			);
			$ch = curl_init();

			curl_setopt($ch, CURLOPT_URL, $sipay_pay->get_option( 'merchant_api_domain' )."/ccpayment/api/getpos" );

			curl_setopt($ch, CURLOPT_POST, true);

			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($pos_post));

			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);

			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);



			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);

			$get_pos_response = json_decode(curl_exec($ch),true);
//print_r($get_pos_response); exit;
			curl_close($ch);
			if($get_pos_response['status_code'] == 100){

				$html='';

				if(!empty($get_pos_response['data'])){

					$pos_id ='';

					$pos_amt='';

					$currency_id="";

					$campaign_id="";

					$allocation_id="";

					$installments_number="";

					$hash_key="";

					$currency_code='';

					$i=0;

					$html ="<div class='row'>";

					$installments_count = count($get_pos_response['data']);

					foreach($get_pos_response['data'] as $val){

						if($val['installments_number'] != 1){
							if(in_array($val['installments_number'], $sipay_pay->get_option( 'installments'))){
								$i++;
								continue;
							}
						}

						$active_cls="";

//						$inst= ($i+1)." Installment";

                        $currency_code=$val['currency_code'];

						if($i == 0){

							$active_cls='active';

							$pos_id = $val['pos_id'];

							$pos_amt = $val['amount_to_be_paid'];

							$currency_id=$val['currency_id'];

							$campaign_id=$val['campaign_id'];

							$allocation_id=$val['allocation_id'];

							$installments_number=$val['installments_number'];
                            $hash_key = $val['hash_key'];



							$inst= $sipay_pay->getLocalizationContent('single_installment',$currency_code);

						}else{

						    $inst = ($i+1)." ".$sipay_pay->getLocalizationContent('installment',$currency_code);

                        }

						$html .="<div class='single-installment ".$active_cls."' data-posid='".$val["pos_id"]."' data-amount='".$val["amount_to_be_paid"]."' data-currency_id='".$val["currency_id"]."' data-campaign_id='".$val["campaign_id"]."' data-allocation_id='".$val["allocation_id"]."' data-installments_number='".$val["installments_number"]."' data-hash_key='".$val["hash_key"]."' data-currency_code='".$val["currency_code"]."'>

						<div class='sipay_heading'>".$inst."</div>

						<div class='sipay_amount'>".$val['amount_to_be_paid']." ".$val['currency_code']."</div>

						<div class='sipay_installment_number'>".($i+1)." X</div>

						<div class='sipay_total_amount'>".number_format(($val['amount_to_be_paid']/($i+1)), 2)." ".$val['currency_code']."</div></div>";

						$i++;

					}

					$html .="</div>";

					echo json_encode(array('data' => $html, 'pos_id' => $pos_id, 'pos_amt' => $pos_amt, 'currency_id' => $currency_id, 'campaign_id' => $campaign_id, 'allocation_id' => $allocation_id, 'installments_number' => $installments_number, 'hash_key' => $hash_key, 'currency_code' => $currency_code));

					exit;

				}

				

			}

		}



		/* end getpos request */

		echo json_encode(array('data' => '', 'pos_id' => '', 'pos_amt' => '', 'currency_id' => '', 'campaign_id' => '', 'allocation_id' => '', 'installments_number' => '', 'hash_key' => '', 'currency_code' => ''));

		exit;

	}



	add_filter( 'woocommerce_available_payment_gateways', 'sipay_check_details_manager' );

 

	function sipay_check_details_manager( $available_gateways ) {

		$sipay_pay =new WC_Gateway_Sipay();

		if ( isset( $available_gateways['sipay_payment'] ) && empty($sipay_pay->get_option( 'merchant_key' )) && empty($sipay_pay->get_option( 'app_id' )) && empty($sipay_pay->get_option( 'app_secret' )) && empty($sipay_pay->get_option( 'merchant_api_domain' ))) {

			unset( $available_gateways['sipay_payment'] );

		} 

		return $available_gateways;

	}





}



add_action('template_redirect', "redirect_on_checkoutpage_show_error");

function redirect_on_checkoutpage_show_error(){

	if(isset($_REQUEST['error']) && !empty($_REQUEST['error']) && !is_checkout()){

		wc_add_notice(  $_REQUEST['error'], 'error' );

		wp_redirect(wc_get_checkout_url());

		exit;

	}

}





add_action('init', 'handle_wc_api');



function handle_wc_api(){

	if(isset($_REQUEST['invoice_id']) && isset($_REQUEST['sipay_status']) ){

	$sipay_pay =new WC_Gateway_Sipay();

	 $order_id = $_REQUEST['invoice_id']; 

	$sipay_3d = get_post_meta($order_id, 'sipay_payment_info', true);

	$order = wc_get_order( $order_id );





	if(isset($_REQUEST['sipay_status']) && $_REQUEST['sipay_status'] != 1){

		wc_add_notice('Payment Failed!', 'error' );

		$order->update_status('failed');

		if($_SERVER['REQUEST_METHOD'] === 'GET'){

			$redirect_url = wc_get_checkout_url();

			wp_redirect( $redirect_url );

		}

		exit;

	}



	

	if($order->get_status() == 'completed'){

		if($_SERVER['REQUEST_METHOD'] === 'GET')

			wp_redirect( $order->get_checkout_order_received_url() );

		exit;

	}

	

		

	if (isset($_REQUEST['sipay_status']) && $_REQUEST['sipay_status'] == 1) {

		

		$token_post = array(

			'app_id' =>  $sipay_pay->get_option( 'app_id' ),

			'app_secret' => $sipay_pay->get_option( 'app_secret' )

		);

	   

		$result = wp_remote_post($sipay_pay->get_option( 'merchant_api_domain' )."/ccpayment/api/token", array(

			'method' => 'POST',

			'sslverify' => false,

			'body' => $token_post

		));


		if ( is_wp_error( $result ) ) 
		return;

		$tok = json_decode($result['body'], true);



		if($sipay_3d['sipay_3d'] == 4 || $sipay_3d['sipay_3d'] == 8){

        

			$post = array(

				'merchant_key' =>$sipay_pay->get_option( 'merchant_key' ),

// 				'token' => $tok['data']['token'],

                'invoice_id' => $order_id

			);

			

			$url = $sipay_pay->get_option( 'merchant_api_domain' )."/ccpayment/purchase/status";

		}else{

			$sipay_data = get_post_meta($order_id, 'sipay_data_payment', true);

			

			$sipay_pay->headers[]= "Authorization: Bearer {$tok['data']['token']}";

			

			$post = array(

				'merchant_key' =>$sipay_pay->get_option( 'merchant_key' ),

				'invoice_id' => $order_id

			);

			$post = json_encode($post);

			

			$url = $sipay_pay->get_option( 'merchant_api_domain' )."/ccpayment/api/checkstatus";

		}

		

		





	

		$ch = curl_init();

		curl_setopt($ch, CURLOPT_URL, $url );

		curl_setopt($ch, CURLOPT_POST, true);

		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);

		if($sipay_3d['sipay_3d'] != 4 && $sipay_3d['sipay_3d'] != 8){

			curl_setopt($ch, CURLOPT_HTTPHEADER, $sipay_pay->headers);

		}

		$response = json_decode(curl_exec($ch),true);

		curl_close($ch);

		

		

	 

		if ($response['status_code'] == 100) {

				$order->payment_complete();

				$status = 'wc-' === substr( $sipay_pay->order_status, 0, 3 ) ? substr( $sipay_pay->order_status, 3 ) : $sipay_pay->order_status;

			if(isset($response['recurring_plan_code']) && !empty($response['recurring_plan_code'])){

				update_post_meta($order->get_id(), 'plan_code', $response['recurring_plan_code']);

				update_post_meta($order->get_id(), 'recurring_number', 1);

				$order->add_order_note(sprintf( __( 'Plan code for this order is '.$response['recurring_plan_code'].' and Recurring payment number is 1/'.get_post_meta($order->get_id(), 'payment_duration', true), 'wc-gateway-offline' )));

			}

			

			

					// Set order status

				   $order->update_status( $status, __( 'Checkout with Sipay payment. ', $sipay_pay->domain ) );

				$order->add_order_note(sprintf( __( 'Sipay payment complete', 'wc-gateway-offline' )));

				WC()->mailer()->emails['WC_Email_Customer_'.ucfirst($status).'_Order']->trigger($order_id);

				WC()->mailer()->emails['WC_Email_New_Order']->trigger($order_id);

				WC()->cart->empty_cart();

				$order->reduce_order_stock();

				if($_SERVER['REQUEST_METHOD'] === 'GET'){

					$redirect_url = $order->get_checkout_order_received_url();

					wp_redirect( $redirect_url );

				}

				exit;

			

		}else{

			wc_add_notice(  $response['message'], 'error' );

			$order->update_status('failed');

			if($_SERVER['REQUEST_METHOD'] === 'GET'){

				$redirect_url = wc_get_checkout_url();

				wp_redirect( $redirect_url );

			}

			exit;

		}

	}	

}		

}





function wps_recurring_payment_webhook_rule(){

	add_rewrite_rule( "^sipay-payment-callback/?" ,"index.php?pagename=sipay-payment-callback", "top");

	add_rewrite_rule( "^sipay-sale-payment-callback/?" ,"index.php?pagename=sipay-sale-payment-callback", "top");

	flush_rewrite_rules(false);

}



add_action("init", "wps_recurring_payment_webhook_rule");



/**

 * Webhook for recurring payment 

 * */

function get_sipay_recurring_payment_response(){

	global $wp;

	

	if (isset($wp->query_vars["pagename"]) && $wp->query_vars["pagename"] == "sipay-sale-payment-callback") {	

		handle_wc_api();

	}

	

	if (isset($wp->query_vars["pagename"]) && $wp->query_vars["pagename"] == "sipay-payment-callback") {

 

		/* Checking invoice id and recurring number */

		if(isset($_POST) && $_POST['invoice_id'] > 0 && $_POST['recurring_number'] > 0){

        

		/* creae an object for sipay payment to get setting from admin */

        $sipay_pay =new WC_Gateway_Sipay();

		

		/* Checking admin side merchant key with receiving merchant key, if both are same, it mean's it correct request */

		if($sipay_pay->get_option( 'merchant_key' ) != $_POST['merchant_key']){

			echo json_encode(array('msg' => 'Merchant key is invalid or did not match!'));

			exit;

		}

        

		/* Get token using api the hit recurring payment status api to know current payment status */	

        	$post = array(

				'app_id' =>  $sipay_pay->get_option( 'app_id' ),

				'app_secret' => $sipay_pay->get_option( 'app_secret' )

			);

           

			$result = wp_remote_post($sipay_pay->get_option( 'merchant_api_domain' )."/ccpayment/api/token", array(

				'method' => 'POST',

				'sslverify' => false,

				'body' => $post

			));


			if ( is_wp_error( $result ) ) 
				return;

			$tok = json_decode($result['body'], true);

			 

			

			$order_id = $_POST['invoice_id'];

			$post = get_post($order_id);

			$original_order = wc_get_order( $order_id );	

			$plan_code = $_POST['plan_code'];

				

			$sipay_pay->headers[]= "Authorization: Bearer {$tok['data']['token']}";

				

			$post_data = array(

				'merchant_key' => $_POST['merchant_key'],

				'recurring_number' => $_POST['recurring_number'],

				'plan_code' => $plan_code

			);

			$url = $sipay_pay->get_option( 'merchant_api_domain' )."/ccpayment/api/recurringPlan/query";



		

			$ch = curl_init();

			curl_setopt($ch, CURLOPT_URL, $url );

			curl_setopt($ch, CURLOPT_POST, true);

			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_data));

			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);

			curl_setopt($ch, CURLOPT_HTTPHEADER, $sipay_pay->headers);

			

			$response = json_decode(curl_exec($ch),true);

			

			curl_close($ch);

			 

			if ($response['status_code'] == 100) {

				

				/* Get the current payment status sucess/fail */

				$rec_status = '';

				$is_recurring_exist=0;

				if(!empty($response['transactionHistories'])){

					foreach($response['transactionHistories'] as $trans){

						if($trans['recurring_number'] == $_POST['recurring_number']){

							$rec_status = $trans['status'];

							$is_recurring_exist=1;

						}

					}

				}

				if(!$is_recurring_exist){

					echo json_encode(array('msg' => 'Invalid recurring number!'));

					exit;

				}

				

				/* if recurring number is 1 it's first payment so i just update the status */

				if( $_POST['recurring_number'] == 1){

					

					if($rec_status == 'Success')

						$original_order->update_status('completed');

					if($rec_status == 'Failed')

						$original_order->update_status('failed');

					

					echo json_encode(array('msg' => 'Order Updated successfully'));

					exit;

				}

				

				/* Checking existing order if any order have receiving recurring number then i just update the order status */

				$arr = array(

					'post_type' => 'shop_order',

					'post_status' => 'any',

					'posts_per_page' => '-1',

					'post_parent' => $order_id,

					'meta_key' => 'recurring_number',

					'meta_value' => $_POST['recurring_number']

				);

			

				$rec_post = get_posts($arr);

				

				if(!empty($rec_post)){

					$rec_order = wc_get_order($rec_post[0]->ID);

					if($rec_status == 'Success')

						$rec_order->update_status('completed');

					if($rec_status == 'Failed')

						$rec_order->update_status('failed');

					

					echo json_encode(array('msg' => 'Order Updated successfully'));

					exit;

				}



				

				/* if there is no exiting order with receiving recurring number then it will generate a new order id and update the status according to payment status */

				$new_post_date      = current_time( 'mysql' );

				$new_post_date_gmt  = get_gmt_from_date( $new_post_date );



				$order_data =  array(

					'post_author'   => $post->post_author,

					'post_date'     => $new_post_date,

					'post_date_gmt' => $new_post_date_gmt,

					'post_type'     => 'shop_order',

					'post_parent' => $order_id,

					'post_title'    => sprintf( __( 'Order &ndash; %s', 'woocommerce' ), strftime( _x( '%b %d, %Y @ %I:%M %p', 'Order date parsed by strftime', 'woocommerce' ), strtotime( $post_date ) ) ),

					'post_name' => sanitize_title( sprintf( __( 'Order &ndash; %s', 'woocommerce' ), strftime( _x( '%b %d, %Y @ %I:%M %p', 'Order date parsed by strftime', 'woocommerce' ), strtotime( $post_date) ) ) ),

					'post_status'   => 'wc-on-hold',

					'ping_status'   => 'closed',

					'post_password' => uniqid( 'order_' ),   // Protects the post just in case

					'post_modified'             => $new_post_date,

					'post_modified_gmt'         => $new_post_date_gmt

				);



				$new_post_id = wp_insert_post( $order_data, true ); 



				if ( !is_wp_error( $new_post_id ) ){

					$new_order = new WC_Order($new_post_id);

					update_post_meta( $new_post_id, '_order_shipping',         get_post_meta($order_id, '_order_shipping', true) );

					update_post_meta( $new_post_id, '_order_discount',         get_post_meta($order_id, '_order_discount', true) );

					update_post_meta( $new_post_id, '_cart_discount',          get_post_meta($order_id, '_cart_discount', true) );

					update_post_meta( $new_post_id, '_order_tax',              get_post_meta($order_id, '_order_tax', true) );

					update_post_meta( $new_post_id, '_order_shipping_tax',     get_post_meta($order_id, '_order_shipping_tax', true) );

					update_post_meta( $new_post_id, '_order_total',            get_post_meta($order_id, '_order_total', true) );



					update_post_meta( $new_post_id, '_order_key',              'wc_' . apply_filters('woocommerce_generate_order_key', uniqid('order_') ) );

					update_post_meta( $new_post_id, '_customer_user',          get_post_meta($order_id, '_customer_user', true) );

					update_post_meta( $new_post_id, '_order_currency',         get_post_meta($order_id, '_order_currency', true) );

					update_post_meta( $new_post_id, '_prices_include_tax',     get_post_meta($order_id, '_prices_include_tax', true) );

					update_post_meta( $new_post_id, '_customer_ip_address',    get_post_meta($order_id, '_customer_ip_address', true) );

					update_post_meta( $new_post_id, '_customer_user_agent',    get_post_meta($order_id, '_customer_user_agent', true) );



					/* billing fields */



					update_post_meta( $new_post_id, '_billing_city',           get_post_meta($order_id, '_billing_city', true));

					update_post_meta( $new_post_id, '_billing_state',          get_post_meta($order_id, '_billing_state', true));

					update_post_meta( $new_post_id, '_billing_postcode',       get_post_meta($order_id, '_billing_postcode', true));

					update_post_meta( $new_post_id, '_billing_email',          get_post_meta($order_id, '_billing_email', true));

					update_post_meta( $new_post_id, '_billing_phone',          get_post_meta($order_id, '_billing_phone', true));

					update_post_meta( $new_post_id, '_billing_address_1',      get_post_meta($order_id, '_billing_address_1', true));

					update_post_meta( $new_post_id, '_billing_address_2',      get_post_meta($order_id, '_billing_address_2', true));

					update_post_meta( $new_post_id, '_billing_country',        get_post_meta($order_id, '_billing_country', true));

					update_post_meta( $new_post_id, '_billing_first_name',     get_post_meta($order_id, '_billing_first_name', true));

					update_post_meta( $new_post_id, '_billing_last_name',      get_post_meta($order_id, '_billing_last_name', true));

					update_post_meta( $new_post_id, '_billing_company',        get_post_meta($order_id, '_billing_company', true));



					/* Shipping fields */



					update_post_meta( $new_post_id, '_shipping_country',       get_post_meta($order_id, '_shipping_country', true));

					update_post_meta( $new_post_id, '_shipping_first_name',    get_post_meta($order_id, '_shipping_first_name', true));

					update_post_meta( $new_post_id, '_shipping_last_name',     get_post_meta($order_id, '_shipping_last_name', true));

					update_post_meta( $new_post_id, '_shipping_company',       get_post_meta($order_id, '_shipping_company', true));

					update_post_meta( $new_post_id, '_shipping_address_1',     get_post_meta($order_id, '_shipping_address_1', true));

					update_post_meta( $new_post_id, '_shipping_address_2',     get_post_meta($order_id, '_shipping_address_2', true));

					update_post_meta( $new_post_id, '_shipping_city',          get_post_meta($order_id, '_shipping_city', true));

					update_post_meta( $new_post_id, '_shipping_state',         get_post_meta($order_id, '_shipping_state', true));

					update_post_meta( $new_post_id, '_shipping_postcode',      get_post_meta($order_id, '_shipping_postcode', true));



					/* order items */

					

					/* update recurring number */

					

					

					update_post_meta($new_post_id, 'recurring_number', $_POST['recurring_number']);

					update_post_meta($new_post_id, 'plan_code', $plan_code);



					

				

					foreach($original_order->get_items() as $item_id => $item){

						$itemName = $item->get_name();

						$qty =		$item->get_quantity();

						$lineTotal = $item->get_total();

						$lineTax = $item->get_total_tax();

						$productID = $item->get_product_id();

			

						$item_new_id = wc_add_order_item( $new_post_id, array(

								'order_item_name'       => $itemName,

								'order_item_type'       => 'line_item'

						) );

			

						wc_add_order_item_meta( $item_new_id, '_qty', $qty );

						wc_add_order_item_meta( $item_new_id, '_tax_class', $item->get_tax_class() );

						wc_add_order_item_meta( $item_new_id, '_product_id', $productID );

						wc_add_order_item_meta( $item_new_id, '_variation_id', $item->get_variation_id() );

						wc_add_order_item_meta( $item_new_id, '_line_subtotal', wc_format_decimal( $lineTotal ) );

						wc_add_order_item_meta( $item_new_id, '_line_total', wc_format_decimal( $lineTotal ) );

						wc_add_order_item_meta( $item_new_id, '_line_tax', wc_format_decimal( $lineTax ) );

						wc_add_order_item_meta( $item_new_id, '_line_subtotal_tax', wc_format_decimal(  $item->get_subtotal_tax() ) );

					}

				



					/* shipping */

					$original_order_shipping_items = $original_order->get_items('shipping');



					foreach ( $original_order_shipping_items as $original_order_shipping_item ) {

						$item_id = wc_add_order_item( $new_post_id, array(

							'order_item_name'       => $original_order_shipping_item['name'],

							'order_item_type'       => 'shipping'

						) );

						if ( $item_id ) {

							wc_add_order_item_meta( $item_id, 'method_id', $original_order_shipping_item['method_id'] );

							wc_add_order_item_meta( $item_id, 'cost', wc_format_decimal( $original_order_shipping_item['cost'] ) );

						}

					}



					/* coupon */



					$original_order_coupons = $original_order->get_items('coupon');

					foreach ( $original_order_coupons as $original_order_coupon ) {

						$item_id = wc_add_order_item( $new_post_id, array(

							'order_item_name'       => $original_order_coupon['name'],

							'order_item_type'       => 'coupon'

						) );

						// Add line item meta

						if ( $item_id ) {

							wc_add_order_item_meta( $item_id, 'discount_amount', $original_order_coupon['discount_amount'] );

						}

					}

					$new_order->calculate_totals();

					$updateNote = 'This order was duplicated from order ' . $order_id . ' and Plan code is '.$plan_code."Recurring payment number is ". $_POST['recurring_number']."/".get_post_meta($order_id, 'payment_duration', true);

					$new_order->add_order_note($updateNote);

					

					if($rec_status == 'Success')

						$new_order->update_status('completed');

					if($rec_status == 'Failed')

						$new_order->update_status('failed');

					

					echo json_encode(array('msg' => 'Order Created successfully'));

					exit;

				}



			}

		}



		exit;

	}

}

add_action('parse_request', 'get_sipay_recurring_payment_response', 0);



add_filter( 'product_type_options', 'add_new_recurring_product_type' );



function add_new_recurring_product_type( $types ){

	

	$types['recurring'] = array(

					'id'            => '_recurring',

					'wrapper_class' => 'show_if_simple',

					'label'         => __( 'Recurring', 'woocommerce' ),

					'description'   => __( 'Product will be set as recurring', 'woocommerce' ),

					'default'       => 'no',

				);

	

 return $types;

}



function add_custom_class_script_for_recurring() {



	?><script>

	jQuery( document ).ready( function( $ ) {



		$( 'input#_recurring' ).change( function() {

			var is_gift_card = $( 'input#_recurring:checked' ).size();



			$( '.show_if_recurring' ).hide();

			$( '.show_if_recurring' ).hide();



			if ( is_gift_card ) {

				$( '.hide_if_recurring' ).hide();

			}

			if ( is_gift_card ) {

				$( '.show_if_recurring' ).show();

			}

		});

		$( 'input#_recurring' ).trigger( 'change' );

	});

</script><?php



}

add_action( 'admin_head', 'add_custom_class_script_for_recurring' );



add_action("save_post_product", "save_recurring_checkbox_value", 10, 3);

function save_recurring_checkbox_value($post_ID, $product, $update) {



    update_post_meta($product->ID, "_recurring", isset($_POST["_recurring"]) ? "yes" : "no");



}



add_filter('woocommerce_product_data_tabs', 'sipay_recurring_product_settings_tabs' );

function sipay_recurring_product_settings_tabs( $tabs ){



 

	$tabs['sipay_recurring'] = array(

		'label'    => 'Recurring',

		'target'   => 'sipay_recurring_product_data',

		'class'    => array('show_if_recurring'),

		//'priority' => 21,

	);

	return $tabs;

 

}



add_action( 'woocommerce_product_data_panels', 'sipay_recurring_product_panels' );

function sipay_recurring_product_panels(){

 

	echo '<div id="sipay_recurring_product_data" class="panel woocommerce_options_panel hidden">';

 

	woocommerce_wp_text_input( array(

		'id'                => 'payment_duration',

		'value'             => get_post_meta( get_the_ID(), 'payment_duration', true ),

		'label'             => 'No of Payments',

		'description'       => ''

	) );

 

	woocommerce_wp_select( array(

		'id'          => 'payment_cycle',

		'value'       => get_post_meta( get_the_ID(), 'payment_cycle', true ),

		//'wrapper_class' => 'show_if_downloadable',

		'label'       => 'Order Frequency Cycle',

		'options'     => array( '' => 'Please select', 'D' => 'Daily', 'M' => 'Monthly', 'Y' => 'Yearly'),

	) );

	

	woocommerce_wp_text_input( array(

		'id'                => 'payment_interval',

		'value'             => get_post_meta( get_the_ID(), 'payment_interval', true ),

		'label'             => 'Order Frequency Interval',

		'description'       => ''

	) );

 

	echo '</div>';

 

}



add_action( 'woocommerce_process_product_meta', 'sipay_recurring_save_fields', 10, 2 );

function sipay_recurring_save_fields( $id, $post ){

	update_post_meta( $id, 'payment_duration', $_POST['payment_duration'] );

	update_post_meta( $id, 'payment_cycle', $_POST['payment_cycle'] );

	update_post_meta( $id, 'payment_interval', $_POST['payment_interval'] );

}



function remove_all_cart_item_if_recurring_product_add( $valid, $product_id, $quantity ) {

	$is_recurring = get_post_meta($product_id, "_recurring", true);

    if( $is_recurring == 'yes'){

		if(!WC()->cart->is_empty()){

			WC()->cart->empty_cart();

			wc_add_notice( "You cannot have another item in your cart for recurring payments.", 'error' );

		}

    }else{

		if( ! empty ( WC()->cart->get_cart() )){

			foreach( WC()->cart->get_cart() as $cart_item ) {

                $cart_product_id = $cart_item['product_id'];

				$is_recurring_cart = get_post_meta($cart_product_id, "_recurring", true);

				if( $is_recurring_cart == 'yes'){

					//WC()->cart->empty_cart();

        			wc_add_notice( "You cannot have another item in your cart for recurring payments.", 'error' );

					return false;

				}

			}

		}

	}

	

	



    return $valid;



}

add_filter( 'woocommerce_add_to_cart_validation', 'remove_all_cart_item_if_recurring_product_add', 10, 3 );



function sipay_recurring_product_sold_individually( $individually, $product ){

	 $is_recurring = get_post_meta($product->id, "_recurring", true);

	

	if($is_recurring == 'yes')

		return true;

	return $individually;

}

add_filter( 'woocommerce_is_sold_individually', 'sipay_recurring_product_sold_individually', 10, 2 );



//add_action('woocommerce_before_add_to_cart_quantity', 'woocommerce_before_add_to_cart_quantity_sipay');

function woocommerce_before_add_to_cart_quantity_sipay(){

	global $product;

	$payment_duration =get_post_meta( $product->get_id(), 'payment_duration', true );

	$payment_cycle= get_post_meta( $product->get_id(), 'payment_cycle', true);

	$payment_interval = get_post_meta( $product->get_id(), 'payment_interval', true );

	

	if(empty($payment_duration) || empty($payment_cycle) || empty($payment_interval))

		return;

	

	if($payment_cycle == "D")

		$payment_cycle ="Daily";

	elseif($payment_cycle == "M")

		$payment_cycle ="Monthly";

	elseif($payment_cycle == "Y")

		$payment_cycle ="Yearly";

	

	echo "<p>Payment Duration: ".$payment_duration."</p>";

	echo "<p>Payment Cycle: ".$payment_cycle."</p>";

	echo "<p>Payment Interval: ".$payment_interval."</p>";

}