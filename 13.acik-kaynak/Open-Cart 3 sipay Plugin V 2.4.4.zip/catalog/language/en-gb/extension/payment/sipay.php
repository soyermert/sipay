<?php
// Text
$_['text_title']           = 'Kredi ve Banka Kartı - Sipay';
