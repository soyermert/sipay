<?php
class ControllerExtensionPaymentSipay extends Controller {
	public function index() {
		
		$this->load->language('extension/payment/sipay');
		
		$result = $this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "recurring_product_fields'");
		
		if($result->num_rows==0)
		{		
			$this->db->query("CREATE TABLE IF NOT EXISTS `". DB_PREFIX . "recurring_product_fields` (
				id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
				product_id INT(11)  NOT NULL,
				no_of_payments INT(11) NOT NULL,
				order_frequency_cycle INT(11) NOT NULL,
				order_frequency_interval INT(11) NOT NULL,
				status INT(11)				
				)");
		}
		
		
		return $this->process();
		//return;

		//$data['button_confirm'] = $this->language->get('button_confirm');
		//$data['action'] = $this->url->link('extension/payment/sipay/process', '', true);

		//return $this->load->view('extension/payment/sipay', $data);
	}
	
	public function installation_api()
	{
		echo "To get Authorization Token <br/><br/>";
		$post_url = $this->config->get('payment_sipay_merchant_domainhwe').'/ccpayment/api/token';
		echo "I used this URL to get token : ".$post_url.'<br/><br/>';
		$post = array(
		        'app_secret' => $this->config->get('payment_sipay_app_secret'), //sipay test merchant
				'app_id' => $this->config->get('payment_sipay_app_id')
		    );
		echo "I used these details : <br/><br/>";
		echo "App Secret : ".$post['app_secret'].'<br/><br/>';
		echo "App ID : ".$post['app_id'].'<br/><br/>';
			
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $post_url);
		
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
		
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
		$response = json_decode(curl_exec($ch),true);
		
		curl_close($ch);
		
		echo "I got This token : Bearer ".$response['data']['token'].'<br/><br/><hr/>';
		
		echo "To get installation number <br/><br/>";
		$url = $this->config->get('payment_sipay_merchant_domainhwe').'/ccpayment/api/installations';
		echo "I used this URL : ".$url.'<br/><br/>';
		$headers=array(
			'Accept: application/json',
			'Content-Type: application/json',
			'Authorization: Bearer '.$response['data']['token']
			);
		echo "I used these detail in header <br/><br/>";
		echo $headers[0].'<br/>'.$headers[1].'<br/>'.$headers[2];
		$post_content = array(
			'merchant_key' => $this->config->get('payment_sipay_merchant_key')
		);
		echo "<br/><br/>I used this merchant key : ".$post_content['merchant_key'].'<br/><br/>';
		//print_r($post_content);
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url );

		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post_content));
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
		$get_pos_response = json_decode(curl_exec($ch),true);
		
		curl_close($ch);
		
		echo "Response : <br/>";
		print_r($get_pos_response);
		die();
	}
	
	public function sale_web_hook() {		
		$this->load->model('checkout/order');
		//$orderid= $this->session->data['order_id'];
		$orderid= $_REQUEST['order_id'];
		  
		$order_id = $orderid;
		
		
		$get_Result = $this->db->query("SELECT * FROM ". DB_PREFIX . "sale_webhook_fields WHERE order_id = '".(int)$order_id ."'");
		
		if($get_Result->num_rows == 1)
		{
			$sipay_payment_info = json_decode($get_Result->row['sipay_payment_info']);
			$sipay_data_payment = $get_Result->row['sipay_data_payment'];
		}
		
		$this->load->model('account/order');
		$products = $this->model_account_order->getOrderProducts($order_id); 
		foreach($products as $product)
		{
			$get_Result = $this->db->query("SELECT status FROM ". DB_PREFIX . "recurring_product_fields WHERE product_id = '".(int)$product['product_id'] ."'");
			if($get_Result->num_rows > 0)
			{
				$query = $this->db->query("SELECT no_of_payments FROM ". DB_PREFIX . "recurring_product_fields WHERE product_id = '".(int)$product['product_id'] ."'");				
				$no_of_payments = $query->row['no_of_payments'];
			}
			
		}
		
		
		$sipay_3d = $sipay_payment_info;
		
		//print_r($sipay_3d);
		
		$sipay_payheaders=array(
			'Accept: application/json',
			'Content-Type: application/json'
			);
		if($sipay_3d->sipay_3d == 4 || $sipay_3d->sipay_3d == 8){
        
			$post = array(
				'merchant_key' =>trim($this->config->get('payment_sipay_merchant_key')),
				'token' => $sipay_3d['token'],
                'invoice_id' =>trim($order_id)
			);
			$url = $this->config->get('payment_sipay_merchant_domainhwe')."/ccpayment/purchase/status";
		}else{
			
			//$sipay_data = get_post_meta($order_id, 'sipay_data_payment', true);
			//$sipay_data = json_decode($this->session->data['sipay_data_payment'],true);
			//echo "sdfsdf";
			//print_r($sipay_data);
			
			$sipay_payheaders[]= "Authorization: Bearer ".$sipay_data_payment;
			
			$post = array(
				'merchant_key' =>$this->config->get('payment_sipay_merchant_key'),
				'invoice_id' => $order_id
			);
			$url = $this->config->get('payment_sipay_merchant_domainhwe')."/ccpayment/api/checkstatus";
			
		}
		
		$post['app_id'] = $this->config->get('payment_sipay_app_id');
		$post['app_secret'] = $this->config->get('payment_sipay_app_secret');
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url );
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post));
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
		//if($sipay_3d['sipay_3d'] != 4){
			curl_setopt($ch, CURLOPT_HTTPHEADER, $sipay_payheaders);
		//}
		$response = json_decode(curl_exec($ch),true);
		curl_close($ch);
		
		if ($response['status_code'] == 100) {
				
							   
				/*if(isset($response['recurring_id']) && !empty($response['recurring_id']))
				{
					$this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_sipay_order_status_id'),"success / Plan code : ".$response['recurring_plan_code'].' / Recurring number : 1/'.$no_of_payments , 1);
				}
				else
				{*/
					$this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_sipay_order_status_id'),"success", 1);
				//}
			   echo "Order status updated";
				?>
                    
				 <script>
					//location.replace("<?php //echo  $this->url->link('checkout/success'); ?>");
					
					</script>
					
				<?php 
				die();				
			
		}else{
			
			
			if(isset($response['message']))
			{	
				$error=$response['message'];
				
			}
			else
			{
				$error="Error in processing payment.";	
				
			}
			
			$this->load->model('checkout/order');
			
			$orderid= $this->session->data['order_id'];
		
		 
			 
			/*
			if(isset($response['recurring_id']) && !empty($response['recurring_id']))
			{
				$this->model_checkout_order->addOrderHistory($order_id, 10,$error." / Plan code : ".$response['recurring_plan_code'].' / Recurring number : 1/'.$no_of_payments , 0);
			}
			else
			{*/
				$this->model_checkout_order->addOrderHistory($order_id, 10,$error, 0);
			//}
			  
				echo "Order status updated";
		
				  $data['column_left'] = $this->load->controller('common/column_left');
				  $data['column_right'] = $this->load->controller('common/column_right');
				  $data['content_top'] = $this->load->controller('common/content_top');
				  $data['content_bottom'] = $this->load->controller('common/content_bottom');
				  $data['footer'] = $this->load->controller('common/footer');
				  $data['header'] = $this->load->controller('common/header');
				   $data['heading_title'] ="Your order is failed.";
				   $data['description'] = $error;
				  
				  
				  
				  //$this->response->setOutput($this->load->view('extension/payment/sipay_failure', $data));
				
		
		return;
		
		
			
		}
		
	}
	
	public function recurring_web_hook() {
		
		
		$result = $this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "recurring_order_values'");
		
		if($result->num_rows==0)
		{		
			$this->db->query("CREATE TABLE IF NOT EXISTS `". DB_PREFIX . "recurring_order_values` (
				id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
				order_recurring_id VARCHAR(200)  NOT NULL,
				parent_order_id VARCHAR(200) NOT NULL,
				recurring_number VARCHAR(200) NOT NULL,
				date DATETIME NOT NULL
				)");
		}
	
		$this->load->model('checkout/order');

		if(isset($_POST) && $_POST['invoice_id'] > 0 && $_POST['recurring_number'] > 0){
			
			
			if($this->config->get('payment_sipay_merchant_key') != $_POST['merchant_key']){
				echo json_encode(array('msg' => 'Merchant key is invalid or did not match!'));
				exit;
			}
			
			/*$headers= array(
			'Accept: application/json',
			'Content-Type: application/json'
			);*/
			
			
			$post = array(
				'app_id' =>  $this->config->get('payment_sipay_app_id'),
				'app_secret' => $this->config->get('payment_sipay_app_secret')
			);
			
			$domain = $this->config->get('payment_sipay_merchant_domainhwe');
			$url = $domain."/ccpayment/api/token";
			
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url );
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
			//curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			
			$response = json_decode(curl_exec($ch),true);
			
			curl_close($ch);
						
			//$tok = json_decode($response['data']['token'], true);
			$tok =$response['data']['token'];
			
			$order_id = $_POST['invoice_id'];
			
			$order_info = $this->model_checkout_order->getOrder($order_id);
			
			
			$plan_code = $_POST['plan_code'];
			
			$headers = array(
				'Authorization: Bearer '.$tok
			);
			
			$post_data = array(
				'merchant_key' => $_POST['merchant_key'],
				'plan_code' => $plan_code
			);
			
			$url = $this->config->get('payment_sipay_merchant_domainhwe')."/ccpayment/api/recurringPlan/query";
			
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url );
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			
			$response = json_decode(curl_exec($ch),true);
			
			curl_close($ch);
			
			
			if ($response['status_code'] == 100) {
				$rec_status = '';
				$is_recurring_exist=0;
				if(!empty($response['transactionHistories'])){
					foreach($response['transactionHistories'] as $trans){
						if($trans['recurring_number'] == $_POST['recurring_number']){
							$rec_status = $trans['status'];
							$is_recurring_exist=1;
						}
					}
				}
				if(!$is_recurring_exist){
					echo json_encode(array('msg' => 'Invalid recurring number!'));
					exit;
				}
				//if recurring number is 1 it's first payment so i just update the status 
				if( $_POST['recurring_number'] == 1){
					
					if($rec_status == 'Success')
						//$order_info->update_status('completed');
						
						$this->model_checkout_order->addOrderHistory($order_id, 5,"success", 1);
					if($rec_status == 'Failed')
						//$order_info->update_status('failed');
						$this->model_checkout_order->addOrderHistory($order_id,10,"failed", 1);
					
					echo json_encode(array('msg' => 'Order Updated successfully'));
					exit;
				}
				
				// Checking existing order if any order have receiving recurring number then i just update the order status /
				$rec_post = $this->db->query("SELECT * FROM ". DB_PREFIX . "recurring_order_values WHERE parent_order_id = '".(int)$order_id ."'");
				
				
				if($rec_post->num_rows > 0){
										
					$this->load->model('account/order');
					$products = $this->model_account_order->getOrderProducts($order_id); 
					
					foreach($products as $product)
					{
						$get_Result = $this->db->query("SELECT status FROM ". DB_PREFIX . "recurring_product_fields WHERE product_id = '".(int)$product['product_id'] ."'");
						if($get_Result->num_rows > 0)
						{
							$query = $this->db->query("SELECT no_of_payments FROM ". DB_PREFIX . "recurring_product_fields WHERE product_id = '".(int)$product['product_id'] ."'");				
							$no_of_payments = $query->row['no_of_payments'];
						}
						
					}				
					
					$rec_order =  $this->model_checkout_order->getOrder($order_id);
										
					$this->db->query("UPDATE " . DB_PREFIX . "recurring_order_values SET order_recurring_id = '" . $rec_post->row['order_recurring_id'] . "', recurring_number = '" .$_POST['recurring_number'] . "', date = '" .  date("Y/m/d h:i:sa",time()) . "' WHERE parent_order_id = '" . $order_id . "'");
					
					if($rec_status == 'Success')
						//$rec_order->update_status('completed');
						$this->model_checkout_order->addOrderHistory($rec_post->row['order_recurring_id'], 5,"success / Plan code : ".$plan_code." / Recurring number : ".$_POST['recurring_number'].'/'.$no_of_payments, 1);
					if($rec_status == 'Failed')
						//$rec_order->update_status('failed');
						$this->model_checkout_order->addOrderHistory($rec_post->row['order_recurring_id'],10,"failed / Plan code : ".$plan_code." / Recurring number : ".$_POST['recurring_number'].'/'.$no_of_payments, 1);
					
					echo json_encode(array('msg' => 'Order Updated successfully'));
					exit;
				}
								
				$recurring_order_id = $this->model_checkout_order->addOrder($order_info);
				
				$this->load->model('account/order');
				$products = $this->model_account_order->getOrderProducts($recurring_order_id); 
				
				foreach($products as $product)
				{
					$get_Result = $this->db->query("SELECT status FROM ". DB_PREFIX . "recurring_product_fields WHERE product_id = '".(int)$product['product_id'] ."'");
					if($get_Result->num_rows > 0)
					{
						$query = $this->db->query("SELECT no_of_payments FROM ". DB_PREFIX . "recurring_product_fields WHERE product_id = '".(int)$product['product_id'] ."'");				
						$no_of_payments = $query->row['no_of_payments'];
					}
					
				}	
				
				
				/*$this->model_checkout_order->addOrderHistory($recurring_order_id, 5,"success / Plan code : ".$plan_code." / Recurring number : ".$_POST['recurring_number'].'/'.$no_of_payments, 1);
				*/
				if($rec_status == 'Success')
					//$rec_order->update_status('completed');
					$this->model_checkout_order->addOrderHistory($recurring_order_id, 5,"success / Plan code : ".$plan_code." / Recurring number : ".$_POST['recurring_number'].'/'.$no_of_payments, 1);
				if($rec_status == 'Failed')
					//$rec_order->update_status('failed');
					$this->model_checkout_order->addOrderHistory($recurring_order_id,10,"failed / Plan code : ".$plan_code." / Recurring number : ".$_POST['recurring_number'].'/'.$no_of_payments, 1);
				
					
				$this->db->query("INSERT INTO " . DB_PREFIX . "recurring_order_values SET order_recurring_id = '" . $recurring_order_id . "', parent_order_id = '" . $order_id . "', recurring_number = '" . $_POST['recurring_number'] . "', date = '" . date("Y/m/d h:i:sa",time()) . "'");	
				
				
				echo json_encode(array('msg' => 'Order Created successfully'));
					exit;
			}

		}
	}
	public function success() {
		
		$result = $this->db->query("SHOW TABLES LIKE '" . DB_PREFIX . "sale_webhook_fields'");
		if($result->num_rows==0)
		{		
			$this->db->query("CREATE TABLE IF NOT EXISTS `". DB_PREFIX . "sale_webhook_fields` (
				id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
				order_id INT(11) NOT NULL,
				sipay_payment_info TEXT,
				sipay_data_payment TEXT				
				)");
		}
			
		
		$this->load->model('checkout/order');
		$orderid= $this->session->data['order_id'];
		  
		$order_id = $orderid;
		$this->load->model('account/order');
		$products = $this->model_account_order->getOrderProducts($order_id); 
		foreach($products as $product)
		{
			$get_Result = $this->db->query("SELECT status FROM ". DB_PREFIX . "recurring_product_fields WHERE product_id = '".(int)$product['product_id'] ."'");
			if($get_Result->num_rows > 0)
			{
				$query = $this->db->query("SELECT no_of_payments FROM ". DB_PREFIX . "recurring_product_fields WHERE product_id = '".(int)$product['product_id'] ."'");				
				$no_of_payments = $query->row['no_of_payments'];
			}
			
		}
		
		
		$sipay_3d = json_decode($this->session->data['sipay_payment_info'],true);
		
		//print_r($sipay_3d);
		
		$sipay_payheaders=array(
			'Accept: application/json',
			'Content-Type: application/json'
			);
		if($sipay_3d['sipay_3d'] == 4 || $sipay_3d['sipay_3d'] == 8){
        
			$post = array(
				'merchant_key' =>trim($this->config->get('payment_sipay_merchant_key')),
				'token' => $sipay_3d['token'],
                'invoice_id' =>trim($order_id)
			);
			$url = $this->config->get('payment_sipay_merchant_domainhwe')."/ccpayment/purchase/status";
		}else{
			
			//$sipay_data = get_post_meta($order_id, 'sipay_data_payment', true);
			$sipay_data = json_decode($this->session->data['sipay_data_payment'],true);
			//echo "sdfsdf";
			//print_r($sipay_data);
			
			$sipay_payheaders[]= "Authorization: Bearer {$sipay_data['sipay_token']}";
			
			$post = array(
				'merchant_key' =>$this->config->get('payment_sipay_merchant_key'),
				'invoice_id' => $order_id
			);
			$url = $this->config->get('payment_sipay_merchant_domainhwe')."/ccpayment/api/checkstatus";
			
		}
		
		$post['app_id'] = $this->config->get('payment_sipay_app_id');
		$post['app_secret'] = $this->config->get('payment_sipay_app_secret');
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url );
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post));
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
		//if($sipay_3d['sipay_3d'] != 4){
			curl_setopt($ch, CURLOPT_HTTPHEADER, $sipay_payheaders);
		//}
		$response = json_decode(curl_exec($ch),true);
		curl_close($ch);
			
		if ($response['status_code'] == 100) {
				
							   
				if(isset($response['recurring_id']) && !empty($response['recurring_id']))
				{
					$this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_sipay_order_status_id'),"success / Plan code : ".$response['recurring_plan_code'].' / Recurring number : 1/'.$no_of_payments , 1);
				}
				else
				{
					$this->db->query("INSERT INTO " . DB_PREFIX . "sale_webhook_fields SET order_id = '" . (int)$order_id . "', sipay_payment_info = '" . json_encode($sipay_3d) . "', sipay_data_payment = '" . $sipay_data['sipay_token'] . "'");

					$this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_sipay_order_status_id'),"success", 1);
				}
			   
				?>
                    
				 <script>
					location.replace("<?php echo  $this->url->link('checkout/success'); ?>");
					
					</script>
					
				<?php 
				die();				
			
		}else{
			
			
			if(isset($response['message']))
			{	
				$error=$response['message'];
				
			}
			else
			{
				$error="Error in processing payment.";	
				
			}
			
			$this->load->model('checkout/order');
			
			$orderid= $this->session->data['order_id'];
		
		 
			 
			
			if(isset($response['recurring_id']) && !empty($response['recurring_id']))
			{
				$this->model_checkout_order->addOrderHistory($order_id, 10,$error." / Plan code : ".$response['recurring_plan_code'].' / Recurring number : 1/'.$no_of_payments , 0);
			}
			else
			{
				$this->db->query("INSERT INTO " . DB_PREFIX . "sale_webhook_fields SET order_id = '" . (int)$order_id . "', sipay_payment_info = '" . json_encode($sipay_3d) . "', sipay_data_payment = '" . $sipay_data['sipay_token'] . "'");

				$this->model_checkout_order->addOrderHistory($order_id, 10,$error, 0);
			}
			  
		
		
				  $data['column_left'] = $this->load->controller('common/column_left');
				  $data['column_right'] = $this->load->controller('common/column_right');
				  $data['content_top'] = $this->load->controller('common/content_top');
				  $data['content_bottom'] = $this->load->controller('common/content_bottom');
				  $data['footer'] = $this->load->controller('common/footer');
				  $data['header'] = $this->load->controller('common/header');
				   $data['heading_title'] ="Your order is failed.";
				   $data['description'] = $error;
				  
				  
				  
				  $this->response->setOutput($this->load->view('extension/payment/sipay_failure', $data));
				
		
		return;
		
		
			
		}
		
	
	}
	
	public function failure() {
		
	/*	ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);*/
		
		 $this->db->query("CREATE TABLE IF NOT EXISTS `". DB_PREFIX . "sale_webhook_fields` (
				id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,
				order_id INT(11) NOT NULL,
				sipay_payment_info TEXT,
				sipay_data_payment TEXT				
				)");
		
		
		
		
		 $this->load->model('checkout/order');
		  $orderid= $this->session->data['order_id'];
		 
		  
		  $order_id = $orderid;
		$sipay_3d = json_decode($this->session->data['sipay_payment_info'],true);
		
		$sipay_payheaders=array(
			'Accept: application/json',
			'Content-Type: application/json'
			);
		if($sipay_3d['sipay_3d'] == 4){
        
			$post = array(
				'merchant_key' =>$this->config->get('payment_sipay_merchant_key'),
				'token' => $sipay_3d['token'],
                'invoice_id' => $order_id
			);
			$url = $this->config->get('payment_sipay_merchant_domainhwe')."/ccpayment/purchase/status";
		}else{
			
			//$sipay_data = get_post_meta($order_id, 'sipay_data_payment', true);
			$sipay_data = json_decode($this->session->data['sipay_data_payment'],true);
			//print_r($sipay_data);
			
			
			$sipay_payheaders[]= "Authorization: Bearer {$sipay_data['sipay_token']}";
			
			$post = array(
				'merchant_key' =>$this->config->get('payment_sipay_merchant_key'),
				'invoice_id' => trim($order_id)
			);
			
			$url = $this->config->get('payment_sipay_merchant_domainhwe')."/ccpayment/api/checkstatus";
		}
		

		$post['app_id'] = $this->config->get('payment_sipay_app_id');
		$post['app_secret'] = $this->config->get('payment_sipay_app_secret');
	//print_r($post);
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url );
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post));
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
		
			curl_setopt($ch, CURLOPT_HTTPHEADER, $sipay_payheaders);
		
		$response = json_decode(curl_exec($ch),true);
		
		curl_close($ch);
		//print_r($response);
	
		if ($response['status_code'] == 100) {
							   
				if(isset($response['recurring_id']) && !empty($response['recurring_id']))
				{
					$this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_sipay_order_status_id'),"success / Plan code : ".$response['recurring_plan_code'].' / Recurring number : 1/'.$no_of_payments , 1);
				}
				else
				{
					$this->db->query("INSERT INTO " . DB_PREFIX . "sale_webhook_fields SET order_id = '" . (int)$order_id . "', sipay_payment_info = '" . json_encode($sipay_3d) . "', sipay_data_payment = '" . $sipay_data['sipay_token'] . "'");
					$this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_sipay_order_status_id'),"success", 1);
				}
				?>
                    
				 <script>
					location.replace("<?php echo  $this->url->link('checkout/success'); ?>");
					
					</script>
					
				<?php 
				die();				
			
		}else{
			//echo "sfdjskgfdfg";
			//die();
			
		if(isset($_REQUEST['error']))
		{	
			$error=$_REQUEST['error'];
			
		}
		elseif(isset($response['message']))
		{	
			$error=$response['message'];
			
		}
		elseif(isset($_REQUEST['status_description']))
		{	
			$error=$_REQUEST['status_description'];
			
		}
		
		else
		{
			$error="Error in processing payment.";	
			
		}
		
		$this->load->model('checkout/order');
		
		 $orderid= $this->session->data['order_id'];
		
		 
			 
			
			if(isset($response['recurring_id']) && !empty($response['recurring_id']))
			{
				$this->model_checkout_order->addOrderHistory($orderid, 10,$error." / Plan code : ".$response['recurring_plan_code'].' / Recurring number : 1/'.$no_of_payments, 0);
			}
			else
			{
				$this->db->query("INSERT INTO " . DB_PREFIX . "sale_webhook_fields SET order_id = '" . (int)$order_id . "', sipay_payment_info = '" . json_encode($sipay_3d) . "', sipay_data_payment = '" . $sipay_data['sipay_token'] . "'");
				$this->model_checkout_order->addOrderHistory($orderid, 10,$error, 0);
			}
			  
			  
		
		
				  $data['column_left'] = $this->load->controller('common/column_left');
				  $data['column_right'] = $this->load->controller('common/column_right');
				  $data['content_top'] = $this->load->controller('common/content_top');
				  $data['content_bottom'] = $this->load->controller('common/content_bottom');
				  $data['footer'] = $this->load->controller('common/footer');
				  $data['header'] = $this->load->controller('common/header');
				   $data['heading_title'] ="Your order is failed.";
				   $data['description'] = $error;
				  
				  
				  
				  $this->response->setOutput($this->load->view('extension/payment/sipay_failure', $data));
				
		
		return;
		
		
			
		}
		
		
		
		/*
		
		if(isset($_REQUEST['error']))
		{	
			$error=$_REQUEST['error'];
			
		}
		else
		{
			$error="Error in processing payment.";	
			
		}
		
		$this->load->model('checkout/order');
		
		 $orderid= $this->session->data['order_id'];
		 $orderidin=$_GET['invoice_id'];
		 
			 
			 $this->model_checkout_order->addOrderHistory($orderid, 10,$error, 1);
			  
		
		
				  $data['column_left'] = $this->load->controller('common/column_left');
				  $data['column_right'] = $this->load->controller('common/column_right');
				  $data['content_top'] = $this->load->controller('common/content_top');
				  $data['content_bottom'] = $this->load->controller('common/content_bottom');
				  $data['footer'] = $this->load->controller('common/footer');
				  $data['header'] = $this->load->controller('common/header');
				   $data['heading_title'] ="Your order is failed.";
				   $data['description'] = $error;
				  
				  
				  
				  $this->response->setOutput($this->load->view('extension/payment/sipay_failure', $data));
				
		
		return;
		
		
		 
			   
				?>
                    
                     <script>
						location.replace('<?php echo  $this->url->link('checkout/failure'); ?>');
						
						</script>
						
                    <?php 
					die();
			 
		
		 
		*/
		
	}
	
	public function process() {
		
		
		
		//echo "sdfdsf";
		
		  $data['column_left'] = $this->load->controller('common/column_left');
				  $data['column_right'] = $this->load->controller('common/column_right');
				  $data['content_top'] = $this->load->controller('common/content_top');
				  $data['content_bottom'] = $this->load->controller('common/content_bottom');
				  $data['footer'] = $this->load->controller('common/footer');
				  $data['header'] = $this->load->controller('common/header');
				   $data['heading_title'] ="Processing Your Order";
				  // $data['description'] = $error;
				   
			
		
		$this->session->data['sipay_data_payment'] = '';
		
		$this->session->data['sipay_payment_info'] = '';
		
			  $this->load->model('checkout/order');
			  
			  
			 // $this->model_checkout_order->addOrderHistory($this->session->data['order_id'], 1);
			  
			
			  $domain=$this->config->get('payment_sipay_merchant_domainhwe');
			  
			  $post_url = $domain.'/ccpayment/api/token';	
			  
		//echo $this->cart->getTotal();
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		
		$order_info['currency_code']=$this->config->get('payment_sipay_merchant_currencyhwe');
		

		if ($order_info) {
			$redirect_url = '';
		    $invoice = [];
		    $currency = $order_info['currency_code'];
			$product_ids = [];

			foreach ($this->cart->getProducts() as $product) {
				$product_ids[] =  $product['product_id'];
				$item = [
	                'name' => htmlspecialchars($product['name']),
	                'price' => $this->currency->format($product['price'], $order_info['currency_code'], false, false),
	                'qty' => $product['quantity'],
	                'description' => htmlspecialchars($product['model']),
	            ];
	            $invoice['items'][] = $item;
			}
			

		    $invoice['invoice_id'] = $order_info['order_id']; // should be the same invoice id as the one in your store database
		    $invoice['invoice_description'] = $this->session->data['order_id'] . ' - ' . html_entity_decode($order_info['payment_firstname'], ENT_QUOTES, 'UTF-8') . ' ' . html_entity_decode($order_info['payment_lastname'], ENT_QUOTES, 'UTF-8');
		    $invoice['total'] =$this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false);
		   // $invoice['return_url'] = $this->url->link('extension/payment/sipay/callback', '', true)."?sipay_status=1&invoice_id=".$this->session->data['order_id'];
		   // $invoice['cancel_url'] = $this->url->link('checkout/checkout', '', true);
			

		    $invoice = json_encode($invoice);
			$invoice_json_decode = json_decode($invoice);
			
		    $post = array(
		        'app_secret' => $this->config->get('payment_sipay_app_secret'), //sipay test merchant
		      //  'invoice' => $invoice,
		       // 'currency_code' =>  $order_info['currency_code'],
				'app_id' => $this->config->get('payment_sipay_app_id')

		    );
			
		    //exit;
		    $ch = curl_init();
		    curl_setopt($ch, CURLOPT_URL, $post_url);
		  
		    curl_setopt($ch, CURLOPT_POST, true);
		    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);

		    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
		    $response = json_decode(curl_exec($ch),true);
			
		    curl_close($ch);
			
			if($response['status_code'] == 100){
				$is_3d = $response['data']['is_3d'];
                
			}
		
		$baseurl= $this->config->get('config_url')."index.php";
		
		if(!empty(HTTPS_SERVER))
		{
			
			$baseurl=str_replace("http://","https://",$baseurl);
			
			
		}
		
				
			ob_start();
			
				echo '<form action="'.$baseurl.'?route=extension/payment/sipay/callback" class="payment_3dgweget" method="post">';
				
			if($is_3d != 4 && $is_3d != 8){
				
				
			
				?>
               <!-- <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">-->

                <fieldset id="wc-sipay-cc-form" class="wc-credit-card-form wc-payment-form table-bordered">
                <?php } ?>
			<style>
			
			
				#wc-sipay-cc-form
			{
				width: 50%;
				margin-left: 5%;
				border:none;
				/*background:#eee;
				margin-top:10%;*/
				border: 1px solid #ddd
			}
			label
			{
				display: block;
				font-size: 18px;
			}
			.input-text
			{
				box-sizing: border-box;
				width: 100%;
				-moz-appearance: none;
				/*background: #fff;*/
				border-radius: 0;
				border-style: solid;
				border-width: 0.1rem;
				box-shadow: none;
				display: block;
				font-size: 1rem;
				letter-spacing: -0.015em;
				margin: 0;
				max-width: 100%;
				padding: 0.5rem 1rem;
			}
			.form-row-first
			{
				float:left;
			}
			.form-row-last
			{
				float:right;
			}
			.sipay_place_order
			{		
				width: 50%;			
				margin-left:  5%;
				margin-top: 2%;
				/*background-color: #cd2653;*/
				border: none;
				border-radius: 0;
				color: #fff;
				cursor: pointer;
				font-weight: 600;
				letter-spacing: 0.0333em;
				opacity: 1;
				padding: 1.1em 1.44em;
				text-align: center;
				text-decoration: none;
				text-transform: uppercase;
				transition: opacity 0.15s linear;
				font-size: 16px;
				margin-bottom:4%
				
			}
			
		 .single-installment
{
	text-align: center;
	max-height: 180px;
	width: 12%;
	margin-right: 5px;
	margin-top: 10px;
	position: relative;
	float: left;
	height: 160px;
	min-width: 130px;
	line-height: 1.5rem;
	padding: 5px 15px;
	font-family: Arial;
	border: 2px solid #ccc;
	font-size: 1.6rem;
}
	
	
.single-installment div
{
	width: 100%;
	float: left;
	height: 25%;
}

.sipay_heading
{
font-weight: 600;
margin-bottom: 10px;
color: #777777;
}

.sipay_amount
{
color: #333333;
font-weight: bolder;
}

.sipay_installment_number
{
padding-bottom: 0px !important;
padding-left: 10px;
font-size: inherit !important;
}

.sipay_total_amount
{
font-weight: 500;
margin: 5px;
color: #800;
}
			
			.single-installment.active 
			{
				border: 2px solid green;
			}
			  
			/*body
			{ 
				background:#8e8989;
			} */
			
			#wc-sipay-cc-form
			{
				/*background: #f5f5f7;*/
				border-radius: 12px;
			}
			
			.input-text
			{
				border-radius: 4px;
				box-shadow: 1px 1px 1px 1px #888;
				line-height: 2;
				font-size: 16px;
			}
			
			p
			{
				margin: 10px;
				padding: 10px 10px 0px 10px;
			}
			
			#cc_cvv
			{
				width: 70%;
			}
			
			select
			{
				box-shadow: 1px 1px 1px 1px #888;
			}
			
			@media screen and (max-width: 480px) {
			  .form-row-last {
				float:left;
			  }
			  #wc-sipay-cc-form
			  {
				  width:100%;
				  margin-left:0%;
			  }
			  #place_order
			  {
				  margin-left:0%;
			  }
			}
			
			</style>
		
		<?php 
		
		
		$recurringoption=0;
			
			if($response['status_code'] == 100){
				echo "<input type='hidden' name='sipay_token' class='sipay_token' id='sipay_token' value='".$response['data']['token']."'/>";
				
				if(!empty($product_ids))
				{
					
					
					foreach($product_ids as $product_id)
					{
						$cart_product_id = $product_id;
						
						$get_Result = $this->db->query("SELECT * FROM ". DB_PREFIX . "recurring_product_fields WHERE product_id = '".(int)$cart_product_id ."'");
						
						$statushwe="";
						
						if(isset($get_Result->row['status']))
						{
							$statushwe=$get_Result->row['status'];
							
						}
						
						if($statushwe==1)
						{
							
																					
							$payment_duration = $get_Result->row['no_of_payments'];
							
							$payment_cycle = $get_Result->row['order_frequency_cycle'];
							$payment_interval = $get_Result->row['order_frequency_interval'];
							if(!empty($payment_duration) && !empty($payment_cycle) && !empty($payment_interval)){
									$recurringoption=1;
								
								?>
						<input class="recurring_checkbox" name="recurring_options[recurring_check]" type="hidden"  value="yes">
						<input type="hidden" name="recurring_options[payment_duration]" class="payment_duration" value="<?php echo $payment_duration; ?>"/>
						<input type="hidden" name="recurring_options[payment_cycle]" class="payment_cycle" value="<?php echo $payment_cycle; ?>"/>
						<input type="hidden" name="recurring_options[payment_interval]" class="payment_interval" value="<?php echo $payment_interval; ?>"/>	
                       <!-- <input type="hidden" name="recurring_options[payment_recurring_webhook]" class="payment_recurring_webhook" value="<?php //echo $this->config->get('payment_sipay_recurringwebhook'); ?>"/>-->
                        	<?php
								
							}
						}
						
						
					}
					
				}				
			}else{
				
				echo "<input type='hidden' name='sipay_token' class='sipay_token' id='sipay_token' value=''/>";
			}
			
			
			echo "<input type='hidden' name='sipay_3d' class='sipay_3d' id='sipay_3d' value='".$is_3d."'/>";
			echo "<input type='hidden' name='amount' class='amount' id='amount' value='".$invoice_json_decode->total."'/>";
		
			
			if($is_3d != 4 && $is_3d != 8){
				
					// Add this action hook if you want your custom payment gateway to support it
			

			// I recommend to use inique IDs, because other gateways could already use #ccNo, #expdate, #cvc
			?>
            
			<p class="form-row form-row-wide">
	 <label><?php echo $this->getLocalizationContent('card_holder_name', $order_info['currency_code']) ?> <span class="required">*</span></label>
      
				<input id="cc_holder_name" name="cc_holder_name" class="form-control" style="text-transform:uppercase" type="text" autocomplete="off" required="required">
			</p>
			<p class="form-row form-row-wide">
				<label><?php echo $this->getLocalizationContent('card_number', $order_info['currency_code']) ?> <span class="required">*</span></label>
				<input id="cc_number" class="form-control" name="cc_number" type="text" maxlength="16" autocomplete="off" required="required">
                
               <?php
			   
			   $baseurl2= $this->config->get('config_url');
		
		if(!empty(HTTPS_SERVER))
		{
			
			$baseurl2=str_replace("http://","https://",$baseurl2);
			
			
		}
		
		?>
                
				<span class="sipay_spinner_blk" style="display:none"><img src="<?php echo $baseurl2; ?>/catalog/view/theme/default/template/extension/payment/spinner.gif" /></span>
			</p>
			<p class="form-row form-row-first">
			<label><?php echo $this->getLocalizationContent('expiry', $order_info['currency_code']) ?> <span class="required">*</span></label>
				<select name="expiry_month" class="btn dropdown-toggle" id="expiry_month"  style="padding:10px;" required="required">
                    <?php
                    for($i=1; $i<=12; $i++)
                        echo '<option value="'.$i.'" >'.$i.'</option>';
                    ?>
				</select>
                <select class="btn dropdown-toggle" name="expiry_year" id="expiry_year"  style="padding:10px;" required="required">
                    <?php
                    for($i=date('Y'); $i<=date('Y') + 10; $i++)
                        echo '<option value="'.$i.'" >'.$i.'</option>';
                    ?>
                </select>
			</p>
			<p class="form-row form-row-last">
			<label><?php echo $this->getLocalizationContent('cvv', $order_info['currency_code']) ?> <span class="required">*</span></label>
				<input id="cc_cvv" class="form-control" name="cc_cvv" type="password" autocomplete="off" maxlength="3" placeholder="CVV" required="required">
			</p>
			<input type="hidden" name="pos_id" class="pos_id" value=""/>
			<input type="hidden" name="pos_amount" class="pos_amount" value=""/>
			<input type="hidden" name="currency_id" class="currency_id" value=""/>
			<input type="hidden" name="campaign_id" class="campaign_id" value=""/>
			<input type="hidden" name="currency_code" class="currency_code" value=""/>
			<input type="hidden" name="allocation_id" class="allocation_id" value=""/>
			<input type="hidden" name="installments_number" class="installments_number" value=""/>
            <input type="hidden" name="hash_key" class="hash_key" value=""/>
			<div class="clear"></div>
            
            <?php
			$instllment = $this->config->get( 'payment_sipay_enable_disable' );
				$dis = '';
			if($instllment == '1'){
				$dis = "style='display:none'";
			}
			?>
            
			<p class="installments form-row form-row-wide" id="installments" <?php echo $dis; ?>></p>
			<div class="clear"></div>
			<?php
			if($is_3d == 1){ ?>
			<p class="form-row form-row-first" style="float: left;width: 50%;">
				<input style="width:10%;" id="pay_via_3d" class="pay_via_3d" name="pay_via_3d" type="checkbox" autocomplete="off" value="yes"><strong>  <?php echo $this->getLocalizationContent('i_want_3d_payment_option', $order_info['currency_code']) ?></strong>
			</p>
            
            
            
			<?php } ?>
            
      <!--      <div class="recurring_block">
                    <p class="form-row form-row-wide" style="margin-top: 17%;">
                        <input style="width:auto;" id="recurring_checkbox" class="recurring_checkbox" name="recurring_options[recurring_check]" type="checkbox" autocomplete="off" value="yes"> <strong>Recurring Payment</strong>
                    </p>
                    <div class="recurring_option_fields" style="display:none;">
                        <p class="form-row form-row-wide">
                            <label>No of Payments <span class="required">*</span></label>
                            <input type="number" name="recurring_options[payment_duration]" class="payment_duration" value=""/>
                        </p>
                        <p class="form-row form-row-wide">
                            <label>Order Frequency Cycle <span class="required">*</span></label>
                            <select name="recurring_options[payment_cycle]" class="payment_cycle">
                                <option value="D">Daily</option>
                                <option value="W">Weekly</option>
                                <option value="M">Monthly</option>
                                <option value="Y">Yearly</option>
                            </select>
                        </p>
                        <p class="form-row form-row-wide">
                            <label>Order Frequency Interval <span class="required">*</span></label>
                            <input type="number" name="recurring_options[payment_interval]" class="payment_interval" value=""/>
                        </p>
                    </div>
                </div>-->
                
		<?php
			
			
			echo '<div class="clear"></div></fieldset>';
			
			if(!empty( $this->config->get('payment_sipay_labelpayment')))
		{
			$titleset= $this->config->get('payment_sipay_labelpayment');	
		}
		else
		{
			$titleset="Sipay ile Öde";
		}
		
		
			?>
			 <button type="submit" class="button alt sipay_place_order btn btn-primary" name="opencart_sipay_place_order" id="place_order" value="Place order" data-value="Place order"><?php echo $titleset; ?></button>
			<?php			
				
			}
			?>
            
           
			</form>
            
            
           
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
				<script>
				$(document).ready(function(){
					
							
							/*jQuery(document).on('click', '#recurring_checkbox', function(){
							if(jQuery(this).is(':checked'))
							jQuery('.recurring_option_fields').show();
							else
							jQuery('.recurring_option_fields').hide();
							});*/
							
					
					
					<?php
					if($is_3d == 4 || $is_3d == 8)
					{
					?>
					
					$(".payment_3dgweget").submit();
					<?php } ?>
					
					
					$("#cc_number").keypress(function(e){
						if(e.which== 13)
						{
							return false;	
						}
						
						
					});
					
					$("#cc_number").keyup(function(){
						
						$(".sipay_spinner_blk").show();
						$.ajax({
							url: "<?php echo $baseurl; ?>?route=extension/payment/sipay/hwegetinstallement",
							type: 'post',
							data: 
							{
								token:$("#sipay_token").val(),
								number:$(this).val(),
								amount:$("#amount").val(),
								currencycode: '<?php echo $order_info['currency_code']; ?>',
								recurringhwe:'<?php echo $recurringoption; ?>'
							},
							dataType: "JSON",
							success: function (data, textStatus, jQxhr) {
								console.log(data);
								$("#installments").html(data.data);
								$(".pos_id").val(data.pos_id);
								$(".pos_amount").val(data.pos_amt);
								$(".currency_id").val(data.currency_id);
								$(".campaign_id").val(data.campaign_id);
								$(".currency_code").val(data.currency_code);
								$(".allocation_id").val(data.allocation_id);
								$(".installments_number").val(data.installments_number);
								$(".hash_key").val(data.hash_key);
								$(".sipay_spinner_blk").hide();
								//$(".pay_via_3d").css("margin-top","74%");
							},
							error: function (jqXhr, textStatus, errorThrown) {
								console.log(errorThrown);
								jQuery(".sipay_spinner").remove();
							}
						});
						
					});
					
					
   
   
   
				});
				
				$("body").delegate(".single-installment","click",function()
				{
					
						   jQuery(".pos_id").val(jQuery(this).attr('data-posid'));
						   jQuery(".pos_amount").val(jQuery(this).attr('data-amount'));
						   jQuery(".currency_id").val(jQuery(this).attr('data-currency_id'));
						   jQuery(".campaign_id").val(jQuery(this).attr('data-campaign_id'));
						   jQuery(".currency_code").val(jQuery(this).attr('data-currency_code'));
						   jQuery(".allocation_id").val(jQuery(this).attr('data-allocation_id'));
						   jQuery(".installments_number").val(jQuery(this).attr('data-installments_number'));
						   jQuery('.single-installment').removeClass('active');
						   jQuery(this).addClass('active');	
					
				});
					</script>
			
            
            
           <?php /*?>   <?php echo $data['content_bottom']; ?></div>
      <?php echo $data['column_right']; ?> </div>
</div>
 <?php echo $data['footer']; ?><?php */?>
			<?php
			$contentgethwe=ob_get_contents();
			ob_end_clean();
			
			$data['contenhwe']=$contentgethwe;
			 return $this->load->view('extension/payment/sipay', $data);
			
	
			
		}
	}
	
	public function receipt_page(){
		$this->load->model('checkout/order');
		$orderid=$this->session->data['order_id'];
		 $domain=$this->config->get('payment_sipay_merchant_domainhwe');
		$appid=$this->config->get('payment_sipay_app_id');
		$appsecret=$this->config->get('payment_sipay_app_secret');
		
		$sipay_data=$_POST;
		//print_r($sipay_data);
		//die();
			
			
			foreach($sipay_data as $key => $val){
					if($key == "sipay_token"){
					$key ="Authorization";
					$val = "Bearer ".$val;
					}
					$formdata[] = "<input type='hidden' name='".$key."' value='".$val."'/>";
				}

		?>
		<form action="<?php echo $domain; ?>/ccpayment/api/pay3d" class="payment_3dsss" method="post">
			
           
            <?php echo  implode('', $formdata); ?>
			<input type="hidden" name="app_id" value="<?php echo $appid; ?>">
			<input type="hidden" name="app_secret" value="<?php echo $appsecret; ?>">
           
		</form>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
			<script>
		$(".payment_3dsss").submit();
			</script>
		<?php
		
	}
	
	public	function generateHashKey($total,$installment,$currency_code,$merchant_key,$invoice_id, $app_secret){
                    
                     $data = $total.'|'.$installment.'|'.$currency_code.'|'.$merchant_key.'|'.$invoice_id;
                    
                     $iv = substr(sha1(mt_rand()), 0, 16);
                     $password = sha1($app_secret);
                    
                     $salt = substr(sha1(mt_rand()), 0, 4);
                     $saltWithPassword = hash('sha256', $password . $salt);
                    
                     $encrypted = openssl_encrypt("$data", 'aes-256-cbc', "$saltWithPassword", null, $iv);
                    
                     $msg_encrypted_bundle = "$iv:$salt:$encrypted";
                     $msg_encrypted_bundle = str_replace('/', '__', $msg_encrypted_bundle);
                    
                     return $msg_encrypted_bundle;
        }
                    
	public function getLocalizationContent($content, $language){
		$language = strtoupper($language);
		$lang = [
			'TRY' => [
				'card_holder_name' => 'Kart Sahibi',
				'card_number' => 'Kart Numarası',
				'expiry' => 'Son Kullanma Tarihi',
				'cvv' => 'Güvenlik Numarası',
				'single_installment' => 'Peşin',
				'installment' => 'Taksit',
				'i_want_3d_payment_option' => '3d ödeme seçeneği istiyorum'
			],
			'USD' => [
				'card_holder_name' => 'Card Holder Name',
				'card_number' => 'Card Number',
				'expiry' => 'Expiry',
				'cvv' => 'CVV',
				'single_installment' => 'Single Installment',
				'installment' => 'Installment',
				'i_want_3d_payment_option' => 'I want 3D payment option'
			]
		];

		if (!isset($lang[$language])){
			$language = 'USD';
		}
		if (isset($lang[$language][$content])){
			$localizeContent = $lang[$language][$content];
		}else{
			$localizeContent = $content;
		}

		return $localizeContent;
	}
	public function hwegetinstallement()
	{
		
						
		/*$pos_post = array(
				'credit_card' => $_POST['number'],
				'amount' => $_POST['amount'],
				"currency_code" =>$_POST['currencycode'],
				"merchant_key" => $this->config->get('payment_sipay_merchant_key')
			);*/
			
			$pos_post = array(
				'credit_card' => $_POST['number'],
				'amount' => $_POST['amount'],
				"currency_code" =>$this->config->get('payment_sipay_merchant_currencyhwe'),
				"merchant_key" => $this->config->get('payment_sipay_merchant_key'),
				'app_id' => $this->config->get( 'payment_sipay_app_id' ),

				'app_secret' => $this->config->get( 'payment_sipay_app_secret' )
			);
			
			
			if($_POST['recurringhwe']==1){
				$pos_post['is_recurring'] = 1;
			}
		
		
		$headers = array(
				'Accept: application/json',
				'Content-Type: application/json',
				"Authorization: Bearer {$_POST['token']}"
			);
			
		  $domain=$this->config->get('payment_sipay_merchant_domainhwe');
		  
		 /* echo $domain."/ccpayment/api/getpos" ;
		  print_r($pos_post);
		   print_r($headers);
		   echo json_encode($pos_post);
		   die;
		  */
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,  $domain."/ccpayment/api/getpos" );

			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($pos_post));
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
			$get_pos_response = json_decode(curl_exec($ch),true);
		//print_r($get_pos_response);
		//die();
		
			curl_close($ch);
			 
			//die();
			
			if($get_pos_response['status_code'] == 100){
				
				$html='';
				if(!empty($get_pos_response['data'])){
					$pos_id ='';
					$pos_amt='';
					$currency_id="";
					$campaign_id="";
					$allocation_id="";
					$installments_number="";
					$hash_key="";
					$currency_code='';
					$i=0;
					$html ="<div class='row' style='margin-top: 20%'>";
					
					foreach($get_pos_response['data'] as $val){
						$sipay_installment = explode(',',$this->config->get('payment_sipay_installment'));
						
						if($val['installments_number'] != 1){
							
							if(in_array($val['installments_number'], $sipay_installment)){
								$i++;
							continue;
							}
						}
						
											
						$active_cls="";
//						$inst= ($i+1)." Installment";
                        $currency_code=$val['currency_code'];
						if($i == 0){
							$active_cls='active';
							$pos_id = $val['pos_id'];
							
							$pos_amt = $val['amount_to_be_paid'];
							$currency_id=$val['currency_id'];
							$campaign_id=$val['campaign_id'];
							$allocation_id=$val['allocation_id'];
							$installments_number=$val['installments_number'];
							$hash_key = $val['hash_key'];

							$inst= $this->getLocalizationContent('single_installment',$currency_code);
							
							$html .="<div class='single-installment ".$active_cls."' data-posid='".$val["pos_id"]."' data-amount='".$val["amount_to_be_paid"]."' data-currency_id='".$val["currency_id"]."' data-campaign_id='".$val["campaign_id"]."' data-allocation_id='".$val["allocation_id"]."' data-installments_number='".$val["installments_number"]."' data-hash_key='".$val["hash_key"]."' data-currency_code='".$val["currency_code"]."'
						
						style='margin-left: 1%;'
						
						>
						<div class='sipay_heading'>".$inst."</div>
						<div class='sipay_amount'>".$val['amount_to_be_paid']." ".$val['currency_code']."</div>
						<div class='sipay_installment_number'>".($i+1)." X</div>
						<div class='sipay_total_amount'>".$val['amount_to_be_paid']." ".$val['currency_code']."</div></div>";
						
						
						}else{
						   $inst = ($i+1)." ".$this->getLocalizationContent('installment',$currency_code);
						   
						   $html .="<div class='single-installment ".$active_cls."' data-posid='".$val["pos_id"]."' data-amount='".$val["amount_to_be_paid"]."' data-currency_id='".$val["currency_id"]."' data-campaign_id='".$val["campaign_id"]."' data-allocation_id='".$val["allocation_id"]."' data-installments_number='".$val["installments_number"]."' data-hash_key='".$val["hash_key"]."' data-currency_code='".$val["currency_code"]."'
						
						
						
						>
						<div class='sipay_heading'>".$inst."</div>
						<div class='sipay_amount'>".$val['amount_to_be_paid']." ".$val['currency_code']."</div>
						<div class='sipay_installment_number'>".($i+1)." X</div>
						<div class='sipay_total_amount'>".number_format(($val['amount_to_be_paid']/($i+1)), 2)." ".$val['currency_code']."</div></div>";
						
						
                        }
						
						$i++;
					}
					$html .="</div>";
					
					echo json_encode(array('data' => $html, 'pos_id' => $pos_id, 'pos_amt' => $pos_amt, 'currency_id' => $currency_id, 'campaign_id' => $campaign_id, 'allocation_id' => $allocation_id, 'installments_number' => $installments_number, 'hash_key' => $hash_key,   'currency_code' => $currency_code));
					exit;
				}
			}
			echo json_encode(array('data' => '', 'pos_id' => '', 'pos_amt' => '', 'currency_id' => '', 'campaign_id' => '', 'allocation_id' => '', 'installments_number' => '', 'hash_key' => '', 'currency_code' => $this->config->get('payment_sipay_merchant_currencyhwe')));
			exit;
		
	}
	
	
    public function callback() {
					
    	$this->load->model('checkout/order');

		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		
		
		
			 $sub_total = $this->cart->getSubTotal();
			
		 $total = $this->cart->getTotal();
		
		 $tax_total = $total - $sub_total;
		$order_total=$total ;
		$shipping_total=0;
		
			if (isset($this->session->data['shipping_method'])) {
				
			$shipping_total=$this->session->data['shipping_method']['cost'];
			
			
		}
		
	$discount_coupon = 0;
		
		if(isset($this->session->data['coupon']))
		{
		    $coupon_code = $this->session->data['coupon'];
		    $coupon_query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "coupon` WHERE code = '" . $this->db->escape($coupon_code)."'");
		}
		else {
		    $coupon_query = null;
		}
		
		
		if(isset($coupon_query->num_rows))
		{
			$discount_coupon = $coupon_query->row['discount'];
		}
		
		
		if($discount_coupon > 0){

			$invoice['discount'] = number_format( $discount_coupon, 2, ".", "");

			$invoice['coupon'] = $coupon_code;

		}else{

			$invoice['discount'] =0;

			$invoice['coupon'] = '3XY8P';

		}
		
		$ordersetinfo=json_encode(array('sipay_3d' => $_POST['sipay_3d'], 'token' => $_POST['sipay_token']));
			$this->session->data['sipay_payment_info'] = $ordersetinfo;
		

    	if($order_info){
			$post = array(
				'merchant_key' =>$this->config->get('payment_sipay_merchant_key'),
				'invoice_id' => $order_info['order_id']
			);

			
				$post_url = $this->config->get('payment_sipay_merchant_domainhwe').'/ccpayment/purchase/link';
				  $domain=$this->config->get('payment_sipay_merchant_domainhwe');
				
			
			
			
			
			
			$invoice['invoice_description'] = "Order with Invoice ".  $order_info['order_id'] ;
			
				//$return_url=$domain.'/index.php?route=extension/payment/sipay/receipt_page?sipay_status=1&invoice_id='.$order_info['order_id'];
				
				$baseurl= $this->config->get('config_url')."index.php";
				
				if(!empty(HTTPS_SERVER))
				{
			
					$baseurl=str_replace("http://","https://",$baseurl);
			
			
				}
		
										

				
				//$invoice['return_url'] = $this->url->link('checkout/success').'&sipay_status=1&invoice_id='.$order_info['order_id'];
				//$invoice['cancel_url'] =$this->url->link('checkout/failure');
				
				
				
				
				$invoice['return_url']=$baseurl.'?route=extension/payment/sipay/success';
				$invoice['cancel_url']=$baseurl.'?route=extension/payment/sipay/failure';
					
					
									/* Older version payment request */
									
	//================================case1========================================================//
	
		
				if(isset($_POST['sipay_3d']) && ($_POST['sipay_3d'] == 4 || $_POST['sipay_3d'] == 8)){
					
		
				$item_total=0;
				$dis_per_product_amount=0;
				if($discount_coupon > 0){
					$dis_total_amount = number_format( $discount_coupon, 2, ".", "");
					$item_count= count($this->cart->getProducts());
					$dis_per_product_amount = $dis_total_amount/$item_count;
				}
				foreach($this->cart->getProducts() as $product){
							$item = [
							'name' => str_replace('&quot;', ' ',$product['name']),
							//'price' => number_format( $product['price'], 2, ".", ""),
							'price' => number_format( ($product['price']-$dis_per_product_amount), 2, ".", ""),
							'qty' =>(int)$product['quantity'],
							'description' => htmlspecialchars($product['model']),
						];
						$invoice['items'][] = $item;
							//$item_total += $product['price'] * $product['quantity'];
							$item_total += $product['price'] * $product['quantity']-$dis_per_product_amount;
				}


			/*$rebate = $item_total + $tax_total + $shipping_total - $order_total;
			
			if ($rebate > 0) {
			
				$invoice['discount'] =number_format( $rebate, 2, ".", "");
				$invoice['coupon'] = '3XY8P';
			} 
			else{
			$invoice['discount'] =0;
			$invoice['coupon'] = '3XY8P';
			}*/
					
					if($shipping_total>0)
					{
						
						$invoice['items'][] = array(
						'name' => 'Shipping Charge',
						'price' => number_format( $shipping_total, 2, ".", ""),
						'qty' => 1,
						'description' => ''
						);	
						$item_total += $shipping_total;
					}
		 
		 		if($tax_total >0)
				{
				
				$invoice['items'][] = array(
						'name' => 'Tax',
						'price' => number_format( $tax_total, 2, ".", ""),
						'qty' => 1,
						'description' => ''
					);
					$item_total += $tax_total;		 
				}

			$invoice['invoice_id'] = $order_info['order_id'];
			$invoice['total'] =number_format( $item_total, 2, ".", "");

                    //BIlling info Optional
                    $invoice['bill_address1'] = isset($order_info['payment_address_1']) ? $order_info['payment_address_1'] : '';
                    $invoice['bill_address2'] = isset($order_info['payment_address_2']) ? $order_info['payment_address_2'] : '';
                    $invoice['bill_city'] = isset($order_info['payment_city']) ? $order_info['payment_city'] : '';
                    $invoice['bill_postcode'] = isset($order_info['payment_postcode']) ? $order_info['payment_postcode'] : '';
                    $invoice['bill_state'] = isset($order_info['payment_zone']) ? $order_info['payment_zone'] : '';
                    $invoice['bill_country'] = isset($order_info['payment_country']) ? $order_info['payment_country'] : '';
                    $invoice['bill_email'] = isset($order_info['email']) ? $order_info['email'] : '';
                    $invoice['bill_phone'] = isset($order_info['telephone']) ? $order_info['telephone'] : '';
					
					if(!empty($this->config->get('payment_sipay_salewebhook')))
					{
						$invoice['sale_web_hook_key'] = $this->config->get('payment_sipay_salewebhook');
					}
										
					
					if(isset($_POST['recurring_options']) && !empty($_POST['recurring_options']) && $_POST['recurring_options']['recurring_check'] == 'yes'){
						$invoice['order_type'] = 1;
						$invoice['recurring_payment_number'] = $_POST['recurring_options']['payment_duration'];
						$invoice['recurring_payment_cycle'] = $_POST['recurring_options']['payment_cycle'];
						$invoice['recurring_payment_interval'] = $_POST['recurring_options']['payment_interval'];
						//$invoice['recurring_web_hook_key'] = $_POST['recurring_options']['payment_recurring_webhook'];
						if(!empty($this->config->get('payment_sipay_recurringwebhook')))
						{
							$invoice['recurring_web_hook_key'] =$this->config->get('payment_sipay_recurringwebhook');
						}	
					}
					
					$invoice = json_encode($invoice);

					$post = array(
						'merchant_key' => $this->config->get('payment_sipay_merchant_key'),
						'invoice' => $invoice,
						'currency_code' =>  $this->config->get('payment_sipay_merchant_currencyhwe'),
						'name' => $order_info['payment_firstname'],
						'surname' => $order_info['payment_lastname']
					);
					

					$ch = curl_init();
					curl_setopt($ch, CURLOPT_URL, $domain."/ccpayment/purchase/link" );

					curl_setopt($ch, CURLOPT_POST, true);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
					curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
					curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);

					curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
					$response = json_decode(curl_exec($ch),true);
					curl_close($ch);
					
					
					if ($response['status'] == 1) {
						$successlink= $response['link'];
						?>
                        <script>
						location.replace("<?php echo  $response['link']; ?>");
						
						</script>
                        
                        <?php
						
						
					}else{
						
						$error=$response['status_description'];
						
				//$this->model_checkout_order->addOrderHistory($order_info['order_id'], 10);
						?>
                        <script>
						location.replace("<?php echo  $baseurl.'?route=extension/payment/sipay/failure&error='.$error; ?>");
						
						</script>
                        
                        <?php
					}

					
				}
				
				
				
				$price = 0;
				

			
			
				$invoice['payable_amount'] = number_format( $_POST['pos_amount'], 2, ".", "");
				$invoice['merchant_key'] = $this->config->get('payment_sipay_merchant_key');

				$invoice['pos_id'] = $_POST['pos_id'];
				$invoice['currency_id'] = $_POST['currency_id'];
				$invoice['campaign_id'] = $_POST['campaign_id'];
				$invoice['allocation_id'] = $_POST['allocation_id'];
				$invoice['installments_number'] = $_POST['installments_number'];
				$invoice['hash_key'] = $_POST['hash_key'];
				$invoice['cc_holder_name'] = $_POST['cc_holder_name'];
				$invoice['cc_no'] = $_POST['cc_number'];
				$invoice['expiry_month'] = $_POST['expiry_month'];
				$invoice['expiry_year'] = $_POST['expiry_year'];
				$invoice['cvv'] = $_POST['cc_cvv'];
				$invoice['currency_code'] = $this->config->get('payment_sipay_merchant_currencyhwe');

				
	//=====================case2========================================================//
			
				
					if(((isset($_POST['sipay_3d']) && $_POST['sipay_3d'] == 1) && (isset($_POST['pay_via_3d']) && $_POST['pay_via_3d'] == "yes")) || (isset($_POST['sipay_3d']) && $_POST['sipay_3d'] == 2)){
						
					
						$item_total=0;
						$dis_per_product_amount=0;
						if($discount_coupon > 0){
							$dis_total_amount = number_format( $discount_coupon, 2, ".", "");
							$item_count= count($this->cart->getProducts());
							$dis_per_product_amount = $dis_total_amount/$item_count;
						}
						foreach($this->cart->getProducts() as $product){
							
							$item = [
							'name' => str_replace('&quot;', ' ',$product['name']),
							//'price' => number_format( $product['price'], 2, ".", ""),
							'price' => number_format( ($product['price']-$dis_per_product_amount), 2, ".", ""),
							'qnantity' =>(int)$product['quantity'],
							'description' => htmlspecialchars($product['model']),
						];
						$invoice['items'][] = $item;
						//$item_total += $product['price'] * $product['quantity'];
						$item_total += $product['price'] * $product['quantity']-$dis_per_product_amount;
					}

				/*$rebate = $item_total + $tax_total + $shipping_total - $order_total;
			
					if ($rebate > 0) {
					
						$invoice['discount'] =number_format( $rebate, 2, ".", "");
						$invoice['coupon'] = '3XY8P';
					} 
					else{
					$invoice['discount'] =0;
					$invoice['coupon'] = '3XY8P';
					}*/
					
					if($shipping_total>0)
					{
						
						$invoice['items'][] = array(
						'name' => 'Shipping Charge',
						'price' => number_format( $shipping_total, 2, ".", ""),
						'qnantity' => 1,
						'description' => ''
						);	
						$item_total += $shipping_total;
					}
		 
		 		if($tax_total >0)
				{
				
				$invoice['items'][] = array(
						'name' => 'Tax',
						'price' => number_format( $tax_total, 2, ".", ""),
						'qnantity' => 1,
						'description' => ''
					);
					$item_total += $tax_total;
		 
				}
						
					

						$pay_data=array(
							'sipay_token' => $_POST['sipay_token'],
							'sipay_3d' => $_POST['sipay_3d'],
							'cc_holder_name' => $_POST['cc_holder_name'],
							'cc_no' => $_POST['cc_number'],
							'expiry_month' => $_POST['expiry_month'],
							'expiry_year' => $_POST['expiry_year'],
							'cvv' => $_POST['cc_cvv'],
							'pos_id' => $_POST['pos_id'],
							'pos_amount' => $_POST['pos_amount'],
							'currency_id' => $_POST['currency_id'],
							'currency_code' => $_POST['currency_code'],
							'campaign_id' => $_POST['campaign_id'],
							'allocation_id' => $_POST['allocation_id'],
							'installments_number' => $_POST['installments_number'],
							'hash_key' => $_POST['hash_key'],
							'invoice_id' => $order_info['order_id'],
							'invoice_description' => "Order with Invoice ".  $order_info['order_id'],
							'total' => number_format( $item_total, 2, ".", ""),
							'merchant_key' => $this->config->get('payment_sipay_merchant_key'),
							'payable_amount' => number_format( $_POST['pos_amount'], 2, ".", ""),
							'return_url' => $invoice['return_url'],
							'cancel_url' => $invoice['cancel_url'],
							'items' => json_encode($invoice['items']),
							'name' => $order_info['payment_firstname'],
							'surname' => $order_info['payment_lastname'],
                            'bill_address1' => isset($order_info['payment_address_1']) ? $order_info['payment_address_1'] : '',
                            'bill_address2' => isset($order_info['payment_address_2']) ? $order_info['payment_address_2'] : '',
                            'bill_city' => isset($order_info['payment_city']) ? $order_info['payment_city'] : '',
                            'bill_postcode' => isset($order_info['payment_postcode']) ? $order_info['payment_postcode'] : '',
                            'bill_state' => isset($order_info['payment_zone']) ? $order_info['payment_zone'] : '',
                            'bill_country' => isset($order_info['payment_country']) ? $order_info['payment_country'] : '',
                            'bill_email' => isset($order_info['email']) ? $order_info['email'] : '',
                            'bill_phone' => isset($order_info['telephone']) ? $order_info['telephone'] : ''

						);
						if($invoice['discount'] > 0)
							$pay_data['discount'] = $invoice['discount'];
						if(!empty($this->config->get('payment_sipay_salewebhook')))
						{
							$pay_data['sale_web_hook_key'] = $this->config->get('payment_sipay_salewebhook');
						}
							
						
						
						 if(isset($_POST['recurring_options']) && !empty($_POST['recurring_options']) && $_POST['recurring_options']['recurring_check'] == 'yes'){
							$pay_data['order_type'] = 1;
							$pay_data['recurring_payment_number'] = $_POST['recurring_options']['payment_duration'];
							$pay_data['recurring_payment_cycle'] = $_POST['recurring_options']['payment_cycle'];
							$pay_data['recurring_payment_interval'] = $_POST['recurring_options']['payment_interval'];
							//$pay_data['recurring_web_hook_key'] = $_POST['recurring_options']['payment_recurring_webhook'];
							if(!empty($this->config->get('payment_sipay_recurringwebhook')))
							{
								$pay_data['recurring_web_hook_key'] =$this->config->get('payment_sipay_recurringwebhook');
							}
		
						}
						
						//print_r($pay_data);
						$pay_datainfo=json_encode($pay_data);
						$this->session->data['sipay_data_payment'] = $pay_datainfo;
								
						
						foreach($pay_data as $key => $val){
					
						$formdatass[] = "<input type='hidden' name='".$key."' value='".$val."'/>";
						}

						?>
                      <form action="<?php echo $baseurl; ?>?route=extension/payment/sipay/receipt_page" method="post" id="hwesipay">
                       <?php echo  implode('', $formdatass); ?>
                      
                      </form> 
                      
                      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
			<script>
			
			 $("#hwesipay").submit();  
		  
		  
			
			</script>
                        
                        
                        <?php
									
									
						
					die();
				}
				
	//================================================case3========================================================//
		
			
		
				$item_total=0;
				$dis_per_product_amount=0;
				if($discount_coupon > 0){
					$dis_total_amount = number_format( $discount_coupon, 2, ".", "");
					$item_count= count($this->cart->getProducts());
					$dis_per_product_amount = $dis_total_amount/$item_count;
				}
						foreach($this->cart->getProducts() as $product){
							$item = [
							'name' =>  str_replace('&quot;', ' ',$product['name']),
							//'price' => number_format( $product['price'], 2, ".", ""),
							'price' => number_format( ($product['price']-$dis_per_product_amount), 2, ".", ""),
							'qnantity' =>(int)$product['quantity'],
							'description' => htmlspecialchars($product['model']),
						];
						$invoicecase3['items'][] = $item;
						//$item_total += $product['price'] * $product['quantity'];
						$item_total += $product['price'] * $product['quantity']-$dis_per_product_amount;
					}


				/*$rebate = $item_total + $tax_total + $shipping_total - $order_total;
				
				if ($rebate > 0) {
					
						$invoicecase3['discount'] =number_format( $rebate, 2, ".", "");
						$invoicecase3['coupon'] = '3XY8P';
					} 
					else{
					$invoicecase3['discount'] =0;
					$invoicecase3['coupon'] = '3XY8P';
					}*/
					if($discount_coupon > 0){

						$invoicecase3['discount'] = number_format( $discount_coupon, 2, ".", "");
			
						$invoicecase3['coupon'] = $coupon_code;
			
					}else{
			
						$invoicecase3['discount'] =0;
			
						$invoicecase3['coupon'] = '3XY8P';
			
					}
					if($shipping_total>0)
					{
						
						$invoicecase3['items'][] = array(
						'name' => 'Shipping Charge',
						'price' => number_format( $shipping_total, 2, ".", ""),
						'qnantity' => 1,
						'description' => ''
						);	
						$item_total += $shipping_total;
					}
		 
		 		if($tax_total >0)
				{
				
				$invoicecase3['items'][] = array(
						'name' => 'Tax',
						'price' => number_format( $tax_total, 2, ".", ""),
						'qnantity' => 1,
						'description' => ''
					);
					$item_total += $tax_total;
		 
				}
			
					$invoicecase3['invoice_id']=$order_info['order_id'];
					$invoicecase3['invoice_description']="Order with Invoice ".$order_info['order_id'];
					$invoicecase3['return_url']=$baseurl.'?route=extension/payment/sipay/success';
					$invoicecase3['cancel_url']=$baseurl.'?route=extension/payment/sipay/failure';
					$invoicecase3['total']=number_format( $item_total, 2, ".", "");
					$invoicecase3['payable_amount']=number_format( $_POST['pos_amount'], 2, ".", "");
					$invoicecase3['merchant_key']=trim($this->config->get('payment_sipay_merchant_key'));
					
					$invoicecase3['pos_id']= $_POST['pos_id'];
					$invoicecase3['currency_id']=$_POST['currency_id'];
					$invoicecase3['campaign_id']=$_POST['campaign_id'];
					$invoicecase3['allocation_id']=$_POST['allocation_id'];
					$invoicecase3['installments_number']=$_POST['installments_number'];
					$invoicecase3['cc_holder_name']=$_POST['cc_holder_name'];
					$invoicecase3['cc_no']=$_POST['cc_number'];
					$invoicecase3['expiry_month']=$_POST['expiry_month'];
					$invoicecase3['expiry_year']=$_POST['expiry_year'];
					$invoicecase3['cvv']=$_POST['cc_cvv'];
					
					$invoicecase3['currency_code']=$_POST['currency_code'];
					$invoicecase3['app_id']=trim($this->config->get('payment_sipay_app_id'));
					$invoicecase3['app_secret']=trim($this->config->get('payment_sipay_app_secret'));
					
					$invoicecase3['name']=$order_info['payment_firstname'];
					$invoicecase3['surname']=$order_info['payment_lastname'];
					$invoicecase3['bill_address1']=isset($order_info['payment_address_1']) ? $order_info['payment_address_1'] : '';
					
					$invoicecase3['bill_address2']=isset($order_info['payment_address_2']) ? $order_info['payment_address_2'] : '';
					$invoicecase3['bill_city']=isset($order_info['payment_city']) ? $order_info['payment_city'] : '';
					$invoicecase3['bill_postcode']=isset($order_info['payment_postcode']) ? $order_info['payment_postcode'] : '';
					
					$invoicecase3['bill_state']=isset($order_info['payment_zone']) ? $order_info['payment_zone'] : '';
					$invoicecase3['bill_country']=isset($order_info['payment_country']) ? $order_info['payment_country'] : '';
					$invoicecase3['bill_email']=isset($order_info['email']) ? $order_info['email'] : '';
					
					$invoicecase3['bill_phone']=isset($order_info['telephone']) ? $order_info['telephone'] : '';
					
					if(!empty($this->config->get('payment_sipay_salewebhook')))
					{
						$invoicecase3['sale_web_hook_key'] = $this->config->get('payment_sipay_salewebhook');
					}
					
					if(isset($_POST['recurring_options']) && !empty($_POST['recurring_options']) && $_POST['recurring_options']['recurring_check'] == 'yes'){
						$invoicecase3['order_type'] = 1;
						$invoicecase3['recurring_payment_number'] = $_POST['recurring_options']['payment_duration'];
						$invoicecase3['recurring_payment_cycle'] = $_POST['recurring_options']['payment_cycle'];
						$invoicecase3['recurring_payment_interval'] = $_POST['recurring_options']['payment_interval'];
						//$invoicecase3['recurring_web_hook_key'] = $_POST['recurring_options']['payment_recurring_webhook'];
						if(!empty($this->config->get('payment_sipay_recurringwebhook')))
						{
							$invoicecase3['recurring_web_hook_key'] =$this->config->get('payment_sipay_recurringwebhook');
						}
	
					}					
					
					
					$headers= array(
			'Accept: application/json',
			'Content-Type: application/json'
			);
				$pay_datainfo=json_encode(array('sipay_token' => $_POST['sipay_token']));
				$this->session->data['sipay_data_payment'] = $pay_datainfo;
				
				
			$headers[]= "Authorization: Bearer {$_POST['sipay_token']}";
			
				//echo $domain."/ccpayment/api/pay";
			
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL,"https://dev.sipay.com.tr/ccpayment/api/pay");

				curl_setopt($ch, CURLOPT_POST, true);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($invoicecase3));
				curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
				curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

				curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
				$response = json_decode(curl_exec($ch),true);
				curl_close($ch);
			//print_r($response);	
			
			if ($response['status_code'] == 100 ) {
				
				//$this->model_checkout_order->addOrderHistory($order_info['order_id'], $this->config->get('payment_sipay_order_status_id'));
										
					?>
                    
                     <script>
						location.replace("<?php echo  $baseurl.'?route=extension/payment/sipay/success'; ?>");
						
						</script>
						
                    <?php
					die();
				}else{
					$error=$response['status_description'];
					if(!$error)
					{
						$error=	$response['message'];
					}
					if(!$error)
					{
						$error=	"Error in processing payment.";
					}
					
					//$this->model_checkout_order->addOrderHistory($order_info['order_id'], 10);
					?>
                     <script>
						location.replace("<?php echo $baseurl.'?route=extension/payment/sipay/failure&error='.$error; ?>");						
						</script>
                    
                    <?php
					die();
				}
			


			/*$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $post_url);
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
			$response = json_decode(curl_exec($ch),true);
			curl_close($ch);
			if (isset($response['status']) ) {
				$this->model_checkout_order->addOrderHistory($order_info['order_id'], $this->config->get('payment_sipay_order_status_id'));
				$this->response->redirect($this->url->link('checkout/success', '', true));
			}*/
		}

    }

}

?>
