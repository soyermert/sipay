<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 9/17/2020
 * Time: 4:44 PM
 */

namespace common\integration;


use App\Http\Controllers\Traits\CommonLogTrait;

class CCPaymentIntegration
{
    use CommonLogTrait;

    public $payment_integration_option = '';
    public $status_code = '';
    public $status_message = 'Message Undefined';
    public $pay_3d_form = '';
    public $output_data = [];

    private static $instance = null;
    private $merchant_key = '';
    private $app_id = '';
    private $app_secret = '';
    private $headers = [
        'Accept: application/json',
        'Content-Type: application/json'
    ];
    private $sipay_apis = [];
    private $api_url = '';
    private $input_data = [];


    public function __construct($app_id, $app_secret, $merchant_key)
    {
        $end_point = config('app.CC_PAYMENT_URL');
//        $end_point = "https://provisioning.sipay.com.tr/ccpayment";
        $this->app_id = $app_id;
        $this->app_secret = $app_secret;
        $this->merchant_key = $merchant_key;
        $this->input_data['merchant_key'] = $merchant_key;

        $this->sipay_apis = [
            'get_token' => $end_point. '/api/token',
            'get_pos' => $end_point . '/api/getpos',
            'pay_3d' => $end_point . '/api/pay3d',
            'pay_2d' => $end_point .'/api/pay',
            'check_status' => $end_point .'/api/checkstatus',
            'branded_solution' => $end_point .'/purchase/link'
        ];

        $this->generateToken();

        $logData['action'] = 'CREATE_CCPAYMENT_OBJECT';
        $this->createLog($logData);

    }

    public static function getInstance($app_id, $app_secret, $merchant_key)
    {
        if(!self::$instance)
        {
            self::$instance = new CCPaymentIntegration($app_id, $app_secret, $merchant_key);
        }

        return self::$instance;
    }

    private function generateToken(){

        $inputData = [
            'app_id' => $this->app_id,
            'app_secret' => $this->app_secret,
        ];
        $this->input_data =  $inputData;
        $this->input_data['merchant_key'] = $this->merchant_key;

        $this->api_url = $this->sipay_apis['get_token'];

        $response = $this->callApiByCurl();

        if ($response->status_code == 100) {
            $this->headers[] = "Authorization: Bearer {$response->data->token}";
            $this->status_code = $response->status_code;
            $this->status_message = $response->status_description;
            $this->payment_integration_option = $response->data->is_3d;
        } else {

            $this->status_code = $response->status_code;
            $this->status_message = $response->status_description;
        }
    }


    public function pay2d($input)
    {
        $this->input_data =  $input;
        $this->input_data['merchant_key'] = $this->merchant_key;
        $this->api_url = $this->sipay_apis['pay_2d'];

        $response = $this->callApiByCurl();

        if ($response->status_code == 100) {
            $this->status_code = $response->status_code;
            $this->status_message = 'Payment Created Successfully';
        }else{
            $this->status_code = $response->status_code;
            $this->status_message = $response->status_description;
        }
    }

    public function pay3d($input)
    {
        $this->input_data =  $input;
        $this->input_data['merchant_key'] = $this->merchant_key;

        $this->api_url = $this->sipay_apis["pay_3d"];

        $formOpen = "<form action='{$this->api_url}' method='post' id='the-form'>";
        $form = '';
        foreach ($this->input_data as $key => $value){
            $form .= "<input type='hidden' name='{$key}' value='{$value}'>";
        }

        $formClose = "</form>";
        $script ='<script type="text/javascript">window.onload = function(){
                        document.getElementById("the-form").submit();}
                  </script>';

        $this->pay_3d_form = $formOpen.$form.$formClose.$script;

    }

    public function redirectedToBranded($input)
    {

        $this->input_data =  $input;
        $this->input_data['merchant_key'] = $this->merchant_key;

        $this->api_url = $this->sipay_apis['branded_solution'];

        $response = $this->callApiByCurl();

        if ($response->status == true) {
            $form = "<form action='{$response->link}' method='get' id='the-form'></form>";
            $script ='<script type="text/javascript">window.onload = function(){
                        document.getElementById("the-form").submit();}
                  </script>';
            $this->pay_3d_form = $form.$script;
            $this->status_code = 100;
            $this->status_message = 'Payment link Created Successfully';
        }else{
            $this->status_code = $response->status_code;
            $this->status_message = $response->success_message;
        }


    }

    public function getPos($input)
    {

        $input['credit_card'] = $input['cc_no'];
        $this->input_data =  $input;
        $this->input_data['merchant_key'] = $this->merchant_key;

        $this->api_url = $this->sipay_apis["get_pos"];
        $response = $this->callApiByCurl();
        $this->output_data = '';
        if ($response->status_code == 100) {
            $this->status_code = $response->status_code;
            $this->status_message = 'Payment Created Successfully';
            $this->output_data = $response->data;
        }else{
            $this->status_code = $response->status_code;
            $this->status_message = $response->status_description;
        }
    }

    public function getOrderStatus($input){

        $this->input_data =  $input;
        $this->input_data['merchant_key'] = $this->merchant_key;

        $this->api_url = $this->sipay_apis["check_status"];
        $response = $this->callApiByCurl();
        $this->output_data = '';
        if ($response->status_code == 100) {
            $this->status_code = $response->status_code;
            $this->status_message = 'Payment Created Successfully';
            $this->output_data = $response;
        }else{
            $this->status_code = $response->status_code;
            $this->status_message = $response->message;
        }
    }

    public function refund($input){

    }

    private function callApiByCurl()
    {

        $ch = curl_init($this->api_url);
        if ($this->isNonSecureConnection()){
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        }
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER,  $this->headers);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($this->input_data));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 90);
        $output = curl_exec($ch);
        $output = json_decode($output);

        curl_close($ch);

        return $output;

    }

}