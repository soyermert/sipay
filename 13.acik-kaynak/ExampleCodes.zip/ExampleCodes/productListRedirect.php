<?php
ob_start();
@session_start();
$host = 'https://provisioning.sipay.com.tr';
$host = 'https://app.sipay.com.tr';
$host = 'https://dev.sipay.com.tr';
// $host = 'http://localhost/app.sipay.com.tr';
//Configuration Section  Start
//$merchant_key  =  '$2y$10$NHjMDiNnNrYz57U5cNU8rOD.ikhTP5n0VuYMFHqYMwFacoYxIYbK6';
$merchant_key  =  '$2y$10$w/ODdbTmfubcbUCUq/ia3OoJFMUmkM1UVNBiIQIuLfUlPmaLUT1he';
$URL  =   $host."/ccpayment/purchase/link";
$return_url = $host."/payment_success.php";
$cancel_url =  $host."/payment_success.php";

$invoice_id = rand(1,99999).time();

if (isset($_SESSION['merchant_key']) and !empty($_SESSION['merchant_key'])){
    $merchant_key = $_SESSION['merchant_key'];
}
//Configuration Section End
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Product List </title>
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css"> -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <style>
        .main {
            width: 80%;
            margin: 50px auto;
            background: #eee;
            display: flex;
        }

        .product-left {
            width: 50%;
            float: left;
        }

        .product-right {
            width: 50%;
            float: left;
        }

        .single-product {
            padding: 20px;
        }

        .product-image img {
            width: 100%;
            height: auto;
        }

        .product-image {
            padding: 20px;
        }
        #iframeModalWindow{
            background: url('data:image/svg+xml;charset=utf-8,<svg xmlns="http://www.w3.org/2000/svg" width="100%" height="100%" viewBox="0 0 100% 100%"><text fill="%2300b0ff" x="50%" y="50%" font-family="\'Lucida Grande\', sans-serif" font-size="24" text-anchor="middle">Loading....</text></svg>') 0px 0px no-repeat;
        }
    </style>
</head>
<body>
<div class="main">
    <form action="#" method="post" id="productList">
        <div class="single-product">
            <div class="product-left">
                <div class="product-image">
                    <img src="https://provisioning.sipay.com.tr/iphone8-spgray-select-2018.png" alt="Buy iPhone 8+">
                </div>
                <p>
                    Buy iPhone 8 or iPhone 8 Plus in Space Gray, Silver, or Gold today. Pay in full or pay with low monthly payments. Buy now with fast, free shipping.

                </p>
            </div>
            <div class="product-right">
                <p>
                    Invoice Id: "<?php echo $invoice_id; ?>"
                    <input type="hidden" name="invoice_id" value="<?php echo $invoice_id ?>">
                </p>
                <p>
                    Merchant key:
                    <input type="text" name="merchant_key" value="<?php echo $merchant_key ?>" style="width: 100%">
                </p>

                <p>
                    Currency :
                    <select name="currency">

                        <option value="TRY" selected >TRY</option>
                        <option value="USD"  >USD</option>
                        <option value="EUR"  >EUR</option>
                    </select>
                </p>


                <p>
                    Product Name :
                    <input type="text" name="name_1" value="Product 1">
                </p>

                <p>
                    Product Price :
                    <input type="number" name="price_1" value="20" step="any" min="0">
                </p>
                <p>
                    Product Qty :
                    <input  type="number" name="qty_1" value="1">
                </p>
                <p>
                    Short Description :
                    <textarea name="desc_1" rows="2" cols="20">Product 01 short description</textarea>
                </p>

                <p>
                    Sale web hook:(Optional)
                    <input  type="text" name="sale_web_hook_key" value="">
                </p>
               <p>
                 Max Installment:
                 <input type="text" name="max_installment" value="0" >
               </p>
                <p>
                    <input id="recurringPayment" name="order_type" type="checkbox" value="1"><b>Recurring payment</b>
                </p>
                <div style="display: none" id="recurringArea">
                    <p>
                        Total Number Payments:
                        <input  type="number" name="recurring_payment_number" value="6" placeholder="Total number of payment">
                    </p>
                    <p>
                        Order Frequency Cycle:
                        <select name="recurring_payment_cycle" id="recurring_payment_cycle">
                            <option value="D">Daily</option>
<!--                            <option value="W">Weekly</option>-->
                            <option value="M">Monthly</option>
                            <option value="Y">Yearly</option>

                        </select>
                    </p>
                    <p>
                        Order Frequency Interval:
                        <input  type="number" name="recurring_payment_interval" value="1" placeholder="Order Frequency Interval">

                    </p>
                    <p>
                        Recurring Web Hook Key Name
                        <input  type="text" name="recurring_web_hook_key" value="DEFAULT_RECURRING_WEB_HOOK">

                    </p>
                </div>



              <p><button type="submit" name="checkout" id="checkout" >Checkout</button></p>
<!--                <div class="checkbox">-->
<!--                    <label> <input type="checkbox" name="iframe" value="1">Display CC page as popup</label>-->
<!--                </div>-->

            </div>
        </div>
        <input type="hidden" name="total_product" value="1" />
    </form>

</div>

<!-- Modal -->
<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">Sipay</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" style="min-height: 600px">
                <iframe id="iframeModalWindow"  height="580" width="100%" src="" name="iframe_modal">
                </iframe>
                <div id="loadingMessage">Loading...</div>
            </div>
            <!--            <div class="modal-footer">-->
            <!--                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>-->
            <!--            </div>-->
        </div>
    </div>
</div>
<script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.4.1.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>

<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.js"></script> -->
<script>
    function makeCheckout() {
        var formData = $("#productList").serialize();
        console.log(formData);
    }
    $('#iframeModalWindow').ready(function () {
        $('#loadingMessage').css('display', 'none');
    });
    $('#recurringPayment').click(function() {
        if( $(this).is(':checked')) {
            $("#recurringArea").show();
        } else {
            $("#recurringArea").hide();
        }
    });
</script>

</body>
</html>
<?php



if (isset($_POST['checkout'])) {
    $redirect_url = '';
    $invoice = [];
    $price = 0;
    $isIframe = 0;

    $merchant_key = $_POST['merchant_key'];
    $_SESSION['merchant_key'] = $merchant_key;

    $currency = $_POST["currency"];
    for ($i=0; $i <= $_POST['total_product']; $i++ ) {
        if (!empty($_POST['name_'.$i]) && !empty($_POST['price_'.$i]) && !empty($_POST['qty_'.$i])) {
            $item = [
                'name' => $_POST['name_'.$i],
                'price' => $_POST['price_'.$i],
                'qty' => $_POST['qty_'.$i],
                'description' => $_POST['desc_'.$i],
            ];
            $price += $_POST['price_'.$i];
            $invoice['items'][] = $item;
        }

    }

    if (isset($_POST['invoice_id'])){
        $invoice['invoice_id'] = $_POST['invoice_id'];
    }else{
        $invoice['invoice_id'] = rand(1,99999); // should be the same invoice id as the one in your store database
    }



    $_SESSION["invoice_id"]  = $invoice['invoice_id'];

    if (isset($_POST['iframe'])){
        $isIframe = $_POST['iframe'];
    }

    $invoice['invoice_description'] = "Order with Invoice ".  $invoice['invoice_id'] ;
    $invoice['total'] = $price;
    $invoice['return_url'] = $return_url;
    $invoice['cancel_url'] = $cancel_url;

    //billing info
    $invoice['bill_address1'] = 'Address 1 should not more than 100 characters should not more than 100 characters should not more than 100 characters should not more than 100 characters should not more than 100 characters'; //should not more than 100 characters
    $invoice['bill_address2'] = 'Address 2'; //should not more than 100 characters
    $invoice['bill_city'] = 'Istanbul';
    $invoice['bill_postcode'] = '1111';
    $invoice['bill_state'] = 'Istanbul';
    $invoice['bill_country'] = 'TURKEY';
    $invoice['bill_phone'] = '008801777711111';
    $invoice['bill_email'] = 'demo@sipay.com.tr';
    $invoice['sale_web_hook_key'] = $_POST['sale_web_hook_key'];
    $invoice['max_installment'] = $_POST['max_installment'];


    if (isset($_POST['order_type'])){
        $invoice['order_type'] = 1;
        $invoice['recurring_payment_number'] = $_POST['recurring_payment_number'];
        $invoice['recurring_payment_cycle'] = $_POST['recurring_payment_cycle'];
        $invoice['recurring_payment_interval'] = $_POST['recurring_payment_interval'];
        $invoice['recurring_web_hook_key'] = $_POST['recurring_web_hook_key'];

    }

    $invoice = json_encode($invoice);

//    echo "<pre>";
//    print_r($invoice);
//    echo "</pre>";
//
//    exit;

    $post = array(
        'merchant_key' => $merchant_key, //sipay test merchant
        'invoice' => $invoice,
        'currency_code' =>  $currency,
        'name' => 'Test',
        'surname' => 'Sipay'
    );
    //exit;
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $URL);

    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);

    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
    $response = json_decode(curl_exec($ch),true);

    curl_close($ch);

    if ($response['status'] == true) {
        //if response status is true, that means we have a link and we redirect the user to sipay.com.tr
//        header('Location: '.$response['link'].'');
        if ($isIframe == 1){

            $script = '<script>
                var link = "'.$response['link'].'"

                $("#iframeModalWindow").attr("src",link);

                $("#exampleModalCenter").modal("show")
            </script>';
            echo $script;
        }else{

            header('Location: '.$response['link'].'');
            exit;
        }

    }else{
        var_dump($response);
    }
}
ob_end_flush();
