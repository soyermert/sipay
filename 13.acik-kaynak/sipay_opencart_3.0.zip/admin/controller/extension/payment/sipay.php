<?php
class ControllerExtensionPaymentSipay extends Controller {
	private $error = array();

	public function index() {
		
		$this->load->language('extension/payment/sipay');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');
		
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->request->post['payment_sipay_installment'] = implode(',',$this->request->post['payment_sipay_installment']);
		
			$this->model_setting_setting->editSetting('payment_sipay', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		/*if (isset($this->error['login'])) {
			$data['error_login'] = $this->error['login'];
		} else {
			$data['error_login'] = '';
		}

		if (isset($this->error['key'])) {
			$data['error_key'] = $this->error['key'];
		} else {
			$data['error_key'] = '';
		}
		*/
		if (isset($this->error['app_id'])) {
			$data['error_app_id'] = $this->error['app_id'];
		} else {
			$data['error_app_id'] = '';
		}
		
		if (isset($this->error['app_secret'])) {
			$data['error_app_secret'] = $this->error['app_secret'];
		} else {
			$data['error_app_secret'] = '';
		}
		
		if (isset($this->error['recurring_web_hook_key'])) {
			$data['error_recurring_web_hook_key'] = $this->error['recurring_web_hook_key'];
		} else {
			$data['error_recurring_web_hook_key'] = '';
		}
		
		if (isset($this->error['sale_web_hook_key'])) {
			$data['error_sale_web_hook_key'] = $this->error['sale_web_hook_key'];
		} else {
			$data['error_sale_web_hook_key'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/sipay', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/payment/sipay', 'user_token=' . $this->session->data['user_token'], true);
		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);

		if (isset($this->request->post['payment_sipay_merchant_id'])) {
			$data['payment_sipay_merchant_id'] = $this->request->post['payment_sipay_merchant_id'];
		} else {
			$data['payment_sipay_merchant_id'] = $this->config->get('payment_sipay_merchant_id');
		}

		if (isset($this->request->post['payment_sipay_merchant_key'])) {
			$data['payment_sipay_merchant_key'] = $this->request->post['payment_sipay_merchant_key'];
		} else {
			$data['payment_sipay_merchant_key'] = $this->config->get('payment_sipay_merchant_key');
		}
		
		
		if (isset($this->request->post['payment_sipay_merchant_domainhwe'])) {
			$data['payment_sipay_merchant_domainhwe'] = $this->request->post['payment_sipay_merchant_domainhwe'];
		} else {
			$data['payment_sipay_merchant_domainhwe'] = $this->config->get('payment_sipay_merchant_domainhwe');
		}
		
		if (isset($this->request->post['payment_sipay_merchant_currencyhwe'])) {
			$data['payment_sipay_merchant_currencyhwe'] = $this->request->post['payment_sipay_merchant_currencyhwe'];
		} else {
			$data['payment_sipay_merchant_currencyhwe'] = $this->config->get('payment_sipay_merchant_currencyhwe');
		}
		
		
		
		
		if (isset($this->request->post['payment_sipay_app_id'])) {
			$data['payment_sipay_app_id'] = $this->request->post['payment_sipay_app_id'];
		} else {
			$data['payment_sipay_app_id'] = $this->config->get('payment_sipay_app_id');
		}
		
		if (isset($this->request->post['payment_sipay_app_secret'])) {
						
			$data['payment_sipay_app_secret'] = $this->request->post['payment_sipay_app_secret'];
		} else {
			$data['payment_sipay_app_secret'] = $this->config->get('payment_sipay_app_secret');
		}
		
		if (isset($this->request->post['payment_sipay_recurringwebhook'])) {
			
			$data['payment_sipay_recurringwebhook'] = $this->request->post['payment_sipay_recurringwebhook'];
		} else {
			
			$data['payment_sipay_recurringwebhook'] = $this->config->get('payment_sipay_recurringwebhook');
		}
		
		if (isset($this->request->post['payment_sipay_salewebhook'])) {
			
			$data['payment_sipay_salewebhook'] = $this->request->post['payment_sipay_salewebhook'];
		} else {
			
			$data['payment_sipay_salewebhook'] = $this->config->get('payment_sipay_salewebhook');
		}



		if (isset($this->request->post['payment_sipay_labelpayment'])) {
			$data['payment_sipay_labelpayment'] = $this->request->post['payment_sipay_labelpayment'];
		} else {
			$data['payment_sipay_labelpayment'] = $this->config->get('payment_sipay_labelpayment');
		}
		
		
		
		if (isset($this->request->post['payment_sipay_mode'])) {
			$data['payment_sipay_mode'] = $this->request->post['payment_sipay_mode'];
		} else {
			$data['payment_sipay_mode'] = $this->config->get('payment_sipay_mode');
		}

		if (isset($this->request->post['payment_sipay_order_status_id'])) {
			$data['payment_sipay_order_status_id'] = $this->request->post['payment_sipay_order_status_id'];
		} else {
			$data['payment_sipay_order_status_id'] = $this->config->get('payment_sipay_order_status_id');
		}

		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		if (isset($this->request->post['payment_sipay_geo_zone_id'])) {
			$data['payment_sipay_geo_zone_id'] = $this->request->post['payment_sipay_geo_zone_id'];
		} else {
			$data['payment_sipay_geo_zone_id'] = $this->config->get('payment_sipay_geo_zone_id');
		}

		$this->load->model('localisation/geo_zone');

		$data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();

		if (isset($this->request->post['payment_sipay_status'])) {
			$data['payment_sipay_status'] = $this->request->post['payment_sipay_status'];
		} else {
			$data['payment_sipay_status'] = $this->config->get('payment_sipay_status');
		}

		if (isset($this->request->post['payment_sipay_total'])) {
			$data['payment_sipay_total'] = $this->request->post['payment_sipay_total'];
		} else {
			$data['payment_sipay_total'] = $this->config->get('payment_sipay_total');
		}

		if (isset($this->request->post['payment_sipay_sort_order'])) {
			$data['payment_sipay_sort_order'] = $this->request->post['payment_sipay_sort_order'];
		} else {
			$data['payment_sipay_sort_order'] = $this->config->get('payment_sipay_sort_order');
		}
		
		
		if (isset($this->request->post['payment_sipay_enable_disable'])) {
			$data['payment_sipay_enable_disable'] = $this->request->post['payment_sipay_enable_disable'];
		} else {
			$data['payment_sipay_enable_disable'] = $this->config->get('payment_sipay_enable_disable');
		}
		$data['payment_sipay_installment']=array(); 
		if (isset($this->request->post['payment_sipay_installment'])) {
			
			$data['payment_sipay_installment'] = $this->request->post['payment_sipay_installment'];
		} else {
			$data['payment_sipay_installment'] = explode(',',$this->config->get('payment_sipay_installment'));
		}
		

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$data['baseurl']= HTTP_CATALOG."index.php";
	
		$post_url = $this->config->get('payment_sipay_merchant_domainhwe').'/ccpayment/api/token';
		
		$post = array(
		        'app_secret' => $this->config->get('payment_sipay_app_secret'), //sipay test merchant
				'app_id' => $this->config->get('payment_sipay_app_id')
		    );
			
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $post_url);
		
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
		
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
		$response = json_decode(curl_exec($ch),true);
		
		curl_close($ch);
		
		$url = $this->config->get('payment_sipay_merchant_domainhwe').'/ccpayment/api/installments';
		$headers=array(
			//'Accept: application/json',
			//'Content-Type: application/json',
			'Authorization: Bearer '.$response['data']['token']
			);
		//print_r($headers);
		$post_content = array(
			'merchant_key' => $this->config->get('payment_sipay_merchant_key')
		);
		//print_r($post_content);
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url );

		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_content);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
		$installments = json_decode(curl_exec($ch),true);
		//print_r($get_pos_response);
	
		curl_close($ch);
		
		$installment_options= array();
		if(isset($installments['status_code']) && $installments['status_code'] == 100 && !empty($installments['installments'])){
			foreach($installments['installments'] as $in => $installment){
				if($installment == 1)
					continue;

				/*if($in == 1)
					$inst_title= "Installments";
				else
					$inst_title = '';


				$installment_fields['installment_'.$installment] = array(
					'title'   => $inst_title,
					'type'    => 'checkbox',
					'label'   => $installment,
					'default' => 'no'
				);*/

				$installment_options[$installment]= $installment; 

			}
		}
		/*print_r($installment_options);
		die();
		
		
		die();*/
		$data['installments'] = $installment_options;
		
		$this->response->setOutput($this->load->view('extension/payment/sipay', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/payment/sipay')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		/*if (!$this->request->post['payment_sipay_merchant_id']) {
			$this->error['login'] = $this->language->get('error_login');
		}

		if (!$this->request->post['payment_sipay_merchant_key']) {
			$this->error['key'] = $this->language->get('error_key');
		}
		*/
		if (!$this->request->post['payment_sipay_app_id']) {
			$this->error['app_id'] = $this->language->get('error_app_id');
		}
		
		if (!$this->request->post['payment_sipay_recurringwebhook']) {
			$this->error['recurring_web_hook_key'] = $this->language->get('error_recurring_web_hook_key');
		}
		
		if (!$this->request->post['payment_sipay_salewebhook']) {
			$this->error['sale_web_hook_key'] = $this->language->get('error_sale_web_hook_key');
		}
		
		if (!$this->request->post['payment_sipay_app_secret']) {
			$this->error['app_secret'] = $this->language->get('error_app_secret');
		}

		return !$this->error;
	}
}