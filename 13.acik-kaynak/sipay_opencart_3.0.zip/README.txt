Sipay payment module

We need to login with admin detail.

First we need to add this module in Extension -> installer.

Here you need to upload zip file of sipay module.

To see this payemnt module, we go to Extension->extension then select payment then show sipay payment.

We need to install this module, here you will see plus (+) icon to install click on it. 

For configuration, click on pencil icon.

We need to save Merchant details.

Like Merchant key, Merchant id, App id, App key.

And select currency, set button label, set recurring web hook key, set sale web hook key,installments.

When we want to recurring payment we need to make a product as recurring product. To make a product 
is recurring product we need to set No. of payment, order payment cycle, order payment interval.

To set recurring fields, edit a product or add a product then you will see extra fields tab then click on this extra fields tab then show this form to set this fields.

To set sale web hook key for normal product.

Admin can choose installments number to show installments block.

When we do payment it will work.

