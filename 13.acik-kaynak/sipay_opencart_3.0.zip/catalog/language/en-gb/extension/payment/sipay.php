<?php
// Text
$_['text_title']           = 'Pay with SiPay';
