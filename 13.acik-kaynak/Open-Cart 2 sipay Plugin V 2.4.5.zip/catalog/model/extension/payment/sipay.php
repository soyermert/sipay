<?php 
class ModelExtensionPaymentSipay extends Model {
  	public function getMethod($address, $total) {
		$this->language->load('extension/payment/sipay');
	
		if ($this->config->get('sipay_total') > 0 && $this->config->get('sipay_total') > $total) {
			$status = false;
		} else {
			$status = true;
		}

		$method_data = array();

		if ($status) {
                    $method_data = array( 
                            'code'       => 'sipay',
                            'title'      => $this->language->get('text_title'),
                            'sort_order' => '0',
                            'terms'      => ''
                    );
                }
            return $method_data;
  	}
}
?>