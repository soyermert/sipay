<?php

class ControllerExtensionPaymentSipay extends Controller
{
    private $error = array();

    //function executed at load of page
    public function index()
    { 
      
	
        $this->language->load('extension/payment/sipay');
		$this->load->model('setting/setting');

        $this->document->setTitle($this->language->get('heading_title'));
        $arr = array();
		  
		 
		 	if (($this->request->server['REQUEST_METHOD'] == 'POST') )
			 {
			
				$this->model_setting_setting->editSetting('sipay', $this->request->post);
				// $this->config->get('sipay_key');
				
					$this->session->data['success'] = $this->language->get('text_success');	
		
				$this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true));
		}


       
	 
		 	 
	 
        $this->load->model('setting/setting');
		
		 

     
	

        $data['heading_title'] = $this->language->get('heading_title');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_all_zones'] = $this->language->get('text_all_zones');
        $data['text_yes'] = $this->language->get('text_yes');
        $data['text_no'] = $this->language->get('text_no');
        $data['text_live'] = $this->language->get('text_live');
        $data['text_successful'] = $this->language->get('text_successful');
        $data['text_fail'] = $this->language->get('text_fail');
        $data['text_env_production'] = $this->language->get('text_env_production');
        $data['text_env_sdb'] = $this->language->get('text_env_sdb');

		// shahrukh
		
		$data['entry_api_domain'] = $this->language->get('entry_api_domain');
        $data['entry_api_domain_help'] = $this->language->get('entry_api_domain_help');
        $data['error_key_domain'] = $this->language->get('error_key_domain');
		
		$data['entry_merchant_currency'] = $this->language->get('entry_merchant_currency');
        $data['entry_merchant_currency_help'] = $this->language->get('entry_merchant_currency_help');
        $data['error_merchant_currency'] = $this->language->get('error_merchant_currency');
		
		$data['entry_app_id'] = $this->language->get('entry_app_id');
        $data['entry_app_id_help'] = $this->language->get('entry_app_id_help');
        $data['error_app_id'] = $this->language->get('error_app_id');
		
		
		$data['entry_app_secret'] = $this->language->get('entry_app_secret');
        $data['entry_app_secret_help'] = $this->language->get('entry_app_secret_help');
        $data['error_app_secret'] = $this->language->get('error_app_secret');
		
		$data['entry_enable_disable'] = $this->language->get('entry_enable_disable');
        $data['entry_app_enable_disable_help'] = $this->language->get('entry_app_enable_disable_help');
        $data['error_enable_disable'] = $this->language->get('error_enable_disable');
		 
		$data['entry_sales_web_hook_key'] = $this->language->get('entry_sales_web_hook_key');
        $data['entry_sales_web_hook_key_help'] = $this->language->get('entry_sales_web_hook_key_help');
        $data['error_sales_web_hook_key'] = $this->language->get('error_sales_web_hook_key');
		
		$data['entry_recurring_web_hook_key'] = $this->language->get('entry_recurring_web_hook_key');
        $data['entry_recurring_web_hook_key_help'] = $this->language->get('entry_recurring_web_hook_key_help');
        $data['error_recurring_web_hook_key'] = $this->language->get('error_recurring_web_hook_key');
		
		$data['entry_sales_web_hook_url'] = $this->language->get('entry_sales_web_hook_url');
        $data['entry_recurring_web_hook_url_help'] = $this->language->get('entry_recurring_web_hook_url_help');
        $data['error_sales_web_hook_url'] = $this->language->get('error_sales_web_hook_url');
		
	    $data['entry_recurring_web_hook_url'] = $this->language->get('entry_recurring_web_hook_url');
        $data['entry_recurring_web_hook_url_help'] = $this->language->get('entry_recurring_web_hook_url_help');
        $data['error_recurring_web_hook_url'] = $this->language->get('error_recurring_web_hook_url');
		
		$data['entry_label_for_checkout_page'] = $this->language->get('entry_label_for_checkout_page');
        $data['entry_label_for_checkout_page_help'] = $this->language->get('entry_label_for_checkout_page_help');
        $data['error_label_for_checkout_page'] = $this->language->get('error_label_for_checkout_page');
		
  		$data['entry_installments'] = $this->language->get('entry_installments');
        $data['entry_installments_help'] = $this->language->get('entry_installments_help');
        $data['error_installments'] = $this->language->get('error_installments');
		
		$data['entry_geo_zones'] = $this->language->get('entry_geo_zones');
        $data['entry_geo_zones_help'] = $this->language->get('entry_geo_zones_help');
		
	 	$data['entry_short_order'] = $this->language->get('entry_short_order');
        $data['entry_short_order_help'] = $this->language->get('entry_short_order_help');
        $data['error_short_order'] = $this->language->get('error_short_order');
		
		//$data['base_url'] = $this->config->get('HTTPS_SERVER');
		
 
		// shahrukh end
		
        $data['tab_extrafields'] = $this->language->get('tab_extrafields');
        $data['entry_merchant'] = $this->language->get('entry_merchant');
        $data['entry_merchant_help'] = $this->language->get('entry_merchant_help');
        $data['entry_merchantkey'] = $this->language->get('entry_merchantkey');
        $data['entry_merchantkey_help'] = $this->language->get('entry_merchantkey_help');
        $data['entry_order_status'] = $this->language->get('entry_order_status');
        $data['entry_environment'] = $this->language->get('entry_environment');
        $data['entry_environment_help'] = $this->language->get('entry_environment_help');
        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_total'] = $this->language->get('entry_total');
        $data['help_total'] = $this->language->get('help_total');

        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');

        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        if (isset($this->error['merchant'])) {
            $data['error_merchant'] = $this->error['merchant'];
        } else {
            $data['error_merchant'] = '';
        }
        if (isset($this->error['key'])) {
            $data['error_key'] = $this->error['key'];
        } else {
            $data['error_key'] = '';
        }

        if (isset($this->request->post['sipay_order_status_id'])) {
            $data['sipay_order_status_id'] = $this->request->post['sipay_order_status_id'];
        } else {
            $data['sipay_order_status_id'] = $this->config->get('sipay_order_status_id');
        }
		
		if (isset($this->request->post['sipay_geo_zones'])) {
            $data['sipay_geo_zones'] = $this->request->post['sipay_geo_zones'];
        } else {
            $data['sipay_geo_zones'] = $this->config->get('sipay_geo_zones');
        }
		
		

        $this->load->model('localisation/order_status');

        $data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => false
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_payment'),
            'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => ' :: '
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('extension/payment/sipay', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => ' :: '
        );

        $data['action'] = $this->url->link('extension/payment/sipay', 'token=' . $this->session->data['token'], 'SSL');

        $data['cancel'] = $this->url->link('extension/extension', 'token=' . $this->session->data['token'], 'SSL');

        if (isset($this->request->post['sipay_merchant'])) {
            $data['sipay_merchant'] = $this->request->post['sipay_merchant'];
        } else {
            $data['sipay_merchant'] = $this->config->get('sipay_merchant');
        }

        if (isset($this->request->post['sipay_key'])) {
              $data['sipay_key'] = $this->request->post['sipay_key'];
        } else {
              $data['sipay_key'] = $this->config->get('sipay_key');
        }
		
		 if (isset($this->request->post['sipay_api_domain'])) {
              $data['sipay_api_domain'] = $this->request->post['sipay_api_domain'];
        } else {
              $data['sipay_api_domain'] = $this->config->get('sipay_api_domain');
        }

		 if (isset($this->request->post['sipay_merchant_currency'])) {
              $data['sipay_merchant_currency'] = $this->request->post['sipay_merchant_currency'];
        } else {
              $data['sipay_merchant_currency'] = $this->config->get('sipay_merchant_currency');
        }





        if (isset($this->request->post['sipay_status'])) {
            $data['sipay_status'] = $this->request->post['sipay_status'];
        } else {
            $data['sipay_status'] = $this->config->get('sipay_status');
        }

        if (isset($this->request->post['sipay_environment'])) {
            $data['sipay_environment'] = $this->request->post['sipay_environment'];
        } else {
            $data['sipay_environment'] = $this->config->get('sipay_environment');
        }


        if (isset($this->request->post['sipay_sort_order'])) {
            $data['sipay_sort_order'] = $this->request->post['sipay_sort_order'];
        } else {
            $data['sipay_sort_order'] = $this->config->get('sipay_sort_order');
        }


        if (isset($this->request->post['sipay_total'])) {
            $data['sipay_total'] = $this->request->post['sipay_total'];
        } else {
            $data['sipay_total'] = $this->config->get('sipay_total');
        }
		
		/* shahrukh code */
		 if (isset($this->request->post['sipay_app_id'])) {
            $data['sipay_app_id'] = $this->request->post['sipay_app_id'];
        } else {
            $data['sipay_app_id'] = $this->config->get('sipay_app_id');
        }
		
		
		 if (isset($this->request->post['sipay_key'])) {
            $data['sipay_key'] = $this->request->post['sipay_key'];
        } else {
            $data['sipay_key'] = $this->config->get('sipay_key');
        }
		
		 
		
		 if (isset($this->request->post['sipay_enable_disable'])) {
            $data['sipay_enable_disable'] = $this->request->post['sipay_enable_disable'];
        } else {
            $data['sipay_enable_disable'] = $this->config->get('sipay_enable_disable');
        }
		
		 if (isset($this->request->post['sipay_sales_web_hook_key'])) {
            $data['sipay_sales_web_hook_key'] = $this->request->post['sipay_sales_web_hook_key'];
        } else {
            $data['sipay_sales_web_hook_key'] = $this->config->get('sipay_sales_web_hook_key');
        }
		
		 if (isset($this->request->post['sipay_recurring_web_hook_key'])) {
            $data['sipay_recurring_web_hook_key'] = $this->request->post['sipay_recurring_web_hook_key'];
        } else {
            $data['sipay_recurring_web_hook_key'] = $this->config->get('sipay_recurring_web_hook_key');
        }
		
		
		 if (isset($this->request->post['entry_sales_web_hook_url_help'])) {
            $data['entry_sales_web_hook_url_help'] = $this->request->post['entry_sales_web_hook_url_help'];
        } else {
            $data['entry_sales_web_hook_url_help'] = $this->config->get('entry_sales_web_hook_url_help');
        }
		
		 if (isset($this->request->post['sipay_short_order'])) {
            $data['sipay_short_order'] = $this->request->post['sipay_short_order'];
        } else {
            $data['sipay_short_order'] = $this->config->get('sipay_short_order');
        }
		
		 if (isset($this->request->post['sipay_label_for_checkout_page'])) {
            $data['sipay_label_for_checkout_page'] = $this->request->post['sipay_label_for_checkout_page'];
        } else {
            $data['sipay_label_for_checkout_page'] = $this->config->get('sipay_label_for_checkout_page');
        }
		
		 if (isset($this->request->post['sipay_payment_sipay_installment'])) {
            $data['sipay_payment_sipay_installment'] = $this->request->post['sipay_payment_sipay_installment'];
        } else {
            $data['sipay_payment_sipay_installment'] = $this->config->get('sipay_payment_sipay_installment');
        }
		
		
		
		 if (isset($this->request->post['sipay_app_secret'])) {
            $data['sipay_app_secret'] = $this->request->post['sipay_app_secret'];
        } else {
            $data['sipay_app_secret'] = $this->config->get('sipay_app_secret');
        }
		
		
		
		
		/* end shahrukh code */
		if($data['sipay_merchant_currency']=="TRY")
		{
			$data['entry_merchant'] = $this->language->get('entry_merchant_turkish');
			$data['entry_merchantkey'] = $this->language->get('entry_merchantkey_turkish');
			$data['entry_api_domain'] = $this->language->get('entry_api_domain_turkish');
			$data['entry_merchant_currency']= $this->language->get('entry_merchant_currency_turkish');
			$data['entry_app_id']= $this->language->get('entry_app_id_turkish');
			$data['entry_app_secret']= $this->language->get('entry_app_secret_turkish');
			$data['entry_enable_disable']= $this->language->get('entry_enable_disable_turkish');
			$data['entry_sales_web_hook_key']= $this->language->get('entry_sales_web_hook_key_turkish');
			$data['entry_recurring_web_hook_key']= $this->language->get('entry_recurring_web_hook_key_turkish');
			$data['entry_sales_web_hook_url']= $this->language->get('entry_sales_web_hook_url_turkish');
			$data['entry_recurring_web_hook_url']= $this->language->get('entry_recurring_web_hook_url_turkish');
			$data['entry_label_for_checkout_page']= $this->language->get('entry_label_for_checkout_page_turkish');
			$data['entry_installments']= $this->language->get('entry_installments_turkish');
			$data['entry_order_status']= $this->language->get('entry_order_status_turkish');
			$data['entry_status']= $this->language->get('entry_status_turkish');
			$data['entry_short_order']= $this->language->get('entry_short_order_turkish');
			$data['entry_geo_zones'] = $this->language->get('entry_geo_zones_turkish');
		}
		
		
		$post_url = $this->config->get('sipay_api_domain').'/ccpayment/api/token';
		$post = array(
			'app_secret' => $this->config->get('sipay_app_secret'), //sipay test merchant
			'app_id' => $this->config->get('sipay_app_id')
		);
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $post_url);
		
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
		
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
		$response = json_decode(curl_exec($ch),true);
		
		curl_close($ch);
		$url = $this->config->get('sipay_api_domain').'/ccpayment/api/installments';
		$headers=array(	
			'Authorization: Bearer '.$response['data']['token']
		);
		$post_content = array(
			'merchant_key' => $this->config->get('sipay_key')
		);
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url );
		
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_content);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
		$installments = json_decode(curl_exec($ch),true);
		curl_close($ch);
		
		
		$installment_options= array();
		if(isset($installments['status_code']) && $installments['status_code'] == 100 && !empty($installments['installments'])){
			foreach($installments['installments'] as $in => $installment){
				if($installment == 1)
					continue;

				$installment_options[$installment]= $installment; 

			}
		}
		$data['installments'] = $installment_options;
		
        $this->template = 'extension/payment/sipay.tpl';
        $this->children = array(
            'common/header',
            'common/footer'
        );
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');

        $data['footer'] = $this->load->controller('common/footer');
        //$this->response->setOutput($this->render());
        $this->response->setOutput($this->load->view('extension/payment/sipay.tpl', $data));

    }

    //validate function to ensure required fields are filled before proceeding
    protected function validate()
    {
		 
        if (!$this->user->hasPermission('modify', 'extension/payment/sipay')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }


 
        if (!$this->request->post['sipay_merchant']) {
			 
            $this->error['merchant'] = $this->language->get('error_merchant');
        } 
        if (!$this->request->post['sipay_key']) {
            $this->error['key'] = $this->language->get('error_key');
        }

        if (!$this->error) {
            return true;
        } else {
            return false;
        }
    }

    public function orderAction()
    {
		
    }
}

?>