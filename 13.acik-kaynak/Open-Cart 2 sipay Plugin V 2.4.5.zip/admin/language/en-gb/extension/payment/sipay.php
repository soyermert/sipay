<?php
// Heading
$_['heading_title']      = 'Sipay Payment';

// Text
$_['text_payment']       = 'Payment';
$_['text_success']       = 'Success: You have modified Sipay account details!';
$_['text_sipay']         = '<img src="view/image/payment/sipay.png"  alt="Sipay" title="Sipay" style="border: 1px solid #EEEEEE;width: 45px;" />';

$_['text_env_production']       = 'Production';
$_['text_env_sdb']       = 'Sandbox';

// Entry
$_['entry_merchant']     = 'Merchant ID';
$_['entry_merchant_help']     = 'Enter your merchant ID';
$_['entry_merchantkey']  = 'Merchant Key';
$_['entry_merchantkey_help']  = 'Enter your merchant key.';
$_['entry_order_status'] = 'Order Status';


// shahrukh





$_['error_key_domain']     = 'Enter your merchant Api Domain';
$_['entry_api_domain']  = 'Merchant API Domain';
$_['entry_api_domain_help']  = 'Enter your merchant Api Domain.';


$_['error_merchant_currency']     = 'Enter your Merchant Currency';
$_['entry_merchant_currency']  = 'Merchant Currency';
$_['entry_merchant_currency_help']  = 'Enter your Merchant Currency.';

$_['error_app_id']     = 'Enter your App ID';
$_['entry_app_id']  = 'App ID';
$_['entry_app_id_help']  = 'Enter your App ID.';

$_['error_app_secret']     = 'Enter your App Secret';
$_['entry_app_secret']  = 'App Secret';
$_['entry_app_secret_help']  = 'Enter your App Secret.';


$_['error_enable_disable']     = 'Choose your Enable/Disable';
$_['entry_enable_disable']  = 'Enable/Disable';
$_['entry_app_enable_disable_help']  = 'Choose your Enable/Disable.';



$_['error_sales_web_hook_key']     = 'Enter your Sale Web Hook Key';
$_['entry_sales_web_hook_key']  = 'Sale Web Hook Key';
$_['entry_sales_web_hook_key_help']  = 'Enter your Sale Web Hook Key.';


$_['error_recurring_web_hook_key']     = 'Enter your recurring Web Hook Key';
$_['entry_recurring_web_hook_key']  = 'Recurring Web Hook Key';
$_['entry_recurring_web_hook_key_help']  = 'Enter your recurring Web Hook Key.';

$_['error_sales_web_hook_url']     = 'Enter your Sale Web Hook Url';
$_['entry_sales_web_hook_url']  = 'Sale Web Hook URL';
$_['entry_sales_web_hook_url_help']  = 'Enter your Sale Web Hook Url.';


$_['error_recurring_web_hook_url']     = 'Enter your Recurring Web Hook Url';
$_['entry_recurring_web_hook_url']  = 'Recurring Web Hook URL';
$_['entry_recurring_web_hook_url_help']  = 'Enter your Recurring Web Hook Url.';


$_['error_label_for_checkout_page']     = 'Enter Label used at checkout page';
$_['entry_label_for_checkout_page']  = 'Label used at checkout page';
$_['entry_label_for_checkout_page_help']  = 'Enter your Recurring Web Hook Url.';

$_['error_installments']     = 'Select Installments';
$_['entry_installments']  = 'Installments';
$_['entry_installments_help']  = 'Select Installments.';

 
$_['entry_geo_zones']  = 'Geo Zone';
$_['entry_geo_zones_help']  = 'Select Geo Zone.';


$_['error_short_order']     = 'Enter Sort Order';
$_['entry_short_order']  = 'Sort Order';
$_['entry_short_order_help']  = 'Enter Sort Order.'; 
 
   
         
            
        
// end shahrukh



$_['entry_status']       = 'Plugin Status';
$_['entry_environment']       = 'Environment';
$_['entry_environment_help']       = 'Eg. Production/Sandbox';

$_['entry_total']	= 'Total';
$_['help_total']	= 'The checkout total the order must reach before this payment method becomes active.';

// Error
$_['error_permission']   = 'Warning: You do not have permission to modify Sipay account details!';
$_['error_merchant']     = 'Merchant ID Required!';
$_['error_key']          = 'Merchant Key Required!';

//For turkish
$_['entry_merchant_turkish']     = 'Üye işyeri ID';

$_['entry_merchantkey_turkish']  = 'Üye işyeri Anahtarı';

$_['entry_api_domain_turkish']  = 'Merchant API Domain';

$_['entry_merchant_currency_turkish']  = 'Üye işyeri  para birimi';

$_['entry_app_id_turkish']  = 'AppKey';

$_['entry_app_secret_turkish']  = 'App Secret';

$_['entry_enable_disable_turkish']  = 'Etkinleştir / Devre Dışı Bırak';

$_['entry_sales_web_hook_key_turkish']  = 'Satış Web Kancası Anahtar Adı';

$_['entry_recurring_web_hook_key_turkish']  = 'Yinelenen Web Kancası Anahtar Adı';

$_['entry_sales_web_hook_url_turkish']  = 'Satış Web Kancası URL';

$_['entry_recurring_web_hook_url_turkish']  = 'Yinelenen Web Kancası URL';

$_['entry_label_for_checkout_page_turkish']  = 'Ödeme sayfasında kullanılan etiket';

$_['entry_installments_turkish']  = 'Seçili Taksitleri Gösterme <br> Birden Fazla Seçim İçin (Shift) Kullanın';

$_['entry_order_status_turkish'] = 'Sipariş Durumu';

$_['entry_status_turkish']       = 'Plugin Durumu';

$_['entry_short_order_turkish']  = 'Sipariş türü';
$_['entry_geo_zones_turkish']  = 'Coğrafi Bölge';

?>
