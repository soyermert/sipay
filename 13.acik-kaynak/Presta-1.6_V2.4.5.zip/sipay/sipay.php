<?php
/*
* 2007-2016 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2016 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

if (!defined('_PS_VERSION_'))
	exit;

class Sipay extends PaymentModule
{
	protected $_html = '';
	protected $_postErrors = array();

	public $merchant_id;
	public $merchant_key;
	public $app_id;
	public $app_secret;
	public $merchant_currency;
	public $api_domain;
	public $recurring_webhook_key;
	public $sale_webhook_key;
	public $extra_mail_vars;
	public $enable_disable;
	public $installments;
	public $notification;
	public function __construct()
	{
		
		$this->name = 'sipay';
		$this->tab = 'payments_gateways';
		$this->version = '1.1.2';
		$this->author = 'PrestaShop';
		$this->controllers = array('payment', 'validation');
		$this->is_eu_compatible = 1;

		$this->currencies = true;
		$this->currencies_mode = 'checkbox';

		$config = Configuration::getMultiple(array('SIPAY_MERCHANT_ID', 'SIPAY_MERCHANT_KEY', 'SIPAY_APP_ID', 'SIPAY_APP_SECRET_KEY', 'SIPAY_MERCHANT_CURRENCY', 'SIPAY_API_DOMAIN','SIPAY_API_ButtonLabel','SIPAY_recurring_webhook','SIPAY_sale_webhook','SIPAY_enable_disable','SIPAY_installment','SIPAY_notification'));
		/*print_r($config);
		die();*/
		if (!empty($config['SIPAY_MERCHANT_ID']))
			$this->merchant_id = $config['SIPAY_MERCHANT_ID'];
		if (!empty($config['SIPAY_MERCHANT_KEY']))
			$this->merchant_key = $config['SIPAY_MERCHANT_KEY'];
		if (!empty($config['SIPAY_APP_ID']))
			$this->app_id = $config['SIPAY_APP_ID'];
		if (!empty($config['SIPAY_APP_SECRET_KEY']))
			$this->app_secret = $config['SIPAY_APP_SECRET_KEY'];
		if (!empty($config['SIPAY_MERCHANT_CURRENCY']))
			$this->merchant_currency = $config['SIPAY_MERCHANT_CURRENCY'];
		if (!empty($config['SIPAY_API_DOMAIN']))
			$this->api_domain = $config['SIPAY_API_DOMAIN'];
			
		if (!empty($config['SIPAY_API_ButtonLabel']))
			$this->api_buttonlabel = $config['SIPAY_API_ButtonLabel'];	
		if (!empty($config['SIPAY_recurring_webhook']))
			$this->recurring_webhook_key = $config['SIPAY_recurring_webhook'];
			
		if (!empty($config['SIPAY_sale_webhook']))
			$this->sale_webhook_key = $config['SIPAY_sale_webhook'];
		
		if (!empty($config['SIPAY_enable_disable']))
			$this->enable_disable = $config['SIPAY_enable_disable'];
		if (!empty($config['SIPAY_installment']))
			$this->installments = $config['SIPAY_installment'];
		if (!empty($config['SIPAY_notification']))
			$this->notification = $config['SIPAY_notification'];
			

		$this->bootstrap = true;
		parent::__construct();

		$this->displayName = $this->l('Sipay');
		$this->description = $this->l('Accept payments for your products via sipay transfer.');
		$this->confirmUninstall = $this->l('Are you sure about removing these details?');
		$this->ps_versions_compliancy = array('min' => '1.6', 'max' => '1.6.99.99');

		if (!isset($this->merchant_id) || !isset($this->merchant_key) || !isset($this->app_id) || !isset($this->app_secret) || !isset($this->merchant_currency) || !isset($this->api_domain))
			$this->warning = $this->l('All details must be configured before using this module.');
		if (!count(Currency::checkPaymentCurrencies($this->id)))
			$this->warning = $this->l('No currency has been set for this module.');

		$this->extra_mail_vars = array(
										'{sipay_merchant_id}' => nl2br(Configuration::get('SIPAY_MERCHANT_ID')),
										'{sipay_merchant_key}' => nl2br(Configuration::get('SIPAY_MERCHANT_KEY')),
										'{sipay_app_id}' => nl2br(Configuration::get('SIPAY_APP_ID')),
										'{sipay_app_secret_key}' => nl2br(Configuration::get('SIPAY_APP_SECRET_KEY')),
										'{sipay_merchant_currency}' => nl2br(Configuration::get('SIPAY_MERCHANT_CURRENCY')),
										'{sipay_api_domain}' => nl2br(Configuration::get('SIPAY_API_DOMAIN')),
										'{sipay_recurring_webhook_key}' => nl2br(Configuration::get('SIPAY_recurring_webhook')),
										'{sipay_sale_webhook_key}' => nl2br(Configuration::get('SIPAY_sale_webhook')),	
										'{sipay_enable_disable}' => nl2br(Configuration::get('SIPAY_enable_disable')),
										'{SIPAY_installment}' => nl2br(Configuration::get('SIPAY_installment')),					
										'{SIPAY_notification}' => nl2br(Configuration::get('SIPAY_notification')),									
										);
	}

	public function install()
	{
		
		
		if (!parent::install() || !$this->registerHook('payment') || ! $this->registerHook('displayPaymentEU') || !$this->registerHook('paymentReturn') || !$this->registerHook('displayAdminProductsExtra') || !$this->registerHook('actionProductUpdate')  || !$this->registerHook('actionCartSave') || !$this->registerHook('top') || !$this->registerHook('actionBeforeCartUpdateQty'))
			return false;
		return true;
	}
	
	public function hookActionBeforeCartUpdateQty($params)
	{	
		
	}
	
	public function hookTop($params)
	{
		
		//if(strpos($_SERVER["REQUEST_URI"],'payment')>0)	{
		
		if (!$this->context->cart) 
		{
			return false;
		}
		$cart_product_hwe = $this->context->cart->getProducts(true);
		
		$flag=0;
		if($cart_product_hwe>0)
		{
			foreach($cart_product_hwe as $cart_product)
			{
				$cart_product_id = $cart_product['id_product'];
				$cart_data = Db::getInstance()->ExecuteS('SELECT * FROM `' . _DB_PREFIX_ . 'recurring_fields` WHERE product_id='.$cart_product_id);
				if($cart_data[0]['status']==1)
				{
						$flag=1;
						break;
				}
				else
				{
					$flag=2;
					break;
				}
			}
		}
		
		if($flag == 1)
		{
			$error = "There is a recurring product in the basket.you cannot add normal product.";
		}
		if($flag == 2)
		{
			$error = "There is a normal product in the basket.you cannot add recurring product.";
		}
		$notification =  Configuration::get('SIPAY_notification');
		if($notification == 1)
		{				
			$this->smarty->assign('error', $error);
		}
		//$this->smarty->assign('error', $error);

        return $this->display(__FILE__, 'error.tpl');
		//}
	}
	
	public function hookActionCartSave()
	{
		
		
		// If cart doesn't exist or product is not being added to cart in ajax mode - do nothing
		if (!$this->context->cart || !Tools::getValue('id_product') || !Tools::getValue('add') || !Tools::getValue('ajax')) {
			return false;
		}
		$product_id = Tools::getValue('id_product');
		$cart_product_hwe = $this->context->cart->getProducts(true);
		
		$data = Db::getInstance()->ExecuteS('SELECT * FROM `' . _DB_PREFIX_ . 'recurring_fields` WHERE product_id='.$product_id);
		if($data[0]['status']==1)
		{
			if(count($cart_product_hwe)>1)
			{
				foreach($cart_product_hwe as $cart_product)
				{
					$cart_product_id = $cart_product['id_product'];
					
					$cart_data = Db::getInstance()->ExecuteS('SELECT * FROM `' . _DB_PREFIX_ . 'recurring_fields` WHERE product_id='.$cart_product_id);
					if($cart_data[0]['status']==1)
					{
						
							$this->context->cart->deleteProduct($product_id);
							$error = "You have recurring product in your cart so you can not add other product.";
					}
					else
					{
						$error = "You have a simple product in your cart so you can not add recurring product.";
						
					}
				}
			}
		}
		else
		{
			if(count($cart_product_hwe)>1)
			{
				foreach($cart_product_hwe as $cart_product)
				{
					$cart_product_id = $cart_product['id_product'];
					
					if($cart_product_id != $product_id)
					{
						$cart_data_2 = Db::getInstance()->ExecuteS('SELECT * FROM `' . _DB_PREFIX_ . 'recurring_fields` WHERE product_id='.$cart_product_id);
						if($cart_data_2[0]['status']==1)
						{
							$this->context->cart->deleteProduct($product_id);
							$error = "You have recurring product in your cart so you can not add other product.";
							
						}
					}
				}
			}
		}
			//You can do custom logic here if you want to display message only			on some conditions
		
		$this->context->smarty->assign('mycartpopupmessage', $this->l('Message'));
	
		return false;
	}

	//Saving Data
	public function hookActionProductUpdate($params) {
		
		 Db::getInstance()->execute(
		   'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'recurring_fields` (
				`id` int(11) NOT NULL AUTO_INCREMENT,
				`product_id` int(11) NOT NULL,
				`no_of_payments` int(11) NOT NULL,
				`order_frequency_cycle` varchar(100) NOT NULL,
				`order_frequency_interval` int(11) NOT NULL,
				`status` int(11),
				PRIMARY KEY (`id`)
				)'
		);
				
		
		
		$id_product = Tools::getValue('id_product');
		
		$recurring_checkbox = Tools::getValue('recuring_Checkbox_hwe');
		if(empty($recurring_checkbox))
		{
			$recurring_checkbox=0;
		}
		$no_of_payments = Tools::getValue('recuring_no_of_payments');
		
		$order_frequency_cycle = Tools::getValue('recuring_order_frequency_cycle');
		
		$order_frequency_interval = Tools::getValue('recuring_order_frequency_interval');
		//echo 'SELECT * FROM `' . _DB_PREFIX_ . 'recurring_fields` WHERE product_id='.$id_product;
		
		$data = Db::getInstance()->ExecuteS('SELECT * FROM `' . _DB_PREFIX_ . 'recurring_fields` WHERE product_id='.$id_product);
		if(count($data)>0)
		{
			Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . 'recurring_fields` SET no_of_payments='.$no_of_payments.',order_frequency_cycle="'.$order_frequency_cycle.'",order_frequency_interval='.$order_frequency_interval.', status='.$recurring_checkbox.' WHERE product_id='.$id_product);
		}
		else
		{
			Db::getInstance()->execute('INSERT INTO `' . _DB_PREFIX_ . 'recurring_fields` SET product_id='.$id_product.',no_of_payments='.$no_of_payments.',order_frequency_cycle="'.$order_frequency_cycle.'",order_frequency_interval='.$order_frequency_interval.', status='.$recurring_checkbox);
		}
		
	}
	//Preparing data for the form
	public function hookdisplayAdminProductsExtra($params) {
		$id_product = Tools::getValue('id_product');
		$data = Db::getInstance()->ExecuteS('SELECT * FROM `' . _DB_PREFIX_ . 'recurring_fields` WHERE product_id='.$id_product);
		
		$this->smarty->assign(array(
			'no_of_payments' => $data[0]['no_of_payments'],
			'order_frequency_cycle' => $data[0]['order_frequency_cycle'],
			'order_frequency_interval' => $data[0]['order_frequency_interval'],
			'status' => $data[0]['status'],
		));
		
 
		return $this->display(__FILE__, 'views/admin/extrafields.tpl');
	}
	 
	 public function setMedia()
    {
		parent::setMedia(); 
	
			//$this->addCSS(_THEME_CSS_DIR_.'modules/blockuserinfo/blockuserinfo.css', 'all');
			$this->registerStylesheet(_THEME_CSS_DIR_, 'modules/blockuserinfo/blockuserinfo.css', [‘media’ => ‘all’, ‘priority’ => 0]);
	}

	public function uninstall()
	{
		if (!Configuration::deleteByName('SIPAY_MERCHANT_ID')
				|| !Configuration::deleteByName('SIPAY_MERCHANT_KEY')
				|| !Configuration::deleteByName('SIPAY_APP_ID')
				|| !Configuration::deleteByName('SIPAY_APP_SECRET_KEY')
				|| !Configuration::deleteByName('SIPAY_API_DOMAIN')
				|| !Configuration::deleteByName('SIPAY_MERCHANT_CURRENCY')
				|| !Configuration::deleteByName('SIPAY_API_ButtonLabel')
				|| !Configuration::deleteByName('SIPAY_recurring_webhook')
				|| !Configuration::deleteByName('SIPAY_sale_webhook')
				|| !Configuration::deleteByName('SIPAY_enable_disable')
				|| !Configuration::deleteByName('SIPAY_installment')
				|| !Configuration::deleteByName('SIPAY_notification')
				|| !parent::uninstall())
			return false;
		return true;
	}
	
	public function hookDisplayHeader($params)
	{
		
		$this->context->controller->addCSS(_THEME_CSS_DIR_.'modules/blockuserinfo/blockuserinfo.css', 'all');
	}

	protected function _postValidation()
	{
		if (Tools::isSubmit('btnSubmit'))
		{
			if (!Tools::getValue('SIPAY_MERCHANT_ID'))
				$this->_postErrors[] = $this->l('Merchant ID are required.');
			elseif (!Tools::getValue('SIPAY_MERCHANT_KEY'))
				$this->_postErrors[] = $this->l('Merchant key is required.');
			elseif (!Tools::getValue('SIPAY_APP_ID'))
				$this->_postErrors[] = $this->l('App ID is required.');
			elseif (!Tools::getValue('SIPAY_APP_SECRET_KEY'))
				$this->_postErrors[] = $this->l('App secret is required.');
			elseif (!Tools::getValue('SIPAY_API_DOMAIN'))
				$this->_postErrors[] = $this->l('api domain is required.');
			elseif (!Tools::getValue('SIPAY_MERCHANT_CURRENCY'))
				$this->_postErrors[] = $this->l('Merhcant currency is required.');
			/*elseif (!Tools::getValue('SIPAY_recurring_webhook'))
				$this->_postErrors[] = $this->l('Recurring web hook key is required.');*/
			
		}
	}

	protected function _postProcess()
	{
		if (Tools::isSubmit('btnSubmit'))
		{
			$sipay_installment = implode(',',Tools::getValue('SIPAY_installment'));
						
			Configuration::updateValue('SIPAY_MERCHANT_ID', Tools::getValue('SIPAY_MERCHANT_ID'));
			Configuration::updateValue('SIPAY_MERCHANT_KEY', Tools::getValue('SIPAY_MERCHANT_KEY'));
			Configuration::updateValue('SIPAY_APP_ID', Tools::getValue('SIPAY_APP_ID'));
			Configuration::updateValue('SIPAY_APP_SECRET_KEY', Tools::getValue('SIPAY_APP_SECRET_KEY'));
			Configuration::updateValue('SIPAY_API_DOMAIN', Tools::getValue('SIPAY_API_DOMAIN'));
			Configuration::updateValue('SIPAY_MERCHANT_CURRENCY', Tools::getValue('SIPAY_MERCHANT_CURRENCY'));
			Configuration::updateValue('SIPAY_API_ButtonLabel', Tools::getValue('SIPAY_API_ButtonLabel'));
			Configuration::updateValue('SIPAY_recurring_webhook', Tools::getValue('SIPAY_recurring_webhook'));
			Configuration::updateValue('SIPAY_sale_webhook', Tools::getValue('SIPAY_sale_webhook'));
			Configuration::updateValue('SIPAY_enable_disable', Tools::getValue('SIPAY_enable_disable'));
			Configuration::updateValue('SIPAY_installment', implode(',',Tools::getValue('SIPAY_installment')));
			Configuration::updateValue('SIPAY_notification', Tools::getValue('SIPAY_notification'));
		}
		$this->_html .= $this->displayConfirmation($this->l('Settings updated'));
	}

	protected function _displayBankWire()
	{
		return $this->display(__FILE__, 'infos.tpl');
	}

	public function getContent()
	{
		if (Tools::isSubmit('btnSubmit'))
		{
			$this->_postValidation();
			if (!count($this->_postErrors))
				$this->_postProcess();
			else
				foreach ($this->_postErrors as $err)
					$this->_html .= $this->displayError($err);
		}
		else
			$this->_html .= '<br />';

		$this->_html .= $this->_displayBankWire();
		$this->_html .= $this->renderForm();

		return $this->_html;
	}

	public function hookPayment($params)
	{
		if (!$this->active)
			return;
		if (!$this->checkCurrency($params['cart']))
			return;

		$this->smarty->assign(array(
			'this_path' => $this->_path,
			'this_path_bw' => $this->_path,
			'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->name.'/'
		));
		return $this->display(__FILE__, 'payment.tpl');
	}

	public function hookDisplayPaymentEU($params)
	{
		if (!$this->active)
			return;

		if (!$this->checkCurrency($params['cart']))
			return;

		$payment_options = array(
			'cta_text' => $this->l('Pay with SiPay'),
			'logo' => Media::getMediaPath(_PS_MODULE_DIR_.$this->name.'/SiPay.png'),
			'action' => $this->context->link->getModuleLink($this->name, 'validation', array(), true)
		);

		return $payment_options;
	}

	public function hookPaymentReturn($params)
	{
		
		if (!$this->active)
			return;

		$state = $params['objOrder']->getCurrentState();
		if (in_array($state, array(Configuration::get('PS_OS_PAYMENT'), Configuration::get('PS_OS_OUTOFSTOCK'), Configuration::get('PS_OS_OUTOFSTOCK_UNPAID'))))
		{
			$this->smarty->assign(array(
				'total_to_pay' => Tools::displayPrice($params['total_to_pay'], $params['currencyObj'], false),
				'sipaymerchantkey' => Tools::nl2br($this->merchant_key),
				'sipaymerchantid' => Tools::nl2br($this->merchant_id),
				'sipayappid' => Tools::nl2br($this->app_id),
				'sipayappsecret' => Tools::nl2br($this->app_secret),
				'sipaymerchantcurrency' => Tools::nl2br($this->merchant_currency),
				'sipayapidomain' => Tools::nl2br($this->api_domain),
				'status' => 'ok',
				'id_order' => $params['objOrder']->id
			));
			if (isset($params['objOrder']->reference) && !empty($params['objOrder']->reference))
				$this->smarty->assign('reference', $params['objOrder']->reference);
		}
		else
			$this->smarty->assign('status', 'failed');
		return $this->display(__FILE__, 'payment_return.tpl');
	}

	public function checkCurrency($cart)
	{
		$currency_order = new Currency($cart->id_currency);
		$currencies_module = $this->getCurrency($cart->id_currency);

		if (is_array($currencies_module))
			foreach ($currencies_module as $currency_module)
				if ($currency_order->id == $currency_module['id_currency'])
					return true;
		return false;
	}
	


	public function renderForm()
	{
		//get installments number start
		$post_url = Configuration::get('SIPAY_API_DOMAIN').'/ccpayment/api/token';
		
		$post = array(   
			'app_secret' => Configuration::get('SIPAY_APP_SECRET_KEY'), //sipay test merchant
			'app_id' => Configuration::get('SIPAY_APP_ID')
		);
    	$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $post_url);
		
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
		
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
		$response = json_decode(curl_exec($ch),true);
		
		curl_close($ch);
		
		$url = Configuration::get('SIPAY_API_DOMAIN').'/ccpayment/api/installments';
		
		$headers=array(
			//'Accept: application/json',
			//'Content-Type: application/json',
			'Authorization: Bearer '.$response['data']['token']
			);
		//print_r($headers);
		$post_content = array(
			'merchant_key' => Configuration::get('SIPAY_MERCHANT_KEY')
		);
		
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url );
		
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_content);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
		
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
		$installments = json_decode(curl_exec($ch),true);
		//print_r($get_pos_response);
		
		curl_close($ch);
		$installment_options= array();
		if(isset($installments['status_code']) && $installments['status_code'] == 100 && !empty($installments['installments'])){
			foreach($installments['installments'] as $in => $installment){
				if($installment == 1)
					continue;
				$installment_options[$installment]= $installment; 

			}
		}
		$installment_array = array();
		foreach($installment_options as $key=>$value)
		{
			$installment_array[]= array(
				'key' => $key,
				'name' => $value
			);
		}
		if(Configuration::get('SIPAY_MERCHANT_CURRENCY')=="TRY")
		{
			$MerchantKey = 'Üye işyeri Anahtarı';
			$MerchantID ='Üye işyeri ID';
			$AppID ='AppKey';
			$AppSecret ='App Secret';
			$MerchantCurrency ='Üye işyeri  para birimi';
			$Apidomain ='Api domain';
			$LabelOfButton ='Ödeme sayfasında kullanılan etiket';
			$Enable_Disable ='Etkinleştir / Devre Dışı Bırak';
			$SaleWebHookKey ='Satış Web Kancası Anahtar Adı';
			$RecurringWebHookKey ='Yinelenen Web Kancası Anahtar Adı';
			$SalewebhookURL ='Satış Web Kancası URL';
			$RecurringwebhookURL ='Yinelenen Web Kancası URL';
			$Installments ='Taksitler';
			$check_checkboxs ='Taksit bloğunu  devre dışı bırakmak için lütfen onay kutusunu işaretleyin.';
			$notification = 'Bildirimleri göster';
		}
		else
		{
			$MerchantKey = 'Merchant Key';
			$MerchantID ='Merchant ID';
			$AppID ='App ID';
			$AppSecret ='App Secret';
			$MerchantCurrency ='Merchant Currency';
			$Apidomain ='Api domain';
			$LabelOfButton ='Label used at checkout page ';
			$Enable_Disable ='Enable/Disable';
			$SaleWebHookKey ='Sale Web Hook Key';
			$RecurringWebHookKey ='Recurring Web Hook Key';
			$SalewebhookURL ='Sale web hook URL';
			$RecurringwebhookURL ='Recurring web hook URL';
			$Installments ='Installments';
			$check_checkboxs = 'Please check the checkbox to disable installment block.';
			$notification = 'Show notification';
		}	
		//get installments number end
		$fields_form = array(
			'form' => array(
				'legend' => array(
					'title' => $this->l('Account details'),
					'icon' => 'icon-envelope'
				),
				'input' => array(
					array(
						'type' => 'text',
						'label' => $this->l($MerchantKey),
						'name' => 'SIPAY_MERCHANT_KEY',
						'required' => true
					),
					array(
						'type' => 'text',
						'label' => $this->l($MerchantID),
						'name' => 'SIPAY_MERCHANT_ID',
						'required' => true
					),
					
					array(
						'type' => 'text',
						'label' => $this->l($AppID),
						'name' => 'SIPAY_APP_ID',
						'required' => true
					),
					array(
						'type' => 'text',
						'label' => $this->l($AppSecret),
						'name' => 'SIPAY_APP_SECRET_KEY',
						'required' => true
					),
					array(
						'type' => 'select',
						'label' => $this->l($MerchantCurrency),
						'name' => 'SIPAY_MERCHANT_CURRENCY',
						'required' => true,
						'options' => array(
							'query' => array(
								array('key' => 'AED', 'name' => 'United Arab Emirates dirham (د.إ)'),
								array('key' => 'AFN', 'name' => 'Afghan afghani (؋)'),
								array('key' => 'ALL', 'name' => 'Albanian lek (L)'),
								array('key' => 'AMD', 'name' => 'Armenian dram (AMD)'),
								array('key' => 'ANG', 'name' => 'Netherlands Antillean guilder (ƒ)'),
								array('key' => 'AOA', 'name' => 'Angolan kwanza (Kz)'),
								array('key' => 'ARS', 'name' => 'Argentine peso ($)'),
								array('key' => 'AUD', 'name' => 'Australian dollar ($)'),
								array('key' => 'AWG', 'name' => 'Aruban florin (Afl.)'),
								array('key' => 'AZN', 'name' => 'Azerbaijani manat (AZN)'),
								array('key' => 'BAM', 'name' => 'Bosnia and Herzegovina convertible mark (KM)'),
								array('key' => 'BBD', 'name' => 'Barbadian dollar ($)'),
								array('key' => 'BDT', 'name' => 'Bangladeshi taka (৳&nbsp;)'),
								array('key' => 'BGN', 'name' => 'Bulgarian lev (лв.)'),
								array('key' => 'BHD', 'name' => 'Bahraini dinar (.د.ب)'),
								array('key' => 'BIF', 'name' => 'Burundian franc (Fr)'),
								array('key' => 'BMD', 'name' => 'Bermudian dollar ($)'),
								array('key' => 'BND', 'name' => 'Brunei dollar ($)'),
								array('key' => 'BOB', 'name' => 'Bolivian boliviano (Bs.)'),
								array('key' => 'BRL', 'name' => 'Brazilian real (R$)'),
								array('key' => 'BSD', 'name' => 'Bahamian dollar ($)'),
								array('key' => 'BTC', 'name' => 'Bitcoin (฿)'),
								array('key' => 'BTN', 'name' => 'Bhutanese ngultrum (Nu.)'),
								array('key' => 'BWP', 'name' => 'Botswana pula (P)'),
								array('key' => 'BYR', 'name' => 'Belarusian ruble (old) (Br)'),
								array('key' => 'BYN', 'name' => 'Belarusian ruble (Br)'),
								array('key' => 'BZD', 'name' => 'Belize dollar ($)'),
								array('key' => 'CAD', 'name' => 'Canadian dollar ($)'),
								array('key' => 'CDF', 'name' => 'Congolese franc (Fr)'),
								array('key' => 'CHF', 'name' => 'Swiss franc (CHF)'),
								array('key' => 'CLP', 'name' => 'Chilean peso ($)'),
								array('key' => 'CNY', 'name' => 'Chinese yuan (¥)'),
								array('key' => 'COP', 'name' => 'Colombian peso ($)'),
								array('key' => 'CRC', 'name' => 'Costa Rican colón (₡)'),
								array('key' => 'CUC', 'name' => 'Cuban convertible peso ($)'),
								array('key' => 'CUP', 'name' => 'Cuban peso ($)'),
								array('key' => 'CVE', 'name' => 'Cape Verdean escudo ($)'),
								array('key' => 'CZK', 'name' => 'Czech koruna (Kč)'),
								array('key' => 'DJF', 'name' => 'Djiboutian franc (Fr)'),
								array('key' => 'DKK', 'name' => 'Danish krone (DKK)'),
								array('key' => 'DOP', 'name' => 'Dominican peso (RD$)'),
								array('key' => 'DZD', 'name' => 'Algerian dinar (د.ج)'),
								array('key' => 'EGP', 'name' => 'Egyptian pound (EGP)'),
								array('key' => 'ERN', 'name' => 'Eritrean nakfa (Nfk)'),
								array('key' => 'ETB', 'name' => 'Ethiopian birr (Br)'),
								array('key' => 'EUR', 'name' => 'Euro (€)'),
								array('key' => 'FJD', 'name' => 'Fijian dollar ($)'),
								array('key' => 'FKP', 'name' => 'Falkland Islands pound (£)'),
								array('key' => 'GBP', 'name' => 'Pound sterling (£)'),
								array('key' => 'GEL', 'name' => 'Georgian lari (₾)'),
								array('key' => 'GGP', 'name' => 'Guernsey pound (£)'),
								array('key' => 'GHS', 'name' => 'Ghana cedi (₵)'),
								array('key' => 'GIP', 'name' => 'Gibraltar pound (£)'),
								array('key' => 'GMD', 'name' => 'Gambian dalasi (D)'),
								array('key' => 'GNF', 'name' => 'Guinean franc (Fr)'),
								array('key' => 'GTQ', 'name' => 'Guatemalan quetzal (Q)'),
								array('key' => 'GYD', 'name' => 'Guyanese dollar ($)'),
								array('key' => 'HKD', 'name' => 'Hong Kong dollar ($)'),
								array('key' => 'HNL', 'name' => 'Honduran lempira (L)'),
								array('key' => 'HRK', 'name' => 'Croatian kuna (kn)'),
								array('key' => 'HTG', 'name' => 'Haitian gourde (G)'),
								array('key' => 'HUF', 'name' => 'Hungarian forint (Ft)'),
								array('key' => 'IDR', 'name' => 'Indonesian rupiah (Rp)'),
								array('key' => 'ILS', 'name' => 'Israeli new shekel (₪)'),
								array('key' => 'IMP', 'name' => 'Manx pound (£)'),
								array('key' => 'INR', 'name' => 'Indian rupee (₹)'),
								array('key' => 'IQD', 'name' => 'Iraqi dinar (ع.د)'),
								array('key' => 'IRR', 'name' => 'Iranian rial (﷼)'),
								array('key' => 'IRT', 'name' => 'Iranian toman (تومان)'),
								array('key' => 'ISK', 'name' => 'Icelandic króna (kr.)'),
								array('key' => 'JEP', 'name' => 'Jersey pound (£)'),
								array('key' => 'JMD', 'name' => 'Jamaican dollar ($)'),
								array('key' => 'JOD', 'name' => 'Jordanian dinar (د.ا)'),
								array('key' => 'JPY', 'name' => 'Japanese yen (¥)'),
								array('key' => 'KES', 'name' => 'Kenyan shilling (KSh)'),
								array('key' => 'KGS', 'name' => 'Kenyan shilling (KSh)'),
								array('key' => 'KHR', 'name' => 'Cambodian riel (៛)'),
								array('key' => 'KMF', 'name' => 'Comorian franc (Fr)'),
								array('key' => 'KPW', 'name' => 'North Korean won (₩)'),
								array('key' => 'KRW', 'name' => 'South Korean won (₩)'),
								array('key' => 'KWD', 'name' => 'Kuwaiti dinar (د.ك)'),
								array('key' => 'KYD', 'name' => 'Cayman Islands dollar ($)'),
								array('key' => 'KZT', 'name' => 'Kazakhstani tenge (₸)'),
								array('key' => 'LAK', 'name' => 'Lao kip (₭)'),
								array('key' => 'LBP', 'name' => 'Lebanese pound (ل.ل)'),
								array('key' => 'LKR', 'name' => 'Sri Lankan rupee (රු)'),
								array('key' => 'LRD', 'name' => 'Liberian dollar ($)'),
								array('key' => 'LSL', 'name' => 'Lesotho loti (L)'),
								array('key' => 'LYD', 'name' => 'Libyan dinar (ل.د)'),
								array('key' => 'MAD', 'name' => 'Moroccan dirham (د.م.)'),
								array('key' => 'MDL', 'name' => 'Moldovan leu (MDL)'),
								array('key' => 'MGA', 'name' => 'Malagasy ariary (Ar)'),
								array('key' => 'MKD', 'name' => 'Macedonian denar (ден)'),
								array('key' => 'MMK', 'name' => 'Burmese kyat (Ks)'),
								array('key' => 'MNT', 'name' => 'Mongolian tögrög (₮)'),
								array('key' => 'MOP', 'name' => 'Macanese pataca (P)'),
								array('key' => 'MRU', 'name' => 'Mauritanian ouguiya (UM)'),
								array('key' => 'MUR', 'name' => 'Mauritian rupee (₨)'),
								array('key' => 'MVR', 'name' => 'Maldivian rufiyaa (.ރ)'),
								array('key' => 'MWK', 'name' => 'Malawian kwacha (MK)'),
								array('key' => 'MXN', 'name' => 'Mexican peso ($)'),
								array('key' => 'MYR', 'name' => 'Malaysian ringgit (RM)'),
								array('key' => 'MZN', 'name' => 'Mozambican metical (MT)'),
								array('key' => 'NAD', 'name' => 'Namibian dollar (N$)'),
								array('key' => 'NGN', 'name' => 'Nigerian naira (₦)'),
								array('key' => 'NIO', 'name' => 'Nicaraguan córdoba (C$)'),
								array('key' => 'NOK', 'name' => 'Norwegian krone (kr)'),
								array('key' => 'NPR', 'name' => 'Nepalese rupee (₨)'),
								array('key' => 'NZD', 'name' => 'New Zealand dollar ($)'),
								array('key' => 'OMR', 'name' => 'Omani rial (ر.ع.)'),
								array('key' => 'PAB', 'name' => 'Panamanian balboa (B/.)'),
								array('key' => 'PEN', 'name' => 'Sol (S/)'),
								array('key' => 'PGK', 'name' => 'Papua New Guinean kina (K)'),
								array('key' => 'PHP', 'name' => 'Philippine peso (₱)'),
								array('key' => 'PKR', 'name' => 'Pakistani rupee (₨)'),
								array('key' => 'PLN', 'name' => 'Polish złoty (zł)'),
								array('key' => 'PRB', 'name' => 'Transnistrian ruble (р.)'),
								array('key' => 'PYG', 'name' => 'Paraguayan guaraní (₲)'),
								array('key' => 'QAR', 'name' => 'Qatari riyal (ر.ق)'),
								array('key' => 'RON', 'name' => 'Romanian leu (lei)'),
								array('key' => 'RSD', 'name' => 'Serbian dinar (рсд)'),
								array('key' => 'RUB', 'name' => 'Russian ruble (₽)'),
								array('key' => 'RWF', 'name' => 'Rwandan franc (Fr)'),
								array('key' => 'SAR', 'name' => 'Saudi riyal (ر.س)'),
								array('key' => 'SBD', 'name' => 'Solomon Islands dollar ($)'),
								array('key' => 'SCR', 'name' => 'Seychellois rupee (₨)'),
								array('key' => 'SDG', 'name' => 'Sudanese pound (ج.س.)'),
								array('key' => 'SEK', 'name' => 'Swedish krona (kr)'),
								array('key' => 'SGD', 'name' => 'Singapore dollar ($)'),
								array('key' => 'SGD', 'name' => 'Saint Helena pound (£)'),
								array('key' => 'SLL', 'name' => 'Sierra Leonean leone (Le)'),
								array('key' => 'SOS', 'name' => 'Somali shilling (Sh)'),
								array('key' => 'SRD', 'name' => 'Surinamese dollar ($)'),
								array('key' => 'SSP', 'name' => 'South Sudanese pound (£)'),
								array('key' => 'STN', 'name' => 'São Tomé and Príncipe dobra (Db)'),
								array('key' => 'SYP', 'name' => 'Syrian pound (ل.س)'),
								array('key' => 'SZL', 'name' => 'Swazi lilangeni (L)'),
								array('key' => 'THB', 'name' => 'Thai baht (฿)'),
								array('key' => 'TJS', 'name' => 'Tajikistani somoni (ЅМ)'),
								array('key' => 'TMT', 'name' => 'Turkmenistan manat (m)'),
								array('key' => 'TND', 'name' => 'Tunisian dinar (د.ت)'),
								array('key' => 'TOP', 'name' => 'Tongan paʻanga (T$)'),
								array('key' => 'TRY', 'name' => 'Turkish lira (₺)'),
								array('key' => 'TTD', 'name' => 'Trinidad and Tobago dollar ($)'),
								array('key' => 'TWD', 'name' => 'New Taiwan dollar (NT$)'),
								array('key' => 'TZS', 'name' => 'Tanzanian shilling (Sh)'),
								array('key' => 'UAH', 'name' => 'Ukrainian hryvnia (₴)'),
								array('key' => 'UGX', 'name' => 'Ugandan shilling (UGX)'),
								array('key' => 'USD', 'name' => 'United States (US) dollar ($)'),
								array('key' => 'UYU', 'name' => 'Uruguayan peso ($)'),
								array('key' => 'UZS', 'name' => 'Uzbekistani som (UZS)'),
								array('key' => 'VEF', 'name' => 'Venezuelan bolívar (Bs F)'),
								array('key' => 'VES', 'name' => 'Bolívar soberano (Bs.S)'),
								array('key' => 'VND', 'name' => 'Vietnamese đồng (₫)'),
								array('key' => 'VUV', 'name' => 'Vanuatu vatu (Vt)'),
								array('key' => 'WST', 'name' => 'Samoan tālā (T)'),
								array('key' => 'XAF', 'name' => 'Central African CFA franc (CFA)'),
								array('key' => 'XCD', 'name' => 'East Caribbean dollar ($)'),
								array('key' => 'XOF', 'name' => 'West African CFA franc (CFA)'),
								array('key' => 'XPF', 'name' => 'CFP franc (Fr)'),
								array('key' => 'YER', 'name' => 'Yemeni rial (﷼)'),
								array('key' => 'ZAR', 'name' => 'South African rand (R)'),
								array('key' => 'ZMW', 'name' => 'Zambian kwacha (ZK)')								
							),
							'id' => 'key',
							'name' => 'name'
						)
					),
					array(
						'type' => 'text',
						'label' => $this->l($Apidomain),
						'name' => 'SIPAY_API_DOMAIN',
						'required' => true
					),
					
					
					array(
						'type' => 'text',
						'label' => $this->l($LabelOfButton),
						'name' => 'SIPAY_API_ButtonLabel',
						'required' => true
					),
					/*array(
						'type' => 'checkbox',
						'label' => $this->l('Enable/Disable'),
						'name' => 'SIPAY_enable_disable',
						'desc' => $this->l('Enable/Disable Installment Blocks')
					),*/
					array(
						'type' => 'select',
						'label' => $this->l($Enable_Disable),
						'name' => 'SIPAY_enable_disable',
						'desc' => $this->l($check_checkboxs),
						'options' => array(
							'query' => array(
								array('key' => '1', 'name' => 'Enable'),
								array('key' => '0', 'name' => 'Disable')
							),
							'id' => 'key',
							'name' => 'name'
						)
					),
					array(
						'type' => 'select',
						'label' => $this->l($notification),
						'name' => 'SIPAY_notification',
						'options' => array(
							'query' => array(
								array('key' => '1', 'name' => 'Enable'),
								array('key' => '0', 'name' => 'Disable')
							),
							'id' => 'key',
							'name' => 'name'
						)
					),
					array(
						'type' => 'text',
						'label' => $this->l($SaleWebHookKey),
						'name' => 'SIPAY_sale_webhook'
					),
					array(
						'type' => 'text',
						'label' => $this->l($RecurringWebHookKey),
						'name' => 'SIPAY_recurring_webhook'
					),
					array(
						 'desc' =>  Tools::getHttpHost(true).__PS_BASE_URI__.$this->l('index.php?fc=module&module=sipay&controller=salewebhook'),
           				 'label' => $SalewebhookURL
					),
					array(
						 'desc' =>  Tools::getHttpHost(true).__PS_BASE_URI__.$this->l('index.php?fc=module&module=sipay&controller=recurringwebhook'),
           				 'label' => $RecurringwebhookURL
					),
					array(
						'type' => 'select',
						'multiple' => true,
						'label' => $this->l($Installments),
						'name' => 'SIPAY_installment[]',
						'options' => array(
							'query' => $installment_array,
							'id' => 'key',
							'name' => 'name'
						)
					),
				),
				'submit' => array(
					'title' => $this->l('Save'),
				)
			),
		);

		$helper = new HelperForm();
		$helper->show_toolbar = false;
		$helper->table = $this->table;
		$lang = new Language((int)Configuration::get('PS_LANG_DEFAULT'));
		$helper->default_form_language = $lang->id;
		$helper->allow_employee_form_lang = Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') ? Configuration::get('PS_BO_ALLOW_EMPLOYEE_FORM_LANG') : 0;
		$this->fields_form = array();
		$helper->id = (int)Tools::getValue('id_carrier');
		$helper->identifier = $this->identifier;
		$helper->submit_action = 'btnSubmit';
		$helper->currentIndex = $this->context->link->getAdminLink('AdminModules', false).'&configure='.$this->name.'&tab_module='.$this->tab.'&module_name='.$this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->tpl_vars = array(
			'fields_value' => $this->getConfigFieldsValues(),
			'languages' => $this->context->controller->getLanguages(),
			'id_language' => $this->context->language->id
		);

		return $helper->generateForm(array($fields_form));
	}

	public function getConfigFieldsValues()
	{		
		return array(
			'SIPAY_MERCHANT_ID' => Tools::getValue('SIPAY_MERCHANT_ID', Configuration::get('SIPAY_MERCHANT_ID')),
			'SIPAY_MERCHANT_KEY' => Tools::getValue('SIPAY_MERCHANT_KEY', Configuration::get('SIPAY_MERCHANT_KEY')),
			'SIPAY_APP_ID' => Tools::getValue('SIPAY_APP_ID', Configuration::get('SIPAY_APP_ID')),
			'SIPAY_APP_SECRET_KEY' => Tools::getValue('SIPAY_APP_SECRET_KEY', Configuration::get('SIPAY_APP_SECRET_KEY')),
			'SIPAY_API_DOMAIN' => Tools::getValue('SIPAY_API_DOMAIN', Configuration::get('SIPAY_API_DOMAIN')),
			'SIPAY_MERCHANT_CURRENCY' => Tools::getValue('SIPAY_MERCHANT_CURRENCY', Configuration::get('SIPAY_MERCHANT_CURRENCY')),
			'SIPAY_API_ButtonLabel' => Tools::getValue('SIPAY_API_ButtonLabel', Configuration::get('SIPAY_API_ButtonLabel')),
			'SIPAY_recurring_webhook' => Tools::getValue('SIPAY_recurring_webhook', Configuration::get('SIPAY_recurring_webhook')),
			'SIPAY_sale_webhook' => Tools::getValue('SIPAY_sale_webhook', Configuration::get('SIPAY_sale_webhook')),
			'SIPAY_enable_disable' => Tools::getValue('SIPAY_enable_disable', Configuration::get('SIPAY_enable_disable')),
			'SIPAY_notification' => Tools::getValue('SIPAY_notification', Configuration::get('SIPAY_notification')),
			'SIPAY_installment[]' =>explode(',',Configuration::get('SIPAY_installment'))
		);
	}
}
