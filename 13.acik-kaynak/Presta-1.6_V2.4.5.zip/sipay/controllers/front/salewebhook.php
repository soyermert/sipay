<?php
/*
* 2007-2016 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2016 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since 1.5.0
 */
class SipaySalewebhookModuleFrontController extends ModuleFrontController
{
	/**
	 * @see FrontController::postProcess()
	 */
	public function postProcess()
	{		
		parent::initContent();
	
		$baseurl = Tools::getHttpHost(true).__PS_BASE_URI__;
		
		$order_cart_id = $_REQUEST['order_id'];
			
		$order_id = Order::getOrderByCartId((int)($order_cart_id));
		
		$salewebhook_data = Db::getInstance()->ExecuteS('SELECT * FROM `' . _DB_PREFIX_ . 'sale_webhook_fields` WHERE order_id='.$order_id);
		foreach($salewebhook_data as $data)
		{
			$salewebhook_data = $data;
		}
		$sipay_3d = json_decode($salewebhook_data['sipay_payment_info']);
		$sipay_payheaders=array(
			'Accept: application/json',
			'Content-Type: application/json'
			);
		if($sipay_3d->sipay_3d == 4 || $sipay_3d->sipay_3d == 8){
    
			$post = array(
				'merchant_key' =>trim(Configuration::get('SIPAY_MERCHANT_KEY')),
				'token' =>trim($sipay_3d['sipay_token']),
                'invoice_id' => $order_id
			);
			$url = Configuration::get('SIPAY_API_DOMAIN')."/ccpayment/purchase/status";
		}else{
			
			$sipay_data = $sipay_3d->sipay_token;
			$sipay_payheaders[]= "Authorization: Bearer ".$sipay_data;
			$post = array(
				'merchant_key' =>Configuration::get('SIPAY_MERCHANT_KEY'),
				'invoice_id' => $order_id
			);
			$url = Configuration::get('SIPAY_API_DOMAIN')."/ccpayment/api/checkstatus";			
		}
		$post['app_id'] = trim(Configuration::get('SIPAY_APP_ID'));
		$post['app_secret'] = Configuration::get('SIPAY_APP_SECRET_KEY');
		
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url );
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post));
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
		
		curl_setopt($ch, CURLOPT_HTTPHEADER, $sipay_payheaders);
		
		$response = json_decode(curl_exec($ch),true);
		curl_close($ch);
		
		if ($response['status_code']== 100 || $response['statuscode'] == 101) {
			
			$history_recurring = new OrderHistory();
			$history_recurring->id_order = (int)$order_id;
			$history_recurring->changeIdOrderState(2, (int)($order_id));
		}
		else
		{
			$history_recurring = new OrderHistory();
			$history_recurring->id_order = (int)$order_id;
			$history_recurring->changeIdOrderState(8, (int)($order_id));
		}
		echo "Order updated successfully.";
		die();
		
	}	
}
