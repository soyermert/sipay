<?php
/*
* 2007-2016 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2016 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since 1.5.0
 */
class SipayRecurringwebhookModuleFrontController extends ModuleFrontController
{
	/**
	 * @see FrontController::postProcess()
	 */
	public function postProcess()
	{		
		 Db::getInstance()->execute(
		   'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'recurring_order_values` (
				`id` int(11) NOT NULL AUTO_INCREMENT,
				`order_recurring_id` int(11) NOT NULL,
				`parent_order_id` int(11) NOT NULL,
				`recurring_number` int(11) NOT NULL,
				`date` DATETIME NOT NULL,				
				PRIMARY KEY (`id`))'
		);
		
		//$cart = $this->context->cart; 
	
		if(isset($_POST) && $_POST['invoice_id'] > 0 && $_POST['recurring_number'] > 0){
			if(Configuration::get('SIPAY_MERCHANT_KEY') != $_POST['merchant_key']){
				echo json_encode(array('msg' => 'Merchant key is invalid or did not match!'));
				exit;
			}
			
			$post = array(
				'app_id' =>  Configuration::get('SIPAY_APP_ID'),
				'app_secret' => Configuration::get('SIPAY_APP_SECRET_KEY')
			);
			
			$domain = Configuration::get('SIPAY_API_DOMAIN');
			$url = $domain."/ccpayment/api/token";
			
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url );
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
			//curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			
			$response = json_decode(curl_exec($ch),true);
			
			curl_close($ch);
			
			
			//$tok = json_decode($response['data']['token'], true);
			$tok =$response['data']['token'];
			
			$order_cart_id = $_POST['invoice_id'];
			
			$order_id = Order::getOrderByCartId((int)($order_cart_id));
			$order_info = $order = new Order((int) $order_id);
			
			$get_no_of_payemnt = Db::getInstance()->ExecuteS('SELECT no_of_payments FROM `' . _DB_PREFIX_ . 'no_ofpayment_with_orderid` WHERE order_id='.$order_id);
			$no_of_payments = $get_no_of_payemnt[0]['no_of_payments'];
			
			
			
			$delivery_details = new Address((int)($order_info->id_address_delivery));
			
			$AddressObject = new AddressCore();
			
			$AddressObject->id_customer = $delivery_details->id_customer;
			$AddressObject->firstname = $delivery_details->firstname;
			$AddressObject->lastname = $delivery_details->lastname;
			$AddressObject->address1 =  $delivery_details->address1;
			$AddressObject->address2 =  $delivery_details->address2;
			$AddressObject->city = $delivery_details->city;
			$AddressObject->postcode = $delivery_details->postcode;
			$AddressObject->id_country = $delivery_details->id_country;
			$AddressObject->alias = $delivery_details->alias;
			$AddressObject->add();
			
			$currency_object = new CurrencyCore();
			
			$id_currency = $order_info->id_currency;
			$id_address = $AddressObject->id;
			$cart = new Cart();
			$cart->id_customer = (int) $AddressObject->id_customer;
			$cart->id_address_delivery = $order_info->id_address_delivery;
			$cart->id_address_invoice = $order_info->id_address_invoice;
			$cart->id_lang = 1;
			$cart->id_currency = (int) $id_address;
			$cart->id_carrier = 1;
			$cart->recyclable = 0;
			$cart->gift = 0;
			$cart->add();
			$cart_id = $cart->id;
		
			$plan_code = $_POST['plan_code'];
			
			$headers = array(
				'Authorization: Bearer '.$tok
			);
			
			$post_data = array(
				'merchant_key' => $_POST['merchant_key'],
				'plan_code' => $plan_code
			);
			
			$url = $domain."/ccpayment/api/recurringPlan/query";
			
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $url );
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
			
			$response = json_decode(curl_exec($ch),true);
			
			curl_close($ch);
			
			$history = new OrderHistory();
			$history->id_order = (int)$order_id;
			$customer = new Customer($order_info->id_customer);
			$currency = $this->context->currency;
			$total = $order_info->total_paid;
			
			$mailVars = array(
				'{sipay_merchant_id}' => nl2br(Configuration::get('SIPAY_MERCHANT_ID')),
				'{sipay_merchant_key}' => nl2br(Configuration::get('SIPAY_MERCHANT_KEY')),
				'{sipay_app_id}' => nl2br(Configuration::get('SIPAY_APP_ID')),
				'{sipay_app_secret_key}' => nl2br(Configuration::get('SIPAY_APP_SECRET_KEY')),
				'{sipay_api_domain}' => nl2br(Configuration::get('SIPAY_API_DOMAIN')),
				'{sipay_merchant_currency}' => nl2br(Configuration::get('SIPAY_MERCHANT_CURRENCY'))
			);
			
			
			if ($response['status_code'] == 100) {
				$rec_status = '';
				$is_recurring_exist=0;
				if(!empty($response['transactionHistories'])){
					foreach($response['transactionHistories'] as $trans){
						if($trans['recurring_number'] == $_POST['recurring_number']){
							$rec_status = $trans['status'];
							$is_recurring_exist=1;
						}
					}
				}
				if(!$is_recurring_exist){
					echo json_encode(array('msg' => 'Invalid recurring number!'));
					exit;
				}
				
				//if recurring number is 1 it's first payment so i just update the status 
				if( $_POST['recurring_number'] == 1){
					
					if($rec_status == 'Success')
						
						$history->changeIdOrderState(2, (int)($order_id));
					if($rec_status == 'Failed')
						
						$history->changeIdOrderState(8, (int)($order_id));
					
					echo json_encode(array('msg' => 'Order Updated successfully'));
					exit;
				}
				// Checking existing order if any order have receiving recurring number then i just update the order status /
				
				$data = Db::getInstance()->ExecuteS('SELECT * FROM `' . _DB_PREFIX_ . 'recurring_order_values` WHERE parent_order_id='.$order_id.' and recurring_number='.$_POST['recurring_number']);
				
				if(count($data)>0)
				{
					$recurring_order_id = $data[0]['order_recurring_id'];
					$history_recurring = new OrderHistory();
					$history_recurring->id_order = (int)$recurring_order_id;
									
					Db::getInstance()->execute('UPDATE `' . _DB_PREFIX_ . 'recurring_order_values` SET order_recurring_id='.$recurring_order_id.',recurring_number='.$_POST['recurring_number'] .',date="'.date("Y/m/d h:i:sa",time()).'" WHERE parent_order_id='.(int)$order_id);
					
					
					if($rec_status == 'Success')
						//$rec_order->update_status('completed');
						$history_recurring->changeIdOrderState(2, (int)($recurring_order_id));
					if($rec_status == 'Failed')
						//$rec_order->update_status('failed');
						$history_recurring->changeIdOrderState(8, (int)($recurring_order_id));
						
						
					$orderMessage1 = new Message();
					$orderMessage1->id_order = $recurring_order_id;
					$orderMessage1->message = 'Plan code : '.$plan_code.' / Recurring number : '.$_POST['recurring_number'].'/'.$no_of_payments;
					
					$orderMessage1->save();
					
					echo json_encode(array('msg' => 'Order Updated successfully'));
					exit;
				}		
				
				$order = new Order();
				
				$order->id_customer = (int)$order_info->id_customer;
				$order->id_address_invoice = (int)$order_info->id_address_invoice;
				$order->id_address_delivery = (int)$order_info->id_address_delivery;
				$order->id_currency = (int)$order_info->id_currency;
				$order->id_lang = (int)$order_info->id_lang;
				$order->id_cart = (int)$cart->id;
				$order->reference = $order_info->reference;
				$order->id_shop = (int)$order_info->id_shop;
				$order->id_shop_group = (int)$order_info->id_shop_group;
				
				$order->secure_key = $order_info->secure_key;
				$order->payment = $order_info->payment;
				$order->module =  $order_info->module;
				
				$order->recyclable = $order_info->recyclable;
				$order->gift = (int)$order_info->gift;
				$order->gift_message = $order_info->gift_message;
				$order->mobile_theme = $order_info->mobile_theme;
				$order->conversion_rate = $order_info->conversion_rate;
				
				$order->total_paid_real =  $order_info->total_paid_real;
				$order->total_products = $order_info->total_products;
				$order->total_products_wt = $order_info->total_products;
				$order->total_discounts_tax_excl = $order_info->total_discounts_tax_excl;
				$order->total_discounts_tax_incl = $order_info->total_discounts_tax_incl;
				$order->total_discounts = $order_info->total_discounts;
				
				$order->total_shipping_tax_excl = $order_info->total_shipping_tax_excl;
				$order->total_shipping_tax_incl = $order_info->total_shipping_tax_incl;
				$order->total_shipping = $order_info->total_shipping;
				$order->carrier_tax_rate =$order_info->carrier_tax_rate;
				$order->total_wrapping_tax_excl = $order_info->total_wrapping_tax_excl;
				$order->total_wrapping_tax_incl = $order_info->total_wrapping_tax_incl;
				$order->total_wrapping =$order_info->total_wrapping;
				
				$order->total_paid_tax_excl = $order_info->total_paid_tax_excl;
				$order->total_paid_tax_incl = $order_info->total_paid_tax_incl;
				$order->total_paid =$order_info->total_paid;
				$order->round_mode = $order_info->round_mode;
				$order->round_type = $order_info->round_type;
				$order->id_carrier = $order_info->id_carrier;
				$order->current_state = $order_info->current_state;
				
				
				$order->add();
				
				$recurring_order_id_new =$order->id;
				
				$history_recurring_new = new OrderHistory();
				$history_recurring_new->id_order = (int)$recurring_order_id_new;
												
				if($rec_status == 'Success')
					//$rec_order->update_status('completed');
					$history_recurring_new->changeIdOrderState(2, (int)($recurring_order_id_new));
				if($rec_status == 'Failed')
					//$rec_order->update_status('failed');
					$history_recurring_new->changeIdOrderState(8, (int)($recurring_order_id_new));
					
				$orderMessage = new Message();
				$orderMessage->id_order = $recurring_order_id_new;
				$orderMessage->message = 'Plan code : '.$plan_code.' / Recurring number : '.$_POST['recurring_number'].'/'.$no_of_payments;
				
				$orderMessage->save();
				
				Db::getInstance()->execute('INSERT INTO `' . _DB_PREFIX_ . 'recurring_order_values` SET parent_order_id='.$order_id.',order_recurring_id='.$recurring_order_id_new.',recurring_number='.$_POST['recurring_number'] .',date="'.date("Y/m/d h:i:sa",time()).'"');
				echo json_encode(array('msg' => 'Order Created successfully'));
					exit;
			}
			
		}
	}	
}
