<?php
/*
* 2007-2016 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2016 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since 1.5.0
 */
class SipayReceiptpageModuleFrontController extends ModuleFrontController
{
	/**
	 * @see FrontController::postProcess()
	 */
	
	
	public function initContent()
	{
	
		$baseurl = Tools::getHttpHost(true).__PS_BASE_URI__;
		
		$domain = Configuration::get('SIPAY_API_DOMAIN');
		$appid = Configuration::get('SIPAY_APP_ID');
		$appsecret = Configuration::get('SIPAY_APP_SECRET_KEY');
		
		$sipay_data=$_POST;
		
		foreach($sipay_data as $key => $val){
			if($key == "sipay_token"){
			$key ="Authorization";
			$val = "Bearer ".$val;
			}
			$formdata[] = "<input type='hidden' name='".$key."' value='".$val."'/>";
		}
		?>
		<form action="<?php echo $domain; ?>/ccpayment/api/pay3d" class="payment_3dsss" method="post">
			
           
            <?php echo  implode('', $formdata); ?>
			<input type="hidden" name="app_id" value="<?php echo $appid; ?>">
			<input type="hidden" name="app_secret" value="<?php echo $appsecret; ?>">
           
		</form>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
			<script>
		$(".payment_3dsss").submit();
			</script>
		<?php
		die();
	}
	
	
	
}
