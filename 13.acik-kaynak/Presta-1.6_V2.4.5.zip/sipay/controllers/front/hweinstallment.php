<?php
/*
* 2007-2016 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2016 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since 1.5.0
 */
class SipayHweinstallmentModuleFrontController extends ModuleFrontController
{
	/**
	 * @see FrontController::postProcess()
	 */
	public function postProcess()
	{		
		$pos_post = array(
			'credit_card' => $_POST['number'],
			'amount' => $_POST['amount'],
			"currency_code" => Configuration::get('SIPAY_MERCHANT_CURRENCY'),
			"merchant_key" => Configuration::get('SIPAY_MERCHANT_KEY')
		);
		
		
		
		if($_POST['recurringhwe']==1){
			$pos_post['is_recurring'] = 1;
		}
		
		
		$headers = array(
			'Accept: application/json',
			'Content-Type: application/json',
			"Authorization: Bearer {$_POST['token']}"
		);
			
		  $domain=Configuration::get('SIPAY_API_DOMAIN');
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,  $domain."/ccpayment/api/getpos" );

			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($pos_post));
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
			$get_pos_response = json_decode(curl_exec($ch),true);
			//print_r($get_pos_response);
		
			curl_close($ch);
			
		
			if($get_pos_response['status_code'] == 100){
				
				$html='';
				if(!empty($get_pos_response['data'])){
					$pos_id ='';
					$pos_amt='';
					$currency_id="";
					$campaign_id="";
					$allocation_id="";
					$installments_number="";
					$hash_key="";
					$currency_code='';
					$i=0;
					$html ="<div class='row' style='margin-top: 20%'>";
					foreach($get_pos_response['data'] as $val){
						
						$sipay_installment = explode(',',Configuration::get('SIPAY_installment'));
						/*print_r($sipay_installment);
						die();*/
						if($val['installments_number'] != 1){
							
							if(in_array($val['installments_number'], $sipay_installment)){
								$i++;
							continue;
							}
						}
						
						$active_cls="";
//						$inst= ($i+1)." Installment";
                        $currency_code=$val['currency_code'];
						if($i == 0){
							$active_cls='active';
							$pos_id = $val['pos_id'];
							
							$pos_amt = $val['amount_to_be_paid'];
							$currency_id=$val['currency_id'];
							$campaign_id=$val['campaign_id'];
							$allocation_id=$val['allocation_id'];
							$installments_number=$val['installments_number'];
							$hash_key = $val['hash_key'];

							$inst= $this->getLocalizationContent('single_installment',$currency_code);
							
							$html .="<div class='single-installment ".$active_cls."' data-posid='".$val["pos_id"]."' data-amount='".$val["amount_to_be_paid"]."' data-currency_id='".$val["currency_id"]."' data-campaign_id='".$val["campaign_id"]."' data-allocation_id='".$val["allocation_id"]."' data-installments_number='".$val["installments_number"]."' data-hash_key='".$val["hash_key"]."' data-currency_code='".$val["currency_code"]."' style='margin-left: 1%;'>
						<div class='sipay_heading'>".$inst."</div>
						<div class='sipay_amount'>".$val['amount_to_be_paid']." ".$val['currency_code']."</div>
						<div class='sipay_installment_number'>".($i+1)." X</div>
						<div class='sipay_total_amount'>".number_format(($val['amount_to_be_paid']/($i+1)), 2)." ".$val['currency_code']."</div></div>";
						
						
						}else{
						   $inst = ($i+1)." ".$this->getLocalizationContent('installment',$currency_code);
						   
						   $html .="<div class='single-installment ".$active_cls."' data-posid='".$val["pos_id"]."' data-amount='".$val["amount_to_be_paid"]."' data-currency_id='".$val["currency_id"]."' data-campaign_id='".$val["campaign_id"]."' data-allocation_id='".$val["allocation_id"]."' data-installments_number='".$val["installments_number"]."' data-hash_key='".$val["hash_key"]."' data-currency_code='".$val["currency_code"]."'
						
						
						
						>
						<div class='sipay_heading'>".$inst."</div>
						<div class='sipay_amount'>".$val['amount_to_be_paid']." ".$val['currency_code']."</div>
						<div class='sipay_installment_number'>".($i+1)." X</div>
						<div class='sipay_total_amount'>".number_format(($val['amount_to_be_paid']/($i+1)), 2)." ".$val['currency_code']."</div></div>";
						
                        }
						
						$i++;
					}
					$html .="</div>";
					
					echo json_encode(array('data' => $html, 'pos_id' => $pos_id, 'pos_amt' => $pos_amt, 'currency_id' => $currency_id, 'campaign_id' => $campaign_id, 'allocation_id' => $allocation_id, 'installments_number' => $installments_number, 'hash_key' => $hash_key,'currency_code' => $currency_code));
					exit;
				}
			}
			echo json_encode(array('data' => '', 'pos_id' => '', 'pos_amt' => '', 'currency_id' => '', 'campaign_id' => '', 'allocation_id' => '', 'installments_number' => '', 'hash_key' => '', 'currency_code' => Configuration::get('SIPAY_MERCHANT_CURRENCY')));
			exit;
		
	}	
	public function getLocalizationContent($content, $language){
		$language = strtoupper($language);
		$lang = [
			'TRY' => [
				'card_holder_name' => 'Kart Sahibi',
				'card_number' => 'Kart Numarası',
				'expiry' => 'Son Kullanma Tarihi',
				'cvv' => 'Güvenlik Numarası',
				'single_installment' => 'Peşin',
				'installment' => 'Taksit'
			],
			'USD' => [
				'card_holder_name' => 'Card Holder Name',
				'card_number' => 'Card Number',
				'expiry' => 'Expiry',
				'cvv' => 'CVV',
				'single_installment' => 'Single Installment',
				'installment' => 'Installment'
			]
		];

		if (!isset($lang[$language])){
			$language = 'USD';
		}
		if (isset($lang[$language][$content])){
			$localizeContent = $lang[$language][$content];
		}else{
			$localizeContent = $content;
		}

		return $localizeContent;
	}
}
