<?php
/*
* 2007-2016 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2016 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since 1.5.0
 */
class SipayValidationModuleFrontController extends ModuleFrontController
{
	/**
	 * @see FrontController::postProcess()
	 */
	public function postProcess()
	{
		
		$baseurl = Tools::getHttpHost(true).__PS_BASE_URI__;
		
			$post_url = Configuration::get('SIPAY_API_DOMAIN').'/ccpayment/api/token';	
			$post = array(
					'app_secret' => Configuration::get('SIPAY_APP_SECRET_KEY'), //sipay test merchant
					'app_id' => Configuration::get('SIPAY_APP_ID')
	
				);
				
			
			$cart = $this->context->cart;
			
			
			if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active)
				Tools::redirect('index.php?controller=order&step=1');
			$total = (float)$cart->getOrderTotal(true, Cart::BOTH);
			// Check that this payment option is still available in case the customer changed his address just before the end of the checkout process
			$authorized = false;
			foreach (Module::getPaymentModules() as $module)
				if ($module['name'] == 'sipay')
				{
					$authorized = true;
					break;
				}
	
			if (!$authorized)
				die($this->module->l('This payment method is not available.', 'validation'));
	
			$customer = new Customer($cart->id_customer);
			if (!Validate::isLoadedObject($customer))
				Tools::redirect('index.php?controller=order&step=1');
	
			$currency = $this->context->currency;
			$total = (float)$cart->getOrderTotal(true, Cart::BOTH);
			
			$mailVars = array(
				'{sipay_merchant_id}' => nl2br(Configuration::get('SIPAY_MERCHANT_ID')),
				'{sipay_merchant_key}' => nl2br(Configuration::get('SIPAY_MERCHANT_KEY')),
				'{sipay_app_id}' => nl2br(Configuration::get('SIPAY_APP_ID')),
				'{sipay_app_secret_key}' => nl2br(Configuration::get('SIPAY_APP_SECRET_KEY')),
				'{sipay_api_domain}' => nl2br(Configuration::get('SIPAY_API_DOMAIN')),
				'{sipay_merchant_currency}' => nl2br(Configuration::get('SIPAY_MERCHANT_CURRENCY'))
			);
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $post_url);
		  
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
	
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
			$response = json_decode(curl_exec($ch),true);
			
	
			curl_close($ch);
			
			
			if($response['status_code'] == 100){
				$is_3d = $response['data']['is_3d'];
				
			}
			echo '<form action= "'.$baseurl.'index.php?fc=module&module=sipay&controller=sipaycallback" class="payment_3dgweget" method="post">';
			if($is_3d != 4){
				
			?> 
			<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
	
			<fieldset id="wc-sipay-cc-form" class="wc-credit-card-form wc-payment-form">
					   
				<style>
				
				
					#wc-sipay-cc-form
				{
					width: 50%;
					margin-left: 25%;
					border:none;
					background:#eee;
					margin-top:10%;
				}
				label
				{
					display: block;
					font-size: 18px;
				}
				.input-text
				{
					box-sizing: border-box;
					width: 100%;
					-moz-appearance: none;
					background: #fff;
					border-radius: 0;
					border-style: solid;
					border-width: 0.1rem;
					box-shadow: none;
					display: block;
					font-size: 1rem;
					letter-spacing: -0.015em;
					margin: 0;
					max-width: 100%;
					padding: 0.5rem 1rem;
				}
				.form-row-first
				{
					float:left;
				}
				.form-row-last
				{
					float:right;
				}
				.sipay_place_order
				{		
					width: 50%;			
					margin-left: 25%;
					margin-top: 2%;
					background-color: #cd2653;
					border: none;
					border-radius: 0;
					color: #fff;
					cursor: pointer;
					font-weight: 600;
					letter-spacing: 0.0333em;
					opacity: 1;
					padding: 1.1em 1.44em;
					text-align: center;
					text-decoration: none;
					text-transform: uppercase;
					transition: opacity 0.15s linear;
					font-size: 16px;
				}
				
			 .single-installment
				{
					text-align: center;
					max-height: 180px;
					width: 12%;
					margin-right: 5px;
					margin-top: 10px;
					position: relative;
					float: left;
					height: 160px;
					min-width: 130px;
					line-height: 1.5rem;
					padding: 5px 15px;
					font-family: Arial;
					border: 2px solid #ccc;
					font-size: 1.6rem;
				}
					
					
				.single-installment div
				{
					width: 100%;
					float: left;
					height: 25%;
				}
				
				.sipay_heading
				{
				font-weight: 600;
				margin-bottom: 10px;
				color: #777777;
				}
				
				.sipay_amount
				{
				color: #333333;
				font-weight: bolder;
				}
				
				.sipay_installment_number
				{
				padding-bottom: 0px !important;
				padding-left: 10px;
				font-size: inherit !important;
				}
				
				.sipay_total_amount
				{
				font-weight: 500;
				margin: 5px;
				color: #800;
				}
				
				.single-installment.active 
				{
					border: 2px solid green;
				}
				  
				body
				{ 
					background:#8e8989;
				} 
				
				#wc-sipay-cc-form
				{
					background: #f5f5f7;
					border-radius: 12px;
				}
				
				.input-text
				{
					border-radius: 4px;
					box-shadow: 1px 1px 1px 1px #888;
					line-height: 2;
					font-size: 16px;
				}
				
				p
				{
					margin: 10px;
					padding: 10px 10px 0px 10px;
				}
				
				#cc_cvv
				{
					width: 70%;
				}
				
				select
				{
					box-shadow: 1px 1px 1px 1px #888;
				}
				
				</style>
					
				
				<?php
				
			}
			if($response['status_code'] == 100){
				echo "<input type='hidden' name='sipay_token' class='sipay_token' id='sipay_token' value='".$response['data']['token']."'/>";
			}else{
				echo "<input type='hidden' name='sipay_token' class='sipay_token' id='sipay_token' value=''/>";
			}
			echo "<input type='hidden' name='sipay_3d' class='sipay_3d' id='sipay_3d' value='".$is_3d."'/>";
			echo "<input type='hidden' name='amount' class='amount' id='amount' value='".$total."'/>";
		
			
			if($is_3d != 4){
				
			?>
			
			<p class="form-row form-row-wide">
				<label>Card Holder Name <span class="required">*</span></label>
				<input id="cc_holder_name" name="cc_holder_name" class="input-text cc_holder_name" type="text" autocomplete="off" required="required">
			</p>
			<p class="form-row form-row-wide">
				<label>Card Number <span class="required">*</span></label>
				<input id="cc_number" class="input-text cc_number" name="cc_number" type="text" autocomplete="off" required="required">
				<span class="sipay_spinner_blk" style="display:none"><img src="<?php echo $baseurl; ?>modules/sipay/controllers/front/image/spinner.gif" /></span>
			</p>
			<p class="form-row form-row-first">
				<label>Expiry <span class="required">*</span></label>
				<select name="expiry_month" class="btn dropdown-toggle" id="expiry_month"  style="padding:10px;" required="required">
					<?php
					for($i=1; $i<=12; $i++)
						echo '<option value="'.$i.'" >'.$i.'</option>';
					?>
				</select>
				<select class="btn dropdown-toggle" name="expiry_year" id="expiry_year"  style="padding:10px;" required="required">
					<?php
					for($i=date('Y'); $i<=date('Y') + 10; $i++)
						echo '<option value="'.$i.'" >'.$i.'</option>';
					?>
				</select>
			</p>
			<p class="form-row form-row-last">
				<label>CVV <span class="required">*</span></label>
				<input id="cc_cvv" class="input-text cc_cvv" name="cc_cvv" type="password" autocomplete="off" placeholder="CVV" required="required">
			</p>
			<input type="hidden" name="pos_id" class="pos_id" value=""/>
			<input type="hidden" name="pos_amount" class="pos_amount" value=""/>
			<input type="hidden" name="currency_id" class="currency_id" value=""/>
			<input type="hidden" name="campaign_id" class="campaign_id" value=""/>
			<input type="hidden" name="currency_code" class="currency_code" value=""/>
			<input type="hidden" name="allocation_id" class="allocation_id" value=""/>
			<input type="hidden" name="installments_number" class="installments_number" value=""/>
			<div class="clear"></div>
			<p class="installments form-row form-row-wide" id="installments"></p>
			<div class="clear"></div>
			<?php
			if($is_3d == 1){ ?>
			<p class="form-row form-row-first" style="float: left;width: 50%;">
				<input style="width:10%;" id="pay_via_3d" class="pay_via_3d" name="pay_via_3d" type="checkbox" autocomplete="off" value="yes"><strong>I want 3D payment option</strong>
			</p>
			<?php } ?>
			<?php
				echo '<div class="clear"></div></fieldset>';
				?>
				<button type="submit" class="button alt sipay_place_order" name="opencart_sipay_place_order" id="place_order" value="Place order" data-value="Place order">Pay with sipay</button>
			
				<?php			
					
				}?>
				
					</form>
				
				<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
					<script>
					$(document).ready(function(){
						
						<?php
						if($is_3d == 4)
						{
						?>
						
						$(".payment_3dgweget").submit();
						<?php } ?>
						
						
						$("#cc_number").keypress(function(e){
							if(e.which== 13)
							{
								return false;	
							}
							
							
						});
						
						$("#cc_number").keyup(function(){
							
							$(".sipay_spinner_blk").show();
							$.ajax({
								url: "<?php echo $baseurl; ?>index.php?fc=module&module=sipay&controller=hweinstallment",
								type: 'post',
								data: 
								{
									token:$("#sipay_token").val(),
									number:$(this).val(),
									amount:$("#amount").val(),
									currencycode: '<?php echo Configuration::get('SIPAY_MERCHANT_CURRENCY'); ?>'
								},
								dataType: "JSON",
								success: function (data, textStatus, jQxhr) {
									console.log(data);
									$("#installments").show();
									$("#installments").html(data.data);
									$(".pos_id").val(data.pos_id);
									$(".pos_amount").val(data.pos_amt);
									$(".currency_id").val(data.currency_id);
									$(".campaign_id").val(data.campaign_id);
									$(".currency_code").val(data.currency_code);
									$(".allocation_id").val(data.allocation_id);
									$(".installments_number").val(data.installments_number);
									$(".sipay_spinner_blk").hide();
									//$(".pay_via_3d").css("margin-top","74%");
								},
								error: function (jqXhr, textStatus, errorThrown) {
									console.log(errorThrown);
									jQuery(".sipay_spinner").remove();
								}
							});
							
						});
	   
					});
					
					$("body").delegate(".single-installment","click",function()
					{
						
					   jQuery(".pos_id").val(jQuery(this).attr('data-posid'));
					   jQuery(".pos_amount").val(jQuery(this).attr('data-amount'));
					   jQuery(".currency_id").val(jQuery(this).attr('data-currency_id'));
					   jQuery(".campaign_id").val(jQuery(this).attr('data-campaign_id'));
					   jQuery(".currency_code").val(jQuery(this).attr('data-currency_code'));
					   jQuery(".allocation_id").val(jQuery(this).attr('data-allocation_id'));
					   jQuery(".installments_number").val(jQuery(this).attr('data-installments_number'));
					   jQuery('.single-installment').removeClass('active');
					   jQuery(this).addClass('active');	
						
					});
						</script>
				<?php
	die();
			$this->module->validateOrder($cart->id, Configuration::get('PS_OS_PAYMENT'), $total, $this->module->displayName, NULL, $mailVars, (int)$currency->id, false, $customer->secure_key);
			
		Tools::redirect('index.php?controller=order-confirmation&id_cart='.$cart->id.'&id_module='.$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.$customer->secure_key);
		
	}	
}
