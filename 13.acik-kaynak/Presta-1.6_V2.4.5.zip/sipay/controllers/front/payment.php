<?php
/*
* 2007-2016 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2016 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since 1.5.0
 */
class SipayPaymentModuleFrontController extends ModuleFrontController
{
	public $ssl = true;
	public $display_column_left = false;

	/**
	 * @see FrontController::initContent()
	 */
	public function initContent()
	{
		parent::initContent();
		
			$baseurl = Tools::getHttpHost(true).__PS_BASE_URI__;
		
			$post_url = Configuration::get('SIPAY_API_DOMAIN').'/ccpayment/api/token';	
			$post = array(
					'app_secret' => Configuration::get('SIPAY_APP_SECRET_KEY'), //sipay test merchant
					'app_id' => Configuration::get('SIPAY_APP_ID')
	
				);
				
			
			$cart = $this->context->cart;
			
			if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active)
				Tools::redirect('index.php?controller=order&step=1');
			$total = (float)$cart->getOrderTotal(true, Cart::BOTH);
			// Check that this payment option is still available in case the customer changed his address just before the end of the checkout process
			$authorized = false;
			foreach (Module::getPaymentModules() as $module)
				if ($module['name'] == 'sipay')
				{
					$authorized = true;
					break;
				}
	
			if (!$authorized)
				die($this->module->l('This payment method is not available.', 'validation'));
	
			$customer = new Customer($cart->id_customer);
			if (!Validate::isLoadedObject($customer))
				Tools::redirect('index.php?controller=order&step=1');
	
			$currency = $this->context->currency;
			$total = (float)$cart->getOrderTotal(true, Cart::BOTH);
			
			$mailVars = array(
				'{sipay_merchant_id}' => nl2br(Configuration::get('SIPAY_MERCHANT_ID')),
				'{sipay_merchant_key}' => nl2br(Configuration::get('SIPAY_MERCHANT_KEY')),
				'{sipay_app_id}' => nl2br(Configuration::get('SIPAY_APP_ID')),
				'{sipay_app_secret_key}' => nl2br(Configuration::get('SIPAY_APP_SECRET_KEY')),
				'{sipay_api_domain}' => nl2br(Configuration::get('SIPAY_API_DOMAIN')),
				'{sipay_merchant_currency}' => nl2br(Configuration::get('SIPAY_MERCHANT_CURRENCY'))
				
			);
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $post_url);
		  
			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
	
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
			$response = json_decode(curl_exec($ch),true);
			
	
			curl_close($ch);
			if($response['status_code'] == 100){
				$is_3d = $response['data']['is_3d'];
				
			}
			
			
			

		$cart = $this->context->cart;
		$cart_product = $cart->getProducts();
		foreach($cart_product as $product)
		{
			$product_id = $product['id_product'];
		}
		$recurring_product_Data = Db::getInstance()->ExecuteS('SELECT * FROM `' . _DB_PREFIX_ . 'recurring_fields` WHERE product_id='.$product_id);
		
		$card_holder_name = $this->getLocalizationContent('card_holder_name', Configuration::get('SIPAY_MERCHANT_CURRENCY'));
		$card_number = $this->getLocalizationContent('card_number', Configuration::get('SIPAY_MERCHANT_CURRENCY'));
		$expiry = $this->getLocalizationContent('expiry', Configuration::get('SIPAY_MERCHANT_CURRENCY'));
		$cvv = $this->getLocalizationContent('cvv', Configuration::get('SIPAY_MERCHANT_CURRENCY'));
		$i_want_3d_payment_option = $this->getLocalizationContent('i_want_3d_payment_option', Configuration::get('SIPAY_MERCHANT_CURRENCY'));
		
		if (!$this->module->checkCurrency($cart))
			Tools::redirect('index.php?controller=order');

		$this->context->smarty->assign(array(
			'nbProducts' => $cart->nbProducts(),
			'cust_currency' => $cart->id_currency,
			'currencies' => $this->module->getCurrency((int)$cart->id_currency),
			'total' => $cart->getOrderTotal(true, Cart::BOTH),
			'this_path' => $this->module->getPathUri(),
			'this_path_bw' => $this->module->getPathUri(),
			'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->module->name.'/',
			'this_site_url' => Tools::getHttpHost(true).__PS_BASE_URI__,
			"is3d"=>$is_3d,
			"status_code"=>$response['status_code'],
			"token"=>$response['data']['token'],
			"total"=>$total,
			"currentyear"=>date('Y'),
			'sipay_merchant_id' => Configuration::get('SIPAY_MERCHANT_ID'),
			'sipay_merchant_key' => Configuration::get('SIPAY_MERCHANT_KEY'),
			'sipay_app_id' => Configuration::get('SIPAY_APP_ID'),
			'sipay_app_secret_key' => Configuration::get('SIPAY_APP_SECRET_KEY'),
			'sipay_api_domain' => Configuration::get('SIPAY_API_DOMAIN'),
			'sipay_merchant_currency' => Configuration::get('SIPAY_MERCHANT_CURRENCY'),
			'buttonlabelname' => Configuration::get('SIPAY_API_ButtonLabel'),
			'no_of_payments' => $recurring_product_Data[0]['no_of_payments'],
			'order_frequency_cycle' => $recurring_product_Data[0]['order_frequency_cycle'],
			'status' => $recurring_product_Data[0]['status'],
			'order_frequency_interval' => $recurring_product_Data[0]['order_frequency_interval'],
			'recurring_webhook_key' => Configuration::get('SIPAY_recurring_webhook'),
			'enable_disable' => Configuration::get('SIPAY_enable_disable'),
			'card_holder_name' =>$card_holder_name,
			'card_number' =>$card_number,
			'expiry' =>$expiry,
			'cvv' =>$cvv,
			'i_want_3d_payment_option' =>$i_want_3d_payment_option,			
		));
		
		$this->setTemplate('payment_execution.tpl');
	}
	
	public function getLocalizationContent($content, $language){
	
		$language = strtoupper($language);
	
		$lang = [
	
			'TRY' => [
	
				'card_holder_name' => 'Kart Sahibi',
	
				'card_number' => 'Kart Numarası',
	
				'expiry' => 'Son Kullanma Tarihi',
	
				'cvv' => 'Güvenlik Numarası',
	
				'single_installment' => 'Peşin',
	
				'installment' => 'Taksit',
				'i_want_3d_payment_option' => '3d ödeme seçeneği istiyorum'
	
			],
	
			'USD' => [
	
				'card_holder_name' => 'Card Holder Name',
	
				'card_number' => 'Card Number',
	
				'expiry' => 'Expiry',
	
				'cvv' => 'CVV',
	
				'single_installment' => 'Single Installment',
	
				'installment' => 'Installment',
				'i_want_3d_payment_option' => 'I want 3D payment option'
	
			]
	
		];
	
	
	
		if (!isset($lang[$language])){
	
			$language = 'USD';
	
		}
	
		if (isset($lang[$language][$content])){
	
			$localizeContent = $lang[$language][$content];
	
		}else{
	
			$localizeContent = $content;
	
		}
	
	
	
		return $localizeContent;
	
	}
}
