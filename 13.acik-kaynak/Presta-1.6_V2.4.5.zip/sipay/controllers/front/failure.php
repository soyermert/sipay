<?php
/*
* 2007-2016 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2016 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since 1.5.0
 */
class SipayFailureModuleFrontController extends ModuleFrontController
{
	/**
	 * @see FrontController::postProcess()
	 */
	public function initContent()
	{	
		parent::initContent();
	
		$baseurl = Tools::getHttpHost(true).__PS_BASE_URI__;
		
		Db::getInstance()->execute(
		   'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'sale_webhook_fields` (
				`id` int(11) NOT NULL AUTO_INCREMENT,
				`order_id` int(11) NOT NULL,
				`sipay_payment_info` TEXT,
				PRIMARY KEY (`id`)
				)'
		);		
		
		$cart = $this->context->cart;
		
		if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active)
				Tools::redirect('index.php?controller=order&step=1');
			$total = (float)$cart->getOrderTotal(true, Cart::BOTH);
			
		$authorized = false;
		foreach (Module::getPaymentModules() as $module)
			if ($module['name'] == 'sipay')
			{
				$authorized = true;
				break;
			}

		if (!$authorized)
			die($this->module->l('This payment method is not available.', 'validation'));

		$customer = new Customer($cart->id_customer);
		if (!Validate::isLoadedObject($customer))
			Tools::redirect('index.php?controller=order&step=1');

		$currency = $this->context->currency;
		$total = (float)$cart->getOrderTotal(true, Cart::BOTH);
		
		$mailVars = array(
			'{sipay_merchant_id}' => nl2br(Configuration::get('SIPAY_MERCHANT_ID')),
			'{sipay_merchant_key}' => nl2br(Configuration::get('SIPAY_MERCHANT_KEY')),
			'{sipay_app_id}' => nl2br(Configuration::get('SIPAY_APP_ID')),
			'{sipay_app_secret_key}' => nl2br(Configuration::get('SIPAY_APP_SECRET_KEY')),
			'{sipay_api_domain}' => nl2br(Configuration::get('SIPAY_API_DOMAIN')),
			'{sipay_merchant_currency}' => nl2br(Configuration::get('SIPAY_MERCHANT_CURRENCY'))
		);
		
		
		
		
		//$order_id = $cart->id;
		
		$sipay_3d = json_decode(Context::getContext()->cookie->__get('sipay_payment_info'),true);
		
		if(isset($_REQUEST['invoice_id']))
		{
			 $order_id = $_REQUEST['invoice_id'];
		}
		else
		{
		 $order_id = $sipay_3d['orderid'];
		}
		
		
		$sipay_payheaders=array(
			'Accept: application/json',
			'Content-Type: application/json'
			);
			
			
		//$order = wc_get_order( $order_id );
		if($sipay_3d['sipay_3d'] == 4 || $sipay_3d['sipay_3d'] == 8){
        
			$post = array(
				'merchant_key' =>Configuration::get('SIPAY_MERCHANT_KEY'),
				'token' => $sipay_3d['sipay_token'],
                'invoice_id' => $order_id
			);
			$url = Configuration::get('SIPAY_API_DOMAIN')."/ccpayment/purchase/status";
		}else{
			//$sipay_data = get_post_meta($order_id, 'sipay_data_payment', true);
			$sipay_data = json_decode(Context::getContext()->cookie->__get('sipay_data_payment'),true);
			
			$sipay_payheaders[]= "Authorization: Bearer {$sipay_data['sipay_token']}";
			
			$post = array(
				'merchant_key' =>Configuration::get('SIPAY_MERCHANT_KEY'),
				'invoice_id' => $order_id
			);
			$url = Configuration::get('SIPAY_API_DOMAIN')."/ccpayment/api/checkstatus";
		}

		$post['app_id'] = Configuration::get('SIPAY_APP_ID');
		$post['app_secret'] = Configuration::get('SIPAY_APP_SECRET_KEY');
	
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url );
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($post));
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
		
			curl_setopt($ch, CURLOPT_HTTPHEADER, $sipay_payheaders);
		
		$response = json_decode(curl_exec($ch),true);
		curl_close($ch);
		
		if ($response['status_code']== 100) {
				$this->module->validateOrder($cart->id, 2, $total, $this->module->displayName, NULL, $mailVars, (int)$currency->id, false, $customer->secure_key);
				$orderid = $this->module->currentOrder;
								
				if(isset($response['recurring_id']) && !empty($response['recurring_id']))
				{
					$order=new Order($orderid);
			
					$get_order=new Order($order->id_cart);
					
					$products=$cart->getProducts();
					foreach($products as $product)
					{
						$product_id = $product['id_product'];
						$data = Db::getInstance()->ExecuteS('SELECT * FROM `' . _DB_PREFIX_ . 'recurring_fields` WHERE product_id='.$product_id);
						if($data[0]['status']==1)
						{
							$orderMessage = new Message();
							$orderMessage->id_order = $orderid;
							$orderMessage->message = 'Plan code :'.$response['recurring_plan_code'].' / Recurring number : 1/'.$data[0]['no_of_payments'];
							
							$orderMessage->save();
							
							Db::getInstance()->execute(
							   'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'no_ofpayment_with_orderid` (
									`id` int(11) NOT NULL AUTO_INCREMENT,
									`product_id` int(11) NOT NULL,
									`no_of_payments` int(11) NOT NULL,
									`order_id` int(100) NOT NULL,
									PRIMARY KEY (`id`)
									)'
							);
						Db::getInstance()->execute('INSERT INTO `' . _DB_PREFIX_ . 'no_ofpayment_with_orderid` SET product_id='.$product_id.',no_of_payments='.$data[0]['no_of_payments'].',order_id='.$orderid);
						}
						
					}
				}
				else
				{
					Db::getInstance()->execute("INSERT INTO `" . _DB_PREFIX_ . "sale_webhook_fields` SET order_id=".$orderid.",sipay_payment_info='".json_encode($sipay_3d)."'");	
				}
				Tools::redirect('index.php?controller=order-detail&id_order='.$orderid);
			
		}else{
				
			if(isset($_REQUEST['error']))
			{	
				$error=$_REQUEST['error'];
			}
			elseif(isset($response['message']))
			{	
				$error=$response['message'];
				
			}
			
			else
			{
				$error="Error in processing payment.";	
				
			}
			
			$this->context->smarty->assign(array('status'=> Tools::getValue('error')));
			
			$this->module->validateOrder($cart->id, 8, $total, $this->module->displayName, NULL, $mailVars, (int)$currency->id, false, $customer->secure_key);
			$order_id = $this->module->currentOrder;
						
			
				if(isset($response['recurring_id']) && !empty($response['recurring_id']))
				{
					$order=new Order($order_id);
			
					$get_order=new Order($order->id_cart);
					
					$products=$cart->getProducts();
					foreach($products as $product)
					{
						$product_id = $product['id_product'];
						$data = Db::getInstance()->ExecuteS('SELECT * FROM `' . _DB_PREFIX_ . 'recurring_fields` WHERE product_id='.$product_id);
						if($data[0]['status']==1)
						{
							$orderMessage = new Message();
							$orderMessage->id_order = $order_id;
							$orderMessage->message = 'Plan code :'.$response['recurring_plan_code'].' / Recurring number : 1/'.$data[0]['no_of_payments'];
							
							$orderMessage->save();
							
							Db::getInstance()->execute(
							   'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'no_ofpayment_with_orderid` (
									`id` int(11) NOT NULL AUTO_INCREMENT,
									`product_id` int(11) NOT NULL,
									`no_of_payments` int(11) NOT NULL,
									`order_id` int(100) NOT NULL,
									PRIMARY KEY (`id`)
									)'
							);
								Db::getInstance()->execute('INSERT INTO `' . _DB_PREFIX_ . 'no_ofpayment_with_orderid` SET product_id='.$product_id.',no_of_payments='.$data[0]['no_of_payments'].',order_id='.$order_id);
						}
						
					}
				}
				else
				{
					Db::getInstance()->execute("INSERT INTO `" . _DB_PREFIX_ . "sale_webhook_fields` SET order_id=".$order_id.",sipay_payment_info='".json_encode($sipay_3d)."'");
				}
			
			$this->setTemplate('payment_error.tpl');
		}
		
			
			
	}	
}
