<?php
/*
* 2007-2016 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Academic Free License (AFL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/afl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2016 PrestaShop SA
*  @license    http://opensource.org/licenses/afl-3.0.php  Academic Free License (AFL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/

/**
 * @since 1.5.0
 */
class SipaySipayCallbackModuleFrontController extends ModuleFrontController
{
	/**
	 * @see FrontController::postProcess()
	 */
	public function initContent()
	{
		$baseurl = Tools::getHttpHost(true).__PS_BASE_URI__;
		$cart = $this->context->cart;
			if ($cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || !$this->module->active)
				Tools::redirect('index.php?controller=order&step=1');
			$total = (float)$cart->getOrderTotal(true, Cart::BOTH);
			// Check that this payment option is still available in case the customer changed his address just before the end of the checkout process
			$authorized = false;
			foreach (Module::getPaymentModules() as $module)
				if ($module['name'] == 'sipay')
				{
					$authorized = true;
					break;
				}
	
			if (!$authorized)
				die($this->module->l('This payment method is not available.', 'validation'));
	
			$customer = new Customer($cart->id_customer);
			if (!Validate::isLoadedObject($customer))
				Tools::redirect('index.php?controller=order&step=1');
	
			$currency = $this->context->currency;
			$total = (float)$cart->getOrderTotal(true, Cart::BOTH);
			
			$mailVars = array(
				'{sipay_merchant_id}' => nl2br(Configuration::get('SIPAY_MERCHANT_ID')),
				'{sipay_merchant_key}' => nl2br(Configuration::get('SIPAY_MERCHANT_KEY')),
				'{sipay_app_id}' => nl2br(Configuration::get('SIPAY_APP_ID')),
				'{sipay_app_secret_key}' => nl2br(Configuration::get('SIPAY_APP_SECRET_KEY')),
				'{sipay_merchant_currency}' => nl2br(Configuration::get('SIPAY_API_DOMAIN')),
				'{sipay_api_domain}' => nl2br(Configuration::get('SIPAY_MERCHANT_CURRENCY'))
			);
		
		
		$products=$cart->getProducts();
		print_r($products);
		echo $order_total = (float)$cart->getOrderTotal(true, Cart::BOTH);
		echo "<br/>";
		
		$item_total=0;
			
			
			foreach($products as $product){
						$item = [
						'name' => htmlspecialchars($product['product_name']),
						'price' => number_format( $product['price'], 2, ".", ""),
						'qty' =>(int)$product['quantity'],
						'description' => '',
					];
					$invoice['items'][] = $item;
						$item_total += $product['price'] * $product['quantity'];
			}
			echo $shipping_total = $order_total-$item_total;
		
		
	//	$this->module->validateOrder($cart->id, 3, $total, $this->module->displayName, NULL, $mailVars, (int)$currency->id, false, $customer->secure_key);
		//$order_id = $this->module->currentOrder;
		
		//$order = new Order($order_id);
		
		
		$tax_total = 0;
		//$order_total = $order->total_paid ;
		
		//$shipping_total = $order->total_shipping;
		
		$post = array(
			'merchant_key' =>Configuration::get('SIPAY_MERCHANT_KEY'),
			'invoice_id' => $order_id
		);
		
		$domain = Configuration::get('SIPAY_API_DOMAIN');
		$post_url = $domain.'/ccpayment/purchase/link';
		
		$invoice['invoice_description'] = "Order with Invoice ".  $order_id ;
				
		$invoice['return_url']=$baseurl.'index.php?fc=module&module=sipay&controller=success&order_id='.$order_id;
		$invoice['cancel_url']=$baseurl.'index.php?fc=module&module=sipay&controller=failure&order_id='.$order_id;
		
		$returnurlset=$invoice['return_url'];
		$failureseturl=$invoice['cancel_url'];
		
		$products=$cart->getProducts();
		
		$address = new Address(intval($cart->id_address_delivery));
			
		$address1=$address->address1;
		$address2=$address->address2;			
		$city=$address->city;
		$postcode=$address->postcode;
		$country=$address->country;
		$phone=$address->phone; 
		$firstname=$address->firstname;
		$lastname=$address->lastname;
		
		
				die();
		
		/* Older version payment request */
									
	//================================case1========================================================//
	
		
		if(isset($_POST['sipay_3d']) && $_POST['sipay_3d'] == 4){
						
			$item_total=0;
			
			
			foreach($products as $product){
						$item = [
						'name' => htmlspecialchars($product['product_name']),
						'price' => number_format( $product['price'], 2, ".", ""),
						'qty' =>(int)$product['product_quantity'],
						'description' => '',
					];
					$invoice['items'][] = $item;
						$item_total += $product['price'] * $product['product_quantity'];
			}
			
			$invoice['discount'] =number_format( $order->total_discounts, 2, ".", "");
			$invoice['coupon'] = '3XY8P';
			
			$shipping_total	= $order->total_shipping;
			
			if($shipping_total>0)
			{
				
				$invoice['items'][] = array(
				'name' => 'Shipping Charge',
				'price' => number_format( $shipping_total, 2, ".", ""),
				'qty' => 1,
				'description' => ''
				);	
			}
			
			if($tax_total >0)
			{
			
				$invoice['items'][] = array(
					'name' => 'Tax',
					'price' => number_format( $tax_total, 2, ".", ""),
					'qty' => 1,
					'description' => ''
				);
	 
			}
			$invoice['invoice_id'] = $order_id;
			$invoice['total'] =number_format( $order_total, 2, ".", "");
			
			
			$invoice['bill_address1'] = isset($address1) ? $address1 : '';
			$invoice['bill_address2'] = isset($address2) ? $address2 : '';
			$invoice['bill_city'] = isset($city) ? $city : '';
			$invoice['bill_postcode'] = isset($postcode) ? $postcode : '';
			$invoice['bill_state'] = isset($state) ? $state : '';
			$invoice['bill_country'] = isset($country) ? $country : '';
			$invoice['bill_email'] = isset($order_info['email']) ? $order_info['email'] : '';
			$invoice['bill_phone'] = isset($phone) ? $phone : '';
			
			
			

			$invoice = json_encode($invoice);
			
			
			$post = array(
				'merchant_key' => Configuration::get('SIPAY_MERCHANT_KEY'),
				'invoice' => $invoice,
				'currency_code' =>  Configuration::get('SIPAY_MERCHANT_CURRENCY'),
				'name' => $firstname,
				'surname' => $lastname
			);
			
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL, $domain."/ccpayment/purchase/link" );

			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);

			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
			$response = json_decode(curl_exec($ch),true);
			curl_close($ch);
			
			if ($response['status'] == 1) {
				$successlink= $response['link'];
				?>
				<script>
				location.replace('<?php echo $response['link']; ?>');
				
				</script>
				
				<?php
				
				
			}
			else
			{
				$error=$response['status_description'];	
				?>
				<script>
				location.replace('<?php echo $failureseturl; ?>');
				
				</script>
				
				<?php				
			}
			$price = 0;
			
			$invoice['payable_amount'] = number_format( $_POST['pos_amount'], 2, ".", "");
			$invoice['merchant_key'] = Configuration::get('SIPAY_MERCHANT_KEY');

			$invoice['pos_id'] = $_POST['pos_id'];
			$invoice['currency_id'] = $_POST['currency_id'];
			$invoice['campaign_id'] = $_POST['campaign_id'];
			$invoice['allocation_id'] = $_POST['allocation_id'];
			$invoice['installments_number'] = $_POST['installments_number'];

			$invoice['cc_holder_name'] = $_POST['cc_holder_name'];
			$invoice['cc_no'] = $_POST['cc_number'];
			$invoice['expiry_month'] = $_POST['expiry_month'];
			$invoice['expiry_year'] = $_POST['expiry_year'];
			$invoice['cvv'] = $_POST['cc_cvv'];
			$invoice['currency_code'] = Configuration::get('SIPAY_MERCHANT_CURRENCY');
		}
		//=====================case2========================================================//
		if(((isset($_POST['sipay_3d']) && $_POST['sipay_3d'] == 1) && (isset($_POST['pay_via_3d']) && $_POST['pay_via_3d'] == "yes")) || (isset($_POST['sipay_3d']) && $_POST['sipay_3d'] == 2)){
			$item_total=0;
			foreach($products as $product){
				$item = [
					'name' => htmlspecialchars($product['product_name']),
					'price' => number_format( $product['price'], 2, ".", ""),
					'quantity' =>(int)$product['product_quantity'],
					'description' => '',
				];
				$invoice['items'][] = $item;
				$item_total += $product['price'] * $product['product_quantity'];
			}	
			$invoice['discount'] =number_format( $order->total_discounts, 2, ".", "");
			$invoice['coupon'] = '3XY8P';
			
			$shipping_total	= $order->total_shipping;
			
			if($shipping_total>0)
			{
				
				$invoice['items'][] = array(
				'name' => 'Shipping Charge',
				'price' => number_format( $shipping_total, 2, ".", ""),
				'quantity' => 1,
				'description' => ''
				);	
			}
			
			if($tax_total >0)
			{
			
				$invoice['items'][] = array(
					'name' => 'Tax',
					'price' => number_format( $tax_total, 2, ".", ""),
					'quantity' => 1,
					'description' => ''
				);
	 
			}
			
			$pay_data=array(
				'sipay_token' => $_POST['sipay_token'],
				'sipay_3d' => $_POST['sipay_3d'],
				'cc_holder_name' => $_POST['cc_holder_name'],
				'cc_no' => $_POST['cc_number'],
				'expiry_month' => $_POST['expiry_month'],
				'expiry_year' => $_POST['expiry_year'],
				'cvv' => $_POST['cc_cvv'],
				'pos_id' => $_POST['pos_id'],
				'pos_amount' => $_POST['pos_amount'],
				'currency_id' => $_POST['currency_id'],
				'currency_code' => $_POST['currency_code'],
				'campaign_id' => $_POST['campaign_id'],
				'allocation_id' => $_POST['allocation_id'],
				'installments_number' => $_POST['installments_number'],
				'invoice_id' => $order_id,
				'invoice_description' => "Order with Invoice ".  $order_id,
				'total' => number_format( $order_total, 2, ".", ""),
				'merchant_key' => Configuration::get('SIPAY_MERCHANT_KEY'),
				'payable_amount' => number_format( $_POST['pos_amount'], 2, ".", ""),
				'return_url' => $invoice['return_url'],
				'cancel_url' => $invoice['cancel_url'],
				'items' => json_encode($invoice['items']),
				'name' => $firstname,
				'surname' => $lastname,
				'bill_address1' => isset($address1) ? $address1 : '',
				'bill_address2' => isset($address2) ? $address2 : '',
				'bill_city' => isset($city) ? $city : '',
				'bill_postcode' => isset($postcode) ? $postcode : '',
				'bill_state' => isset($state) ? $state : '',
				'bill_country' => isset($country) ? $country : '',
				'bill_email' => isset($order_info['email']) ? $order_info['email'] : '',
				'bill_phone' => isset($phone) ? $phone : ''

			);
			
			
			
			foreach($pay_data as $key => $val){
					
				$formdatass[] = "<input type='hidden' name='".$key."' value='".$val."'/>";
			}
			?>
			<form action="<?php echo $baseurl; ?>index.php?fc=module&module=sipay&controller=receiptpage&order_id=<?php echo $order_id; ?>" method="post" id="hwesipay">
			   <?php echo  implode('', $formdatass); ?>
			  
			</form> 
			  
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
			<script>
			$("#hwesipay").submit();
			</script>
			 
				<?php
							
							
				
			die();
		}
		
		//================================================case3========================================================//
			
		$item_total=0;
		
		foreach($products as $product){
				$item = [
				'name' => htmlspecialchars($product['product_name']),
				'price' => number_format( $product['price'], 2, ".", ""),
				'quantity' =>(int)$product['product_quantity'],
				'description' => '',
			];
			$invoicecase3['items'][] = $item;
			$item_total += $product['price'] * $product['product_quantity'];
		}
			
			if($order->total_discounts>0)
			{
				$invoicecase3['discount'] =number_format( $order->total_discounts, 2, ".", "");
				$invoicecase3['coupon'] = '3XY8P';
			}
			else
			{
				$invoicecase3['discount'] =0;
				$invoicecase3['coupon'] = '3XY8P';
			}
			$shipping_total	= $order->total_shipping;
			
			if($shipping_total>0)
			{
				
				$invoicecase3['items'][] = array(
				'name' => 'Shipping Charge',
				'price' => number_format( $shipping_total, 2, ".", ""),
				'quantity' => 1,
				'description' => ''
				);	
			}
			
			if($tax_total >0)
			{
			
				$invoicecase3['items'][] = array(
					'name' => 'Tax',
					'price' => number_format( $tax_total, 2, ".", ""),
					'quantity' => 1,
					'description' => ''
				);
	 
			}
			
			
			
			
			$invoicecase3['invoice_id']=$order_id;
			$invoicecase3['invoice_description']="Order with Invoice ".$order_id;
			$invoicecase3['return_url']=$baseurl.'index.php?fc=module&module=sipay&controller=success&order_id='.$order_id;
			$invoicecase3['cancel_url']=$baseurl.'index.php?fc=module&module=sipay&controller=failure&order_id='.$order_id;
			$invoicecase3['total']=number_format( $order_total, 2, ".", "");
			$invoicecase3['payable_amount']=number_format( $_POST['pos_amount'], 2, ".", "");
			$invoicecase3['merchant_key']=trim(Configuration::get('SIPAY_MERCHANT_KEY'));
			
			$invoicecase3['pos_id']= $_POST['pos_id'];
			$invoicecase3['currency_id']=$_POST['currency_id'];
			$invoicecase3['campaign_id']=$_POST['campaign_id'];
			$invoicecase3['allocation_id']=$_POST['allocation_id'];
			$invoicecase3['installments_number']=$_POST['installments_number'];
			$invoicecase3['cc_holder_name']=$_POST['cc_holder_name'];
			$invoicecase3['cc_no']=$_POST['cc_number'];
			$invoicecase3['expiry_month']=$_POST['expiry_month'];
			$invoicecase3['expiry_year']=$_POST['expiry_year'];
			$invoicecase3['cvv']=$_POST['cc_cvv'];
			
			$invoicecase3['currency_code']=$_POST['currency_code'];
			$invoicecase3['app_id']=trim(Configuration::get('SIPAY_APP_ID'));
			$invoicecase3['app_secret']=trim(Configuration::get('SIPAY_APP_SECRET_KEY'));
			
			$invoicecase3['name']=$firstname;
			$invoicecase3['surname']=$lastname;
			$invoicecase3['bill_address1']=isset($address1) ? $address1 : '';
			
			$invoicecase3['bill_address2']=isset($address2) ? $address2 : '';
			$invoicecase3['bill_city']=isset($city) ? $city : '';
			$invoicecase3['bill_postcode']=isset($postcode) ? $postcode : '';
			
			$invoicecase3['bill_state']=isset($state) ? $state : '';
			$invoicecase3['bill_country']=isset($country) ? $country : '';
			$invoicecase3['bill_email']=isset($order_info['email']) ? $order_info['email'] : '';
			
			$invoicecase3['bill_phone']=isset($phone) ? $phone : '';
			
			
			$headers= array(
			'Accept: application/json',
			'Content-Type: application/json'
			);
				
			$headers[]= "Authorization: Bearer {$_POST['sipay_token']}";
			
			$ch = curl_init();
			curl_setopt($ch, CURLOPT_URL,"https://provisioning.sipay.com.tr/ccpayment/api/pay");

			curl_setopt($ch, CURLOPT_POST, true);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
			curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($invoicecase3));
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,2);
			curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,0);
			$response = json_decode(curl_exec($ch),true);
			
			
			curl_close($ch);
			
			if ($response['status_code'] == 100 ) {
			?>
				
				 <script>
					location.replace('<?php echo  $returnurlset; ?>');
					
					</script>
					
				<?php
			}else{
				$error=$response['status_description'];
				
				//$this->model_checkout_order->addOrderHistory($order_info['order_id'], 10);
				?>
				 <script>
					location.replace('<?php echo  $failureseturl; ?>');
					
					</script>
				
				<?php
			}
	}
}
