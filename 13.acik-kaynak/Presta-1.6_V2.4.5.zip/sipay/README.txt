Sipay payment module

We need to login with admin detail.

First we need to add this module in 'Modules and Services'.

Here you need to upload zip file of sipay module.

To see this payemnt module, we go to 'Modules and Services' then show sipay payment.

For configuration, click on configure.

We need to save Merchant details.

Like Merchant key, Merchant id, App id, App key.

And select currency, set button label, and set recurring web hook key.

When we want to recurring payment we need to make a product as recurring product. To make a product 
is recurring product we need to set No. of payment, order payment cycle, order payment interval.

To set recurring fields, edit a product and add a product then you will see 'Sipay' tab, click on 'Sipay' tab then show the form to add recurring fields. 

When we do payment it will work.

