<?php
/**
 * Created by PhpStorm.
 * User: user
 * Date: 10/7/2020
 * Time: 11:41 PM
 */

class SipayPayByToken
{
    private $end_point = "https://provisioning.sipay.com.tr";// for production use https://app.sipay.com.tr

    private $merchant_key = '$2y$10$w/ODdbTmfubcbUCUq/ia3OoJFMUmkM1UVNBiIQIuLfUlPmaLUT1he';//for production, use production merchant key

    private $app_id = "c3d81ae3cc3011ef10dcefa31a458d65";// for production, use production app_key
    private $app_secret = "217071ea9f3f2e9b695d8f0039024e64";// for production, use production app_secret

    private $return_url = "https://provisioning.sipay.com.tr/payment_success.php";
    private $cancel_url = "https://provisioning.sipay.com.tr/payment_success.php";


    public function payByCardToken($request){

        $invoice_id = rand(100, 99999); // merchant invoice id
        $currency_code = $request['currency_code']; //Merchant currency code e.g(TRY,USD,EUR)
        $total = 0;

        $cart = [[
            'name' => "Test Product",
            'price' => $request['total'],
            'quantity' => 1,
            'description' => "Some Description",
        ]];

        foreach ($cart as $item){
            $productPrice = $item['price'] * $item['quantity'];
            $total = $total + $productPrice;
        }

        $item_js = json_encode($cart);

        $sale_web_hook = '';//put your web hook

        if (!isset($request['installments_number'])
            || (isset($request['installments_number']) && $request['installments_number'] < 1)){
            $installment = 1;
        }else{
            $installment = $request['installments_number'];
        }

        $hash_key = $this->generateHashKey($total, $installment, $currency_code,
            $this->merchant_key, $invoice_id, $this->app_secret);

        $invoice = [
            'merchant_key' => $this->merchant_key,
            'invoice_id' => $invoice_id,
            'total' => $total,
            'items' => $item_js,
            'currency_code' => $currency_code,
            'customer' => $request['customer'],
            'customer_email' => $request['customer_email'],
            'customer_name' => $request['customer_name'],
            'customer_phone' => $request['customer_phone'],
            'card_token' => $request['card_token'],
            'installments_number' => $installment,
            'hash_key' => $hash_key,
            'cancel_url' => $this->cancel_url,
            'return_url' => $this->return_url,
        ];

        //billing info
        $invoice['bill_address1'] = 'Address 1 should not more than 100'; //should not more than 100 characters
        $invoice['bill_address2'] = 'Address 2'; //should not more than 100 characters
        $invoice['bill_city'] = 'Istanbul';
        $invoice['bill_postcode'] = '1111';
        $invoice['bill_state'] = 'Istanbul';
        $invoice['bill_country'] = 'TURKEY';
        $invoice['bill_phone'] = '008801777711111';
        $invoice['bill_email'] = 'demo@sipay.com.tr';
        $invoice['sale_web_hook_key'] = $sale_web_hook;

        if (isset($request['order_type'])){
            $invoice['order_type'] = 1;
            $invoice['recurring_payment_number'] = $request['recurring_payment_number'];
            $invoice['recurring_payment_cycle'] = $request['recurring_payment_cycle'];
            $invoice['recurring_payment_interval'] = $request['recurring_payment_interval'];
            $invoice['recurring_web_hook_key'] = $request['recurring_web_hook_key'] ?? '';

        }
        if (isset($request['card_program']) && !empty($request['card_program'])){
            $invoice['card_program'] = $request['card_program'];
        }

        $formOpen = "<form action='{$this->end_point}/ccpayment/api/payByCardToken' method='post' id='the-form'>";
        $form = '';
        foreach ($invoice as $key => $value){
            $form .= "<input type='hidden' name='{$key}' value='{$value}'>";
        }

        $formClose = "</form>";
        $script ='<script type="text/javascript">window.onload = function(){
                        document.getElementById("the-form").submit();}
                  </script>';

        echo $formOpen.$form.$formClose.$script;
        exit;

    }

    private function generateHashKey($total, $installment, $currency_code, $merchant_key,  $invoice_id, $app_secret){

        $data = $total.'|'.$installment.'|'.$currency_code.'|'.$merchant_key.'|'.$invoice_id;

        $iv = substr(sha1(mt_rand()), 0, 16);
        $password = sha1($app_secret);

        $salt = substr(sha1(mt_rand()), 0, 4);
        $saltWithPassword = hash('sha256', $password . $salt);

        $encrypted = openssl_encrypt(
            "$data", 'aes-256-cbc', "$saltWithPassword", null, $iv
        );
        $msg_encrypted_bundle = "$iv:$salt:$encrypted";
        $msg_encrypted_bundle = str_replace('/', '__', $msg_encrypted_bundle);
        return $msg_encrypted_bundle;
    }


    private function generateCashOutAPIHashKey($sum_of_amount_column, $first_row_iban, $first_row_amount,
                                               $first_row_currency, $first_row_gsm, $app_secret ){
        //remove plus(+) sign from gsm number.
        $data = $sum_of_amount_column.'|'.$first_row_iban.'|'.$first_row_amount.'|'.$first_row_currency.'|'.$first_row_gsm;

        $iv = substr(sha1(mt_rand()), 0, 16);
        $password = sha1($app_secret);

        $salt = substr(sha1(mt_rand()), 0, 4);
        $saltWithPassword = hash('sha256', $password . $salt);

        $encrypted = openssl_encrypt(
            "$data", 'aes-256-cbc', "$saltWithPassword", null, $iv
        );
        $msg_encrypted_bundle = "$iv:$salt:$encrypted";
        $hash_key = str_replace('/', '__', $msg_encrypted_bundle);
        return $hash_key;
    }

}
