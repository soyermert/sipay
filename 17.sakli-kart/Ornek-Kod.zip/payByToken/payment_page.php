<?php
/**
 * Created by Sipay.
 * User: Tareq
 * Date: 10/8/2020
 * Time: 12:38 AM
 */
require_once 'SipayPayByToken.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $sipaySmart3d = new SipayPayByToken();
    $sipaySmart3d->payByCardToken($_POST);
}



?>


<!DOCTYPE html>
<html>
<head>
    <title>Checkout</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <style>

        form{
            padding: 30px 10px 10px;
            margin-top: 15px;
            -webkit-box-shadow: -1px 6px 15px -10px rgba(145,145,145,1);
            -moz-box-shadow: -1px 6px 15px -10px rgba(145,145,145,1);
            box-shadow: -1px 6px 15px -10px rgba(145,145,145,1);
        }

        input[type=checkbox].css-checkbox:checked + label.css-label {
            background-position: 0 -15px;
        }
        input[type=checkbox].css-checkbox + label.css-label {
            padding-left: 5px;
            height: 15px;
            display: inline-block;
            line-height: 15px;
            background-repeat: no-repeat;
            background-position: 0 0;
            font-size: 14px;
            vertical-align: middle;
            cursor: pointer;
        }
        label{
            font-weight: 500 !important;
            color: black;
        }

    </style>

</head>
<body>


<div class="loader"></div>
<div class="row mt-lg-5">
    <div class="col-sm-4"></div>
    <div class="col-sm-4">
        <form action="<?php echo($_SERVER['PHP_SELF']) ?>" class="payment_form" method="post">

            <table>
              <tr>
                <td>Amount</td>
                <td><input type="text" name="total" placeholder="" value="0.1"></td>
              </tr>
              <tr>
                <td>Currency</td>
                <td>
                  <select name="currency_code">
                    <option value="TRY">TRY</option>
                    <option value="USD">USD</option>
                    <option value="EUR">EUR</option>
                  </select>
                </td>
              </tr>
              <tr>
                <td>Customer</td>
                <td><input type="text" name="customer" placeholder="" value=""></td>
              </tr>
              <tr>
                <td>Email</td>
                <td><input type="text" name="customer_email" placeholder="" value=""></td>
              </tr>
              <tr>
                <td>Name</td>
                <td><input type="text" name="customer_name" placeholder="" value=""></td>
              </tr>
              <tr>
                <td>Phone</td>
                <td><input type="text" name="customer_phone" placeholder="" value=""></td>
              </tr>
              <tr>
                <td>Card Token</td>
                <td><input type="text" name="card_token" placeholder="" value=""></td>
              </tr>
              <tr>
                <td>Installment</td>
                <td><input type="text" name="installments_number" placeholder="" value="1"></td>
              </tr>

              <tr>
                <td colspan="2"><input type="submit" value="Pay" name="Pay"></td>
              </tr>
            </table>


        </form>
    </div>
    <div class="col-sm-4"></div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<script>

    $(".number-only").keypress(function(e){
        var keyCode = e.which;
        if (keyCode < 48 || keyCode > 57) {
            return false;
        }
    });

    $('#recurringPayment').click(function() {
        if( $(this).is(':checked')) {
            $("#recurringArea").show(100);

            $("#recurringArea :input").each(function(e){
                $(this).prop('required', true)
            });
        } else {
            $("#recurringArea").hide(100);
            $("#recurringArea :input").each(function(e){
                $(this).prop('required', false)
            });

        }
    });
</script>
</body>
</html>
